import axiosInstance from "plugins/axiosInstance"




// Function to get CSRF token
// const getCsrfToken = async () => {
//   await axiosInstance.get("/sanctum/csrf-cookie");
// };

// Function to get CSRF token
const getCsrfToken = async () => {
  try {
    await axiosInstance.get("/sanctum/csrf-cookie", { withCredentials: true }); // Ensure cookies are set
  } catch (error) {
    console.log("Failed to fetch CSRF token:", error);
    throw new Error("CSRF token could not be retrieved.");
  }
};

// Function to login user
// const login = async (credentials) => {
//   try {
//     await getCsrfToken(); // This sets the CSRF token in the browser's cookies
//     const response = await axiosInstance.post("/auth/login", credentials);
//     try {
//       localStorage.setItem("auth_token", response.data.access_token);
//       return response;
//     } catch (error) {
//       return error
//     }
//   } catch (error) {
//     return error;
//   }
// };

// const login = async (credentials) => {
//   try {
//     await getCsrfToken(); // This sets the CSRF token in the browser's cookies
//     const response = await axiosInstance.post("/auth/login", credentials, { withCredentials: true });
//     localStorage.setItem("auth_token", response.data.access_token);
//     return response;
//   } catch (error) {
//     return error;
//   }
// };

// Function to login user
const login = async (credentials) => {
  try {
    // Step 1: Fetch CSRF token to set it in cookies
    await getCsrfToken();

    // Step 2: Perform login request with the credentials
    const response = await axiosInstance.post("/auth/login", credentials);

    // Step 3: Store the authentication token in localStorage
    localStorage.setItem("auth_token", response.data.access_token);

    return response; // Return the response for further handling
  } catch (error) {
    // console.log("Login failed:", error.response?.data || error.message);
    // throw error; // Throw the error to handle it in calling components
    return error
  }
};

// Function to register user
const register = async (data) => {
  try {
    await getCsrfToken(); // This sets the CSRF token in the browser's cookies
    const response = await axiosInstance.post("/auth/register", data);
    return response
  } catch (error) {
    return error
  }
};

// Function to logout user
const logout = async () => {
  // await axiosInstance.post("/auth/logout");
  // localStorage.removeItem("auth_token");
  // document.cookie = 'XSRF-TOKEN=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';

  try {
    // Attempt to notify the server to invalidate the session
    await axiosInstance.post("/auth/logout");
  } catch (error) {
    console.warn(
      "Logout request failed, proceeding with local cleanup:", error.response?.data || error.message
    );
    // If the logout fails (e.g., due to token expiration), proceed with cleanup anyway
  }

  // Clean local storage and cookies regardless of backend response
  localStorage.removeItem("auth_token");
  document.cookie = 'XSRF-TOKEN=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
};

// const getProfile = async () => {
//   const response = await axiosInstance.get("/auth/profile");
//   if (response && response.data.profile) {
//     return response.data.profile;
//   }
//   return null;
// };

const getProfile = async () => {
  try {
    const response = await axiosInstance.get("/auth/profile");
    if (response && response.data && response.data.status === 'success') {
      return response;
    }
  } catch (error) {
    return error
  }
};

export {
  login,
  register,
  logout,
  getProfile,
}
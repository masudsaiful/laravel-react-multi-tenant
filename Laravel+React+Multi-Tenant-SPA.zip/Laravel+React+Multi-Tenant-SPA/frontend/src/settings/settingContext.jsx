import {createContext, useContext, useEffect, useCallback, useState, useMemo} from "react";

import { lightThemeMode } from "components/mui-customizations/styleCustomization";
import { darkThemeMode } from "components/mui-customizations/styleCustomization";

import { useAuth } from "auths/hooks/authHook";
import axiosInstance from "plugins/axiosInstance";


const SettingContext = createContext('');
const useSetting = () => {
  return useContext(SettingContext);
}

const SettingProvider = ({children}) => {
  const {isProfile, profile} = useAuth();
  const [themeModeState, setThemeModeState] = useState(lightThemeMode);
  const [themeModeSwitchStateUpdate, setThemeModeSwitchStateUpdate] = useState(null);
  
  // Fetch the theme mode from the backend and update state
  const fetchThemeMode = useCallback(async () => {
    if (!profile?.id) return;
      try {
        const result = await axiosInstance.get(`/settings/theme-mode/${profile.id}`);
        if (result?.data?.status === 'success') {
          const themeModeValue = result.data.themeMode;
          setThemeModeState(themeModeValue ? lightThemeMode : darkThemeMode);
          setThemeModeSwitchStateUpdate(themeModeValue);
        }
      } catch (error) {
        console.log("Failed to fetch theme mode:", error);
      }
  }, [profile?.id]);

  // Update the theme mode on the backend and refetch the current mode
  const handleThemeModeSwitchSetting = useCallback(async (value) => {
    try {
      await axiosInstance.post('/settings/theme-mode', { theme_mode: value });
      await fetchThemeMode();
    } catch (error) {
      console.log("Failed to update theme mode:", error);
    }
  }, [fetchThemeMode]);

  // Fetch the theme mode when the profile changes or on initialization
  useEffect(() => {
    if (isProfile) {
      fetchThemeMode();
    }
  }, [isProfile, fetchThemeMode]);


  // Provide a stable `themeMode` value for external components
  const themeMode = useMemo(() => themeModeState, [themeModeState]);

  return (
    <SettingContext.Provider value={{
      themeMode, 
      themeModeSwitchStateUpdate,
      handleThemeModeSwitchSetting,
    }}>
      {children}
    </SettingContext.Provider>
  )
}

export {
  SettingProvider, 
  useSetting,
};
// Regex to check fields
// First letter, no single char, at least two chars for multi words
const fieldRegex = /^[A-Za-z][A-Za-z0-9]{1,}(?: [A-Za-z0-9]{2,})*$/;
const validateString = value => fieldRegex.test(value);

const isNonValidString = (strng) => {
  return (
    strng.trim() === '' || // empty email (trimmed)
    !validateString(strng) // wrong formated email
  )
}

export default isNonValidString;

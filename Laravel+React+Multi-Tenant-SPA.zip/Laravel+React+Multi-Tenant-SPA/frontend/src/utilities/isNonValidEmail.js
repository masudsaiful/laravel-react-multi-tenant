// Regex to check email
// E-mail field value evalute through regex
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const validateEmail = email => emailRegex.test(email);

const isNonValidEmail = (email) => {
  return (
    email.trim() === '' || // empty email (trimmed)
    !validateEmail(email) // wrong formated email
  )
}

export default isNonValidEmail;

const isEmptyUniversalCheck = input => {
  return (
    input === null ||                 // Check for null
    input === undefined ||            // Check for undefined
    (typeof input === 'string' && input.trim() === '') || // Empty string (trimmed)
    (typeof input === 'object' && !Object.keys(input || {}).length) || // Empty object
    (Array.isArray(input) && input.length === 0) // Empty array

    // input === null || // Check for null
    // input === undefined || // Check for undefined
    // (typeof input === 'string' && input.trim() === '') || // Empty string (trimmed)
    // (typeof input === 'object' && input.constructor === Object && !Object.keys(input || {}).length) || // Empty plain object
    // (Array.isArray(input) && ( // Check if the array is:
    //   input.length === 0 || // Empty array
    //   input.every(item => isEmptyUniversalCheck(item)) // All elements are empty
    // )) || 
    // (input instanceof Set && input.size === 0) || // Empty Set
    // (input instanceof Map && input.size === 0) || // Empty Map
    // (input instanceof Date && isNaN(input.getTime())) // Invalid date
  );
}

export default isEmptyUniversalCheck;
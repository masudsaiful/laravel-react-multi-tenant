const onlyFirstLetterCapital= (name) => {
  if (typeof name !== 'string' || name.trim() === '') {
    return ''; // Return an empty string if input is not valid
  }
  // Trim the input to remove extra spaces and get the first word
  const firstWord = name.trim().split(' ')[0];
  return firstWord.charAt(0).toUpperCase(); // Capitalize the first letter
};

export default onlyFirstLetterCapital;

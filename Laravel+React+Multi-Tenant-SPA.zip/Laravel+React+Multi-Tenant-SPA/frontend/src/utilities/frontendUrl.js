const frontendUrl = import.meta.env.VITE_FRONTEND_URL
export default frontendUrl;
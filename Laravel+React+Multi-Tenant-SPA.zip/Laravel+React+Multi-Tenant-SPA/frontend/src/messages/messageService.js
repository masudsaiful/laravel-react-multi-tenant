// Start with an empty array to hold multiple messages
const messageService = []

export {messageService};
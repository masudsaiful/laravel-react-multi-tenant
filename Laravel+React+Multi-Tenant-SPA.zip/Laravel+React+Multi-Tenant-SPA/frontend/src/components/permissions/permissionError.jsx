import { Paper, Stack, Alert, Typography } from "@mui/material";
import NetworkLockedOutlinedIcon from '@mui/icons-material/NetworkLockedOutlined';
import { 
  ccGap1,
  ccGap2,
  ccGap2p5,
} from "components/mui-customizations/styleCustomization";

import { useSetting } from "settings/settingContext";


const PermissionError = ({children}) => {
  const {themeMode} = useSetting();

  return (
    <Paper
      elevation={3}
      sx={{
        flexGrow: 1,
        backgroundColor: themeMode?.ccGlow2,
        p: {
          xs: ccGap2,
          sm: ccGap2p5,
          md: ccGap2p5,
          xl: ccGap2p5,
          lg: ccGap2p5,
        },
      }}
    >
      <Stack
        direction="column"
        justifyContent="center"
        alignItems="center"
        sx={{ textAlign: "center" }}
        spacing={{
          xs: ccGap1,
          sm: ccGap1,
          md: ccGap2,
          xl: ccGap2,
          lg: ccGap2,
        }}
      >
        <Alert
          variant="filled"
          severity="error"
          icon={<NetworkLockedOutlinedIcon fontSize="inherit" />}
          sx={{
            alignSelf: "stretch",
            justifyContent: "center",
            alignItems: "center",
            textAlign: "center",
            backgroundColor: themeMode?.ccError1,
          }}
        >
          <Typography variant="subtitle1">
            {children}
          </Typography>
        </Alert>
      </Stack>
    </Paper>
  );
};

export default PermissionError

import React, { useState, memo, useEffect, useCallback, useMemo } from "react";

import { useTheme } from '@mui/material/styles';
import SaveAsTwoToneIcon from '@mui/icons-material/SaveAsTwoTone';
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import ModeStandbyIcon from '@mui/icons-material/ModeStandby';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline'; 
import CCMuiSingleSelectAutoComplete from "components/mui-customizations/ccMuiSingleSelectAutoComplete";
import CCMuiMultiSelectAutoComplete from "components/mui-customizations/ccMuiMultiSelectAutoComplete";
import CCMuiTextField from "components/mui-customizations/ccMuiTextField";
import CCMuiTextArea from "components/mui-customizations/ccMuiTextArea";
import CCMuiButton from "components/mui-customizations/ccMuiButton";
import {CCMuiDividerHorizontal} from "components/mui-customizations/ccMuiDivider";
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import CreateOutlinedIcon from '@mui/icons-material/CreateOutlined';
import EditOffOutlinedIcon from '@mui/icons-material/EditOffOutlined';
import {
  Box,
  FormControl,
  FormHelperText,
  InputLabel,
  OutlinedInput,
  Checkbox,
  FormGroup,
  FormControlLabel,
  IconButton,
  Tooltip,
  Typography,
  Chip,
} from "@mui/material";

import isEmptyUniversalCheck from "utilities/isEmptyUniversalCheck";
import wordsUpperCase from "utilities/wordsUpperCase";
import { usePermission } from "components/permissions/permissionContext";
import { useSetting } from "settings/settingContext";
import { useRole } from "components/roles/roleContext";
import { useUser } from "components/users/userContext";


const PermissionFields = memo(({
  children,
  models,
  permissionStates, 
  setPermissionStates,
  errorStates,
  setErrorStates,
  handleCreatePermission,
  handleEditPermission,
}) => {
  const {themeMode} = useSetting();
  const theme = useTheme();
  const {fetchAllUsers, allUsers} = useUser();
  const {fetchAllRoles, allRoles} = useRole();
  const {permissionCreateChk, permissionEditUpdateChk, permissionDeleteChk} = usePermission();

  const [submitOnOfBasedOnRoleMatch, SetSubmitOnOfBasedOnRoleMatch] = useState(null)
  const [submitOnOfBasedOnUserMatch, SetSubmitOnOfBasedOnUserMatch] = useState(null)

  // Format roles to populate roles field
  const memoizedRoles = useMemo(
    () =>
      allRoles?.map((role) => ({
        id: role.id,
        label: role.title,
        value: role.name,
      })) || []
    [allRoles]
  );

  // Format users to populate users field
  const memoizedUsers = useMemo(
    () =>
      allUsers?.map((user) => ({
        id: user.id,
        label: user.name,
        value: user.username,
        rolesOfThisUser: user?.roles?.map(role=>role.id),
      })) || [],
    [allUsers]
  );
  
  const handleRemovePermission = (uuid) => {
    setPermissionStates((prev) => prev.filter((item, i) => item.uuid !== uuid));
  };

  const handleKeepPermission = (uuid) => {
    setPermissionStates((prev) => prev.filter((item, i) => item.uuid === uuid));
  };

  // const handlePermissionChange = (index, field, value) => {
  //   const updatedPermissions = [...permissionStates];
  //   updatedPermissions[index][field] = value;
  //   setPermissionStates(updatedPermissions);
  // };

  // const debounce = (func, delay) => {
  //   let timeout;
  //   return (...args) => {
  //     clearTimeout(timeout);
  //     timeout = setTimeout(() => func(...args), delay);
  //   };
  // };
  
  // const debouncedHandleChange = React.useCallback(debounce((event) => {
  //   handlePermissionChange(uuid, name, event.target.value);
  // }, 200), []);

  // Checking non empty value and update corresponding errors if found while field changes
  const handlePermissionChange = useCallback((uuid, field, value) => {
    const updatedPermissions = [...permissionStates];
    const updatedErrors = [...errorStates];
  
    const permissionIndex = updatedPermissions.findIndex(item => item.uuid === uuid);
    const errorIndex = updatedErrors.findIndex(item => item.uuid === uuid);
  
    if (permissionIndex !== -1) {
      updatedPermissions[permissionIndex][field] = value;
    }
    if (errorIndex !== -1) {
      updatedErrors[errorIndex][field] = '';
    }

    if (field === 'role_id' || field === 'model') {
      if (isEmptyUniversalCheck(value)) {
        updatedErrors[errorIndex][field] = `${wordsUpperCase(field)} must be selected`;
      } 
    }
      
    // Role validation
    if (field === 'role_id') {
      // Current permission states collection based on selected users
      const selectedUsers = memoizedUsers.filter(user => updatedPermissions[permissionIndex].user_id.includes(user.id));

      // Current permission states collection that have no role_id assigned 
      const roleMismatch = selectedUsers.some(user => !user.rolesOfThisUser.includes(value));
  
      // If not role_id assigned to user found error set
      if (roleMismatch) {
        updatedErrors[errorIndex][field] = `${wordsUpperCase(field)} mismatch user`;
        SetSubmitOnOfBasedOnRoleMatch(uuid);

        updatedErrors[errorIndex]['user_id'] = 'User mismatch role';
        SetSubmitOnOfBasedOnUserMatch(uuid);

      } else {
        updatedErrors[errorIndex][field] = ""
        SetSubmitOnOfBasedOnRoleMatch(null);

        updatedErrors[errorIndex]['user_id'] = "";
        SetSubmitOnOfBasedOnUserMatch(null);
      }
    }

    // User validation
    if (field === 'user_id') {
      // Current permission states collection based on selected users
      const selectedUsers = memoizedUsers.filter(user => value.includes(user.id));

      // Current permission states selected role collection
      const roleId = updatedPermissions[permissionIndex].role_id;

      // Current permission states collection that have not assigned the selected role
      const userMismatch = selectedUsers.some(user => !user.rolesOfThisUser.includes(roleId));
  
      // If not role_id assigned to user found error set
      if (userMismatch) {
        updatedErrors[errorIndex][field] = `${wordsUpperCase(field)} mismatch role`;
        SetSubmitOnOfBasedOnUserMatch(uuid);

        updatedErrors[errorIndex]['role_id'] = `Role mismatch user`;
        SetSubmitOnOfBasedOnRoleMatch(uuid);
      } else {
        updatedErrors[errorIndex][field] = ""
        SetSubmitOnOfBasedOnUserMatch(null);

        updatedErrors[errorIndex]['role_id'] = '';
        SetSubmitOnOfBasedOnRoleMatch(null);
      }
    }

    setPermissionStates(updatedPermissions);
    setErrorStates(updatedErrors);

    // setPermissionStates((prev) => {
    //   const updated = [...prev];
    //   const index = updated.findIndex(item => item.uuid === uuid);
    //   if (index !== -1) updated[index][field] = value;
    //   return updated;
    // });
  
    // setErrorStates((prev) => {
    //   const updated = [...prev];
    //   const index = updated.findIndex(item => item.uuid === uuid);
    //   if (index !== -1) updated[index][field] = isEmptyUniversalCheck(value)
    //     ? `${wordsUpperCase(field)} must be selected`
    //     : '';
    //   return updated;
    // });

    // const locatePermission = updatedPermission.map((item,index) => {
    //   if ( item.uuid === uuid) {
    //     if (field === 'user_id' || field === 'model') {
    //       // alert(updateError.find((e,i)=>e.uuid === uuid).)

    //       updateError.find((e,i)=> {
    //         if(e.uuid === uuid) {
    //           return updateError[i][field] = '';
    //         } {
    //           return e;
    //         }
    //       });
    //       setErrorStates(updateError);

    //       if (isEmptyUniversalCheck(value)) {
    //         updateError.find((e,i)=> {
    //           if(e.uuid === uuid) {
    //             return updateError[i][field] = `${wordsUpperCase(field)} must be selected`;
    //           } {
    //             return e;
    //           }
    //         });
    //         setErrorStates(updateError);
    //         return updatedPermission[index][field] = value;
    //       } else {
    //         updateError.find((e,i)=> {
    //           if(e.uuid === uuid) {
    //             return updateError[i][field] = '';
    //           } {
    //             return e;
    //           }
    //         });
    //         setErrorStates(updateError);
    //         return updatedPermission[index][field] = value;
    //       }
    //     } else {
    //       return updatedPermission[index][field] = value;
    //     }
    //   } else {
    //     return item;
    //   }
    // });
  }, [permissionStates, errorStates, memoizedUsers]);

  // const handleCreatePermission = (uuid) => {
  //   const permission = permissionStates[uuid];
  //   console.log("Submitting Permission:", permission);
  //   showSnackbar("Permission submitted successfully!");
  // };

  const fetchDatas = useCallback(async () => {
    try {
      const fetchOperations = [
        { name: "fetchAllUsers", promise: fetchAllUsers() },
        { name: "fetchAllRoles", promise: fetchAllRoles() },
      ];

      const results = await Promise.allSettled(fetchOperations.map(op => op.promise));

      results.forEach((result, index) => {
        if (result.status === "fulfilled") {
          console.log(`${fetchOperations[index].name} succeeded:`, result.value);
        } else if (result.status === "rejected") {
          console.log(`${fetchOperations[index].name} failed:`, result.reason);
        }
      });
    } catch (error) {
      await ccGetError(error);
    }
  }, []);

  useEffect(() => {
    fetchDatas();
  }, [fetchDatas])
  
  const renderSelectField = (uuid, name, label, placeholder="",items, value, error="") => (
    <FormControl 
      sx={{ 
        gridColumn: {
          xs: "span 6",
          sm: "span 6",
          md: 'span 4',
          lg: 'span 2',
        },
      }}
      size="small" 
      required 
      error={!!error}
    >
      <InputLabel id={`${name}-${uuid}-label`} sx={{ color: themeMode?.ccTreeGreen2 }}>{label}</InputLabel>
      <CCMuiSingleSelectAutoComplete
        name={`${name}-${uuid}`}
        value={value}
        id={`${name}-${uuid}`}
        labelId={`${name}-${uuid}-label`}
        placeholder={placeholder}
        onChange={(event, newValue) => handlePermissionChange(uuid, name, event.target.value)}
        input={<OutlinedInput id={`${name}-${uuid}-select`} label={label} />}
        items={items}
      />
      <FormHelperText sx={{ mx: 0, color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  const renderMultiSelectField = (uuid, name, label, placeholder="", items, value = [], error = "") => (
    <FormControl 
      sx={{ 
        gridColumn: {
          xs: "span 6",
          sm: "span 6",
          md: 'span 4',
          lg: 'span 2',
        }
      }} 
      size="small" 
      error={!!error}
    >
      <InputLabel id={`${name}-${uuid}-label`} sx={{ color: themeMode?.ccTreeGreen2 }}>{label}</InputLabel>
      <CCMuiMultiSelectAutoComplete
        name={`${name}-${uuid}`}
        value={value}
        id={`${name}-${uuid}`}
        labelId={`${name}-${uuid}-label`}
        placeholder={placeholder}
        onChange={(event) => handlePermissionChange(uuid, name, event.target.value)}
        input={<OutlinedInput id={`${name}-${uuid}-select`} label={label} />}
        items={items} // Ensure items are passed correctly
        multiple
      />
      <FormHelperText sx={{ mx: 0, color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );
  
  const renderCheckbox = (uuid, name, label, type="checkbox", value="", error = "") => (
    <FormControl 
      sx={{ 
        ml:0.25,
        gridColumn: {
          xs: "span 6",
          sm: "span 6",
          md: 'span 2',
          lg: 'span 1',
        },
      }} 
      size="small" 
      error={!!error}
    >
      <FormGroup>
        <FormControlLabel
          control={
            <Checkbox
              size="small"
              sx={{ 
                // '& .MuiSvgIcon-root': { fontSize: 18 }, 
                pr: 0,
                mr: 0,
              }}
              type={type}
              name={`${name}-${uuid}`}
              id={`${name}-${uuid}`}
              label={label}
              checked={Boolean(value)}
              onChange={(event) =>
                handlePermissionChange(uuid, name, event.target.checked)
              }
              color="primary"
            />
          }
          label={label}
        />
      </FormGroup>
      <FormHelperText sx={{ color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  const renderTextField = (uuid, name, label, type="", value="", error = "") => (
    <FormControl 
      sx={{ 
        gridColumn: {
          xs: "span 9",
          sm: "span 9",
          md: 'span 5',
          lg: 'span 2',
        }
      }} 
      size="small" 
      error={!!error}
    >
      <CCMuiTextField
        type="text"
        name={`${name}-${uuid}`}
        id={`${name}-${uuid}`}
        label={label}
        value={value}
        placeholder={`Enter ${label.toLowerCase()}`}
        onChange={(event) => handlePermissionChange(uuid, name, event.target.value)}
        autoComplete="off"
      />
      <FormHelperText sx={{ color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  const renderTextarea = (uuid, name, label, type="", value = "", error = "") => (
    <FormControl 
      size="small"
      sx={{ 
        gridColumn: {
          xs: "span 9",
          sm: "span 9",
          md: 'span 5',
          lg: 'span 2',
        }
      }} 
      error={!!error}
    >
      <CCMuiTextArea
        size="small"
        name={`${name}-${uuid}`}
        id={`${name}-${uuid}`}
        label={label}
        maxRows={1}
        placeholder={`Enter ${label.toLowerCase()}`}
        value={value}
        onChange={(event) => handlePermissionChange(uuid, name, event.target.value)}
      />
      <FormHelperText sx={{ mx: 0, color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  return (
    <>
      <Box
        component="form"
        sx={{
          display: 'grid',
          gridTemplateColumns: 'repeat(18, 1fr)',    
          gap: 0.5,
          width: '100%',
        }}
        noValidate
        autoComplete="off"
      >
        {children}

        {!isEmptyUniversalCheck(permissionStates) 
        ?
          permissionStates?.map((permission, index) => (
            <React.Fragment key={permission.uuid}>
              {renderSelectField(permission.uuid, "role_id", "Role", "Role title (name)", memoizedRoles, permission.role_id, errorStates.find(e=>e.uuid === permission.uuid).role_id)}
              {renderSelectField(permission.uuid, "model", "Models", "Model name", models, permission.model,  errorStates.find(e=>e.uuid === permission.uuid).model)}
              {renderMultiSelectField(permission.uuid, "user_id", "User(s)", "User name (username)", memoizedUsers, permission.user_id,  errorStates.find(e=>e.uuid === permission.uuid).user_id)}
              {renderCheckbox(permission.uuid, "create", "Cre", 'checkbox', permission.create,  errorStates.find(e=>e.uuid === permission.uuid).create)}
              {renderCheckbox(permission.uuid, "update", "Upd", 'checkbox', permission.update,  errorStates.find(e=>e.uuid === permission.uuid).update)}
              {renderCheckbox(permission.uuid, "delete", "Del", 'checkbox', permission.delete,  errorStates.find(e=>e.uuid === permission.uuid).delete)}
              {renderTextField(permission.uuid, "title", "Title", 'text', permission.title,  errorStates.find(e=>e.uuid === permission.uuid).title)}
              {renderTextarea(permission.uuid, "note", "Note", 'text', permission.note,  errorStates.find(e=>e.uuid === permission.uuid).note)}

              <Box
                display="flex"
                flexDirection="row"
                justifyContent="flex-end"
                alignItems="center"
                sx={{ 
                  gridColumn: {
                    xs: "span 18",
                    sm: "span 18",
                    md: 'span 8',
                    lg: 'span 5',
                    xl: 'span 5', 
                  },
                }}
              >
                {(submitOnOfBasedOnRoleMatch === permission.uuid ||
                  submitOnOfBasedOnUserMatch === permission.uuid) 
                  ? '' : 
                  <>
                    {permissionCreateChk() && (
                      isEmptyUniversalCheck(permission.id)) && (
                      <CCMuiButton 
                        startIcon={<SaveAsTwoToneIcon />}
                        sx={{ 
                          mr: 0.5,
                          px: 0.75,
                          bgcolor: themeMode?.ccButtonBB
                        }}
                        onClick={() => handleCreatePermission(permission.uuid)}
                      >
                        Create
                      </CCMuiButton>
                    )}

                    {permissionEditUpdateChk() && (
                      !isEmptyUniversalCheck(permission.id)) && (
                      <CCMuiButton 
                        startIcon={<SaveAsTwoToneIcon />}
                        sx={{ 
                          mr: 0.5,
                          px: 0.75,
                          bgcolor: themeMode?.ccButtonBB
                        }}
                        onClick={() => handleEditPermission(permission.uuid)}
                      >
                        Update
                      </CCMuiButton>
                      )}
                  </>
                }

                <Tooltip title="Remove item">
                  <IconButton
                    onClick={() => handleRemovePermission(permission.uuid)}
                    sx={{color:`${themeMode?.ccButtonEB}`, px:0}}
                  >
                    <RemoveCircleOutlineIcon />
                  </IconButton>
                </Tooltip>

                <Tooltip title="Standby item">
                  <IconButton
                    onClick={() => handleKeepPermission(permission.uuid)}
                    color="primary"
                    sx={{color:`${themeMode?.ccButtonGB}`, px:0}}
                  >
                    <ModeStandbyIcon />
                  </IconButton>
                </Tooltip>

                {permissionDeleteChk() && (
                <Tooltip title="Delete item">
                  <IconButton
                    onClick={() => handleRemovePermission(permission.uuid)}
                    sx={{color:`${themeMode?.ccButtonDB}`, px:0}}
                  >
                    <DeleteForeverIcon />
                  </IconButton>
                </Tooltip>)}

                {/* <CCMuiButton 
                  startIcon={<CancelOutlinedIcon />}
                  sx={{
                    px: 0.75,
                    mr: 0.5,
                    bgcolor: themeMode?.ccButtonEB, 
                  }}
                  onClick={() => handleRemovePermission(permission.uuid)}
                >
                  Remove
                </CCMuiButton> */}

                {/* <CCMuiButton 
                  startIcon={<CancelOutlinedIcon />}
                  sx={{mr:0, bgcolor: themeMode?.ccButtonDB}}
                  onClick={() => handleRemovePermission(permission.uuid)}
                >
                  Del
                </CCMuiButton> */}

                {/* <IconButton
                  // Third party component like react router 'Link' can be integrated to MUI button using props.
                  component={Link}
                  to={`/user/edit/${params.id}`}
                  color="primary"
                  onClick={(event) => event.stopPropagation()} 
                >
                  <EditIcon />
                </IconButton>} */}
              </Box>

              <Box
                display="flex"
                flexDirection="row"
                justifyContent="flex-start"
                alignItems="center"
                sx={{gridColumn: "span 18"}}
              >
                <Chip 
                  sx={{
                    bgcolor: `${themeMode?.ccGlow3}`,
                    color: `${themeMode?.ccFontDark}`,
                  }}
                  size="small"                  
                  label={`Created By: ${permission?.created_by_user?.name} (${permission?.created_by_user?.username})`} 
                  icon={<CreateOutlinedIcon 
                    sx={{
                      "&.MuiChip-icon": {
                        bgcolor: `${themeMode?.ccGlow3}`,
                        color: `${themeMode?.ccFontDark}`,
                        fontSize: '12px'
                      }
                    }} 
                  />}
                />
              </Box>

              <Box
                display="flex"
                flexDirection="row"
                justifyContent="flex-start"
                alignItems="center"
                sx={{gridColumn: "span 18"}}
              >
                <Chip 
                  size="small"                  
                  label={`Updated By: ${permission?.updated_by_user?.name} (${permission?.updated_by_user?.username})`}
                  icon={<EditOffOutlinedIcon 
                    sx={{
                      "&.MuiChip-icon": {
                        fontSize: '12px'
                      }
                    }} 
                  />}
                />
              </Box>

              {
                permissionStates.length - 1 !== index &&
                <CCMuiDividerHorizontal 
                  sx={{
                    pb:1.5,
                    mb:2.5,
                    gridColumn: 'span 18',
                  }} 
                />
              }
            </React.Fragment>
          ))
        : 
          <Typography
            display="flex"
            alignItems="center"
            justifyContent="center"
            color={`${themeMode?.ccError1}`}
            sx={{gridColumn: 'span 18'}}
          >
            <InfoOutlinedIcon sx={{mr:1}} />
            No permission found created by the user
          </Typography>
        }
      </Box>
    </>
  );
});

export default PermissionFields;

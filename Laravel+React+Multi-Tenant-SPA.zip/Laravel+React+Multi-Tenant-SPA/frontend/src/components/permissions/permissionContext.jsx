import { useState, useEffect, createContext, useContext, memo } from "react";
import { Paper, Stack, Alert, Typography } from "@mui/material";
import { 
  ccGap1,
  ccGap2,
  ccGap2p5,
} from "components/mui-customizations/styleCustomization";

import { useError } from "errors/errorHook";
import { useSetting } from "settings/settingContext";
import { useAuth } from "auths/hooks/authHook";
import useCurrentPages from "components/layouts/hooks/currentPagesHook";
import isEmptyUniversalCheck from "utilities/isEmptyUniversalCheck";
import PermissionError from "./permissionError";


const PermissionContext = createContext('')
const usePermission = () => {
  return useContext(PermissionContext);
}

const PermissionProvider = memo(({ children, currentFirstPath = null}) => {
  const {themeMode} = useSetting();
  // Displaying error
  const {ccGetError} = useError();
  const {fetchProfile,isProfile, profile} = useAuth();
  const {currentLastPath, currentFullPath} = useCurrentPages()
  const [permissionDataset, setPermissionDataset] = useState([]);
  const [profileId, setProfileId] = useState(0);

  // const fetchDatas = useCallback(async () => {
  //   try {
  //     const response = await axiosInstance.get("/auth/profile");
  //     setProfile(response.data.profile); // Update profile
  //   } catch (error) {
  //     console.log("Error fetching profile:", error);
  //   }
  // }, []);

  useEffect(() => {
    const fetchDatas = async () => {
      try {
        // const response = await axiosInstance.get("/auth/profile");
        const response = await fetchProfile();
        if (response?.data?.status === 'success') {
          setPermissionDataset(response?.data?.permissionDataset);
          setProfileId(response?.data?.profile?.id);
        }
      } catch (error) {
        console.log = () => {}; // Suppress error temporarily
        console.log("Error fetching profile of permission context:", error);
      }
    }
    fetchDatas();
  }, [currentFirstPath]);

  // useEffect(() => {
  //   if (profile?.roles) {
  //     const tmp = profile.roles.map(role => 
  //       role.permissions.filter(permission => permission.model === 'RoleBarChart')
  //     );
  //     setIsRoleBarChart(tmp);
  //   }
  // }, [profile]);

  // Permission check functions
  // const generalPermissionChk = () =>
  //   permissionDataset.some(
  //     (p) =>
  //       p.model === currentFirstPath &&
  //       Number(p.create) === 0 &&
  //       Number(p.update) === 0 &&
  //       Number(p.delete) === 0
  //   ) &&
  //   (currentFirstPath === currentLastPath ||
  //     `${currentFirstPath}/list` === currentFullPath ||
  //     "list" === currentLastPath ||
  //     currentFullPath.includes("list"));

  const generalPermissionChk = () => {
    // By default all view if only role + model but no action set.
    const generalChk = !isEmptyUniversalCheck(permissionDataset) && permissionDataset?.some(
      p=>p.model === currentFirstPath && 
      Number(p.create) === 0 && 
      Number(p.update) === 0 && 
      Number(p.delete) === 0
    );

    // By default all view if view path as usual 'list' or single path as model name (lowercase)
    const pathChk = currentFirstPath === currentLastPath || 
    `${currentFirstPath}/list` === currentFullPath || 
    'list' === currentLastPath || 
    currentFullPath.includes('list');

    // By default profile view if no permission set.
    const profileChk = currentFirstPath === 'profile' || currentLastPath === 'profile' || currentFullPath.includes('profile');
    
    // By default super admin to all access
    // Or, By default profile view access
    // Or, By default to view list or single path as model name if role + model but no action set
    if (
      generalChk && pathChk || 
      profileChk ||
      Number(profileId) === 1) {
      return true;
    } else {
      return false;
    }
  }

  // const permissionCreateChk = () =>
  //   permissionDataset.some(
  //     (p) => p.model === currentFirstPath && Number(p.create) === 1
  //   ) &&
  //   (`${currentFirstPath}/create` === currentFullPath ||
  //     "create" === currentLastPath ||
  //     currentFullPath.includes("create")
  //   ) || 
  //   (`${currentFirstPath}/list` === currentFullPath ||
  //     "list" === currentLastPath ||
  //     currentFullPath.includes("list"));

  const permissionCreateChk = () => {
    const createChk = !isEmptyUniversalCheck(permissionDataset) && permissionDataset?.some(
      p=>p.model === currentFirstPath && 
      Number(p.create) === 1
    );

    const pathChk = `${currentFirstPath}/create` === currentFullPath || 
    'create' === currentLastPath || 
    currentFullPath.includes('create');

    const listPathChk = `${currentFirstPath}/list` === currentFullPath || 
    'list' === currentLastPath || 
    currentFullPath.includes('list');

    const lastFirstPathChk = currentFirstPath === currentLastPath;

    // Exclude profile though it has no create (create as a user) only update.
    const profileChk = currentFirstPath != 'profile' || currentLastPath != 'profile' || !currentFullPath.includes('profile');

    if ((createChk && (pathChk || listPathChk || lastFirstPathChk) && profileChk) ||
      (Number(profileId) === 1)) {
      return true;
    } else {
      return false;
    }
  }

  // const permissionEditUpdateChk = () =>
  //   permissionDataset.some(
  //     (p) => p.model === currentFirstPath && Number(p.update) === 1
  //   ) &&
  //   (`${currentFirstPath}/edit` === currentFullPath ||
  //     "edit" === currentLastPath ||
  //     currentFullPath.includes("edit")
  //   ) || 
  //   (`${currentFirstPath}/list` === currentFullPath ||
  //     "list" === currentLastPath ||
  //     currentFullPath.includes("list"));

  const permissionEditUpdateChk = () => {
    const editUpdateChk = !isEmptyUniversalCheck(permissionDataset) && permissionDataset?.some(
      p=>p.model === currentFirstPath && 
      Number(p.update) === 1
    );

    const pathChk = `${currentFirstPath}/edit` === currentFullPath || 
    'edit' === currentLastPath || 
    currentFullPath.includes('edit');

    const listPathChk = `${currentFirstPath}/list` === currentFullPath || 
    'list' === currentLastPath || 
    currentFullPath.includes('list');

    const lastFirstPathChk = currentFirstPath === currentLastPath;

    if ((editUpdateChk && (pathChk || listPathChk || lastFirstPathChk)) || 
      (Number(profileId) === 1)) {
      return true;
    } else {
      return false;
    }
  }
  
  const permissionDeleteChk = () => {
    const deleteChk = !isEmptyUniversalCheck(permissionDataset) && permissionDataset?.some(
      p=>p.model === currentFirstPath && 
      Number(p.delete) === 1
    );

    const listPathChk = `${currentFirstPath}/list` === currentFullPath || 
    'list' === currentLastPath || 
    currentFullPath.includes('list');

    const lastFirstPathChk = currentFirstPath === currentLastPath;

    if ((deleteChk && (listPathChk || lastFirstPathChk)) || 
      (Number(profileId) === 1)) {
      return true;
    } else {
      return false;
    }
  }

  // Render based on permissions
  const renderContent = () => {
    const allowedNext = children;

    const allowedBlock = <PermissionError>Permission restricted, Access denied.</PermissionError>

    const allowedNonBlock = "";

    if (Number(profileId) === 1 || permissionCreateChk() || permissionEditUpdateChk() || generalPermissionChk() || permissionDeleteChk()) {
      return allowedNext;
    }

    return allowedBlock;
  };

  // const allowedNext = (<Box>{children}</Box>)
  // const allowedBlock = (
  //   <Stack 
  //     direction="column" 
  //     justifyContent="center" 
  //     alignItems="center" 
  //     sx={{ textAlign: 'center' }}
  //     spacing={{
  //       xs: ccGap1,
  //       sm: ccGap1,
  //       md: ccGap2,
  //       xl: ccGap2,
  //       lg: ccGap2,
  //     }}
  //   >
  //     <Alert 
  //       variant="filled" 
  //       severity="error" 
  //       sx={{
  //         alignSelf: 'stretch', 
  //         display: 'flex', // Ensure flex layout for internal content
  //         justifyContent: 'center', // Center items horizontally
  //         alignItems: 'center', // Center items vertically
  //         textAlign: 'center', // Center text alignment
  //         backgroundColor: themeMode?.ccError1, // Set custom background color

  //       }}
  //     >
  //       <Typography variant="subtitle1">
  //         Permission restricted, Access denied.
  //       </Typography>
  //     </Alert>
  //   </Stack>
  // )
  // const allowedNonBlock = '';

  // if (Number(profileId) === 1) {
  //   return allowedNext;

  // } else if (permissionCreateChk()) {
  //   return allowedNext;

  // } else if (permissionEditUpdateChk()) {
  //   return allowedNext;

  // } else if (generalPermissionChk()) {
  //   return allowedNext;

  // } else {
  //   if (allowedOption==='') {
  //     return allowedNonBlock;
  //   } else {
  //     return allowedBlock;
  //   }
  // }

  const contextValue = {
    profileId,
    generalPermissionChk,
    permissionCreateChk,
    permissionEditUpdateChk,
    permissionDeleteChk,
  };

  return (
    <PermissionContext.Provider value={contextValue}>
      {renderContent()}
    </PermissionContext.Provider>
  )
});

export {PermissionProvider, usePermission};

import React, {useEffect, useState, useCallback, useMemo, memo } from "react"

import {Box} from '@mui/material';
import SaveAsTwoToneIcon from '@mui/icons-material/SaveAsTwoTone';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import { CCMuiCircularLoader } from "components/mui-customizations/ccMuiCircularLoader";
import CCMuiButton from "components/mui-customizations/ccMuiButton";
import {CCMuiDividerHorizontal} from "components/mui-customizations/ccMuiDivider";

import { useSetting } from "settings/settingContext";
import { useError } from "errors/errorHook";
import { usePermission } from "components/permissions/permissionContext";
import wordsUpperCase from "utilities/wordsUpperCase";
import axiosInstance from "plugins/axiosInstance";
import isEmptyUniversalCheck from "utilities/isEmptyUniversalCheck";
import PermissionFields from "./permissionFields";

import { swalLWithZIndexAlert } from "components/swal-customizations/styleCustomization";

import {v4 as uuidv4} from 'uuid';


const v4Uuid = uuidv4();

// Init permission states
const initPermissionStates = [{
  id: '',
  uuid: v4Uuid,
  role_id: "",
  model: "",
  user_id: [],
  create: false,
  update: false,
  delete: false,
  title: "",
  note: "",
}]

// Init permission states
const initErrors = [{
  uuid: v4Uuid,
  user_id: '',
  role_id: '',
  model: "",
}]

const CreateEditForm = memo(() => {
  const {themeMode} = useSetting();
  const {ccGetError} = useError();
  const {permissionCreateChk, permissionEditUpdateChk} = usePermission();

  const [permissionStates, setPermissionStates] = useState([]);
  const [errorStates, setErrorStates] = useState(initErrors);
  const [loading, setLoading] = useState(false);
  const [models, setModels] = useState([]);

  const handleAddPermission = () => {
    const v4Uuid = uuidv4();
    setPermissionStates((prev) => [
      {
        id: '',
        uuid: v4Uuid,
        title: "",
        note: "",
        create: false,
        update: false,
        delete: false,
        role_id: "",
        model: "",
        user_id: [],
      },
      ...(prev || []),
    ]);

    setErrorStates((prev) => [
      {
        uuid: v4Uuid,
        user_id: '',
        role_id: '',
        model: "",
      },
      ...(prev || []),
    ]);
  };

  const handleRemoveExceptNew = () => {
    const filteredPermissions = permissionStates?.filter((item) =>
      isEmptyUniversalCheck(item.id)
    );
    const permissionUuids = filteredPermissions?.map((item) => item.uuid);

    setPermissionStates(filteredPermissions);
    setErrorStates((prevErrors) =>
      prevErrors?.filter((item) => permissionUuids.includes(item.uuid))
    );

    // Log for debugging
    // console.log('Filtered Permissions:', filteredPermissions);
    // console.log('Updated Error States:', errorStates);
  };

  const handleEditPermission = useCallback(async (uuid) => {
    // Fetch errors if any otherwise triggering to submit
    const findError = [...errorStates];
    const locateError = findError.find(item=>item.uuid === uuid);

    if (Object.keys(locateError).filter(key => key != 'uuid' && locateError[key]).length > 0) {
      await ccGetError({errors: locateError});
      setLoading(false)

    } else {
      try {
        const findPermission = [...permissionStates];
        const locatePermission = findPermission.find(item=>item.uuid === uuid);
        // console.log('masudpermission', locatePermission)
        const result = await axiosInstance.put(`/permissions/${locatePermission.id}`, locatePermission)
        if(result && result.data && result.data.status === "success") {
          swalLWithZIndexAlert.fire({
            title: `${wordsUpperCase(result.data.status)}!`, 
            text: result.data.message, 
            icon: "success",
            iconColor: themeMode?.ccGlow4,
            color: themeMode?.ccGlow4,
            confirmButtonColor: themeMode?.ccGlow4,
            background: themeMode?.ccGlow1,
            timer: 1500,
          }).then(async () => {
            await refreshDatas();
          });
        }
      } catch (error) {
        await ccGetError(error)
      }
    }
  }, [permissionStates, errorStates, ccGetError])

  const handleCreatePermission = useCallback(async (uuid) => {
    // Fetch errors if any otherwise triggering to submit
    const findError = [...errorStates];
    const locateError = findError.find(item=>item.uuid === uuid);

    if (Object.keys(locateError).filter(key => key != 'uuid' && locateError[key]).length > 0) {
      await ccGetError({errors: locateError});
      setLoading(false);

    } else {
      try {
        const findPermission = [...permissionStates];
        const locatePermission = findPermission.find(item=>item.uuid === uuid);
        // console.log('masudpermission', locatePermission)
        const result = await axiosInstance.post('/permissions', locatePermission)
        if(result && result.data && result.data.status === "success") {
          swalLWithZIndexAlert.fire({
            title: `${wordsUpperCase(result.data.status)}!`, 
            text: result.data.message, 
            icon: "success",
            iconColor: themeMode?.ccGlow4,
            color: themeMode?.ccGlow4,
            confirmButtonColor: themeMode?.ccGlow4,
            background: themeMode?.ccGlow1,
            timer: 1500,
          }).then(async () => {
            await refreshDatas();
          });
        } else {
          await ccGetError(result)
        }
      } catch (error) {
        await ccGetError(error);
      }
    }
  }, [permissionStates, errorStates, ccGetError]);

  // const fetchDatas = useCallback(async () => {
  //   setLoading(true);
  //   try {
  //     const fetchOperations = [
  //       { name: "fetchAllUsers", promise: fetchAllUsers() },
  //       { name: "fetchAllRoles", promise: fetchAllRoles() },
  //       { name: "fetchProfile", promise: fetchProfile() },
  //       {
  //         name: "fetchPermissions",
  //         promise: axiosInstance.get("/permissions"),
  //       },
  //     ];

  //     const results = await Promise.allSettled(fetchOperations.map(op => op.promise));

  //     results.forEach((result, index) => {
  //       if (result.status === "fulfilled") {
  //         console.log(`${fetchOperations[index].name} succeeded:`, result.value);
  //       } else if (result.status === "rejected") {
  //         console.log(`${fetchOperations[index].name} failed:`, result.reason);
  //       }
  //     });

  //     const permissionsResult = results.find(
  //       (result, index) => fetchOperations[index].name === "fetchPermissions"
  //     );

  //     if (permissionsResult?.status === "fulfilled") {
  //       const { permissionModels, permissions } = permissionsResult.value.data;

  //       setModels(await permissionModels?.modelNames);
  //       setPermissionStates(
  //         permissions?.map((permission) => ({
  //           id: permission.id || "",
  //           uuid: permission.uuid || v4Uuid,
  //           role_id: permission.role_id || "",
  //           model: permission.model || "",
  //           user_id: permission.user_id || [],
  //           create: permission.create || false,
  //           update: permission.update || false,
  //           delete: permission.delete || false,
  //           title: permission.title || "",
  //           note: permission.note || "",
  //         }))
  //       );

  //       setErrorStates(
  //         permissions?.map((permission) => ({
  //           uuid: permission.uuid || v4Uuid,
  //           user_id: "",
  //           role_id: "",
  //           model: "",
  //         }))
  //       );

  //     } else if (permissionsResult?.status === "rejected") {
  //       console.log("Fetching permissions failed:", permissionsResult.reason);
  //     }
  //   } catch (error) {
  //     await ccGetError(error);
  //   } finally {
  //     setLoading(false);
  //   }
  // }, []);
  
  const refreshDatas = useCallback(async () => {
    setLoading(true);
    try {
      const fetchOperations = [
        {
          name: "fetchPermissions",
          promise: axiosInstance.get("/permissions"),
        },
      ];

      const results = await Promise.allSettled(fetchOperations.map(op => op.promise));

      results.forEach((result, index) => {
        if (result.status === "fulfilled") {
          console.log(`${fetchOperations[index].name} succeeded:`, result.value);
        } else if (result.status === "rejected") {
          console.log(`${fetchOperations[index].name} failed:`, result.reason);
        }
      });

      const permissionsResult = results.find(
        (result, index) => fetchOperations[index].name === "fetchPermissions"
      );

      if (permissionsResult?.status === "fulfilled") {
        const { permissionModels, permissions } = permissionsResult.value.data;

        setModels(await permissionModels?.modelNames);
        setPermissionStates(
          permissions?.map((permission) => ({
            id: permission.id || "",
            uuid: permission.uuid || v4Uuid,
            role_id: permission.role_id || "",
            model: permission.model || "",
            user_id: permission.user_id || [],
            create: permission.create || false,
            update: permission.update || false,
            delete: permission.delete || false,
            title: permission.title || "",
            note: permission.note || "",
            created_by_user: permission.created_by_user || "",
            updated_by_user: permission.updated_by_user || "",
          }))
        );

        setErrorStates(
          permissions?.map((permission) => ({
            uuid: permission.uuid || v4Uuid,
            user_id: "",
            role_id: "",
            model: "",
          }))
        );
      } else if (permissionsResult?.status === "rejected") {
        console.log("Fetching permissions failed:", permissionsResult.reason);
      }
    } catch (error) {
      await ccGetError(error);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleRefresh = useCallback(() => {
    refreshDatas();
  }, [refreshDatas]);

  useEffect(() => {
    refreshDatas();
  },[refreshDatas]);

  if (loading) {
    return (
      <Box width="100%">
        <CCMuiCircularLoader />
      </Box>
    )
  }

  return (
    <PermissionFields
      models={models}
      permissionStates={permissionStates}
      setPermissionStates={setPermissionStates}
      errorStates={errorStates}
      setErrorStates={setErrorStates}
      handleCreatePermission={handleCreatePermission}
      handleEditPermission={handleEditPermission}
    >
      <Box sx={{gridColumn: 'span 18'}}>
        {permissionCreateChk() &&
          <CCMuiButton 
            startIcon={<SaveAsTwoToneIcon />}
            sx={{ mb: 1, bgcolor: themeMode?.ccButtonBB}}
            onClick={handleAddPermission}
          >
            Add Permission
          </CCMuiButton>
        }   

        {permissionCreateChk() &&
          <CCMuiButton 
            startIcon={<CancelOutlinedIcon />}
            sx={{mb: 1, bgcolor: themeMode?.ccButtonEB}}
            onClick={handleRemoveExceptNew}
          >
            Remove Except New
          </CCMuiButton>
        }
        
        <CCMuiButton
          startIcon={<SaveAsTwoToneIcon />}
          onClick={handleRefresh}
          sx={{mb: 1, bgcolor: themeMode?.ccButtonGB, alignSelf: 'flex-end'}}
        >
          Refresh
        </CCMuiButton>

        <CCMuiDividerHorizontal
          sx={{ 
            pb:1,
            mb:2,
          }}
        />
      </Box>
    </PermissionFields>
  )
});

export default CreateEditForm;
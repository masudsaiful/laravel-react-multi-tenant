import * as React from 'react';

import { styled } from '@mui/material/styles';
import { tooltipClasses } from '@mui/material/Tooltip';
import { Tooltip, Divider, Box, Paper, List, ListItem, ListItemText } from '@mui/material';
import Typography from '@mui/material/Typography';

import { useSetting } from "settings/settingContext";


const HtmlTooltip = styled(({ className, themeMode, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme, themeMode }) => ({
  [`& .${tooltipClasses.arrow}`]: {
    color: `${themeMode?.ccTooltipBC}`,
  },
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: `${themeMode?.ccTooltipB}`,
    color: `${themeMode?.ccTooltipC}`,
    maxWidth: 220,
    // fontSize: theme.typography.pxToRem(12),
    border: `1px solid ${themeMode?.ccTooltipBC}`,
  },
}));

const CCMuiTooltip = ({content, title}) => {
  const {themeMode} = useSetting();

  const contentListItems = content && content?.map((item, indx)=>(
    <ListItem 
      alignItems="flex-start" 
      dense 
      disablePadding 
      disableGutters 

      key={item.id}
      sx={{
        borderBottom: (content.length -1 !== indx) 
        ? `1px solid ${themeMode?.ccTooltipBC}52`
        : 'none',
        py:0, 
        my:0
      }}
    >
      <ListItemText sx={{py:0, my:0}}>
        <Typography 
          variant="subtitle2" 
          sx={{
            py:0, 
            my:0
          }}
        >
          {(item?.title?? '') || (item?.name?? '') || (item?.value?? '')}
        </Typography>
      </ListItemText>
    </ListItem>
  ));

  const positionRef = React.useRef({
    x: 0,
    y: 0,
  });
  const popperRef = React.useRef(null);
  const areaRef = React.useRef(null);

  const handleMouseMove = async (event) => {
    positionRef.current = { x: event.clientX, y: event.clientY };

    if (await popperRef.current) {
      await popperRef.current.update();
    }
  };

  return (
    <HtmlTooltip
      themeMode={themeMode}
      // title={content.map(item=>item.title).join(', ')}
      title={
        <>
          <Typography 
            variant="button" 
            color={`${themeMode?.ccTooltipTC}`}
            // sx={{fontSize:'0.9rem'}}
          >
            {title}
          </Typography>
          <Divider />
          <List disablePadding>{contentListItems}</List>
        </>
      }
      placement="top-end"
      arrow
      slotProps={{
        popper: {
          popperRef,
          anchorEl: {
            getBoundingClientRect: () => {
              // if (areaRef.current) {
              //   const rect = areaRef.current.getBoundingClientRect().y;
              //   return new DOMRect(
              //     positionRef.current.x,
              //     rect,
              //     0,
              //     0
              //   );
              // }
              // return new DOMRect(0, 0, 0, 0);
              if (areaRef && areaRef.current) {
                return new DOMRect(
                  positionRef.current.x,
                  areaRef.current.getBoundingClientRect().y,
                  0,
                  0,
                );
              } else {
                return new DOMRect(
                  positionRef.current.x,
                  0,
                  0,
                  0,
                );
              }
            },
          },
        },
      }}
    >
      <Box
        sx={{
          display: 'inline-flex',
          flexDirection: 'row',
        }}
      >
        { content && content.length > 0 ?
          content.map(item => (
            <Paper
              key={item.id}
              ref={areaRef}
              onMouseMove={handleMouseMove}
              sx={{ 
                display: 'flex',
                alignSelf: 'center',
                justifyContent: 'center',
                flexGrow: 1,
                lineHeight: 'normal',
                bgcolor: `${themeMode?.ccSelectChipB}c7`, 
                color: `${themeMode?.ccSelectChipC}`,
                px: 1,
                py: 0,
                mr: 0.25,
                // fontSize: '0.75rem',
              }}
            >
              {(item?.title ?? '') || (item?.name ?? '') || (item?.value ?? '')}
            </Paper>
          )) :
          <Paper
            ref={areaRef}
            onMouseMove={handleMouseMove}
            sx={{ 
              display: 'flex',
              alignSelf: 'center',
              justifyContent: 'center',
              flexGrow: 1,
              lineHeight: 'normal',
              bgcolor: `${themeMode?.ccError1}c7`, 
              color: `${themeMode?.ccFontGlow1}`,
              px: 1,
              py: 0,
              mr: 0.25,
              // fontSize: '0.75rem',
            }}
          >
            Unavailable
          </Paper>
        }
      </Box>
    </HtmlTooltip>
  );
}


export default CCMuiTooltip;
import * as React from 'react';

import { alpha, styled } from '@mui/material/styles';
import Switch from '@mui/material/Switch';

import { useSetting } from 'settings/settingContext';


const CustomSwitch = styled(({ themeMode, ...rest }) => <Switch {...rest} />)(
  ({ theme, themeMode }) => ({
    '& .MuiSwitch-switchBase.Mui-checked': {
      color: `${themeMode?.ccGlow3}`,
      '&:hover': {
        backgroundColor: `${themeMode?.ccGlow1}50`,
      },
    },
    '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
      backgroundColor: `${themeMode?.ccGlow1}`,
    },
  })
);


const CCMuiSwitch = (props) => {
  const {themeMode} = useSetting();

  const { checked, onChange } = props;
  // const [switchState, setSwitchState] = React.useState(checked);

  // Local handler inside CCMuiSwitch
  // const handleSwitchChange = (event) => {
  //   const newMode = event.target.checked;
  //   setSwitchState(newMode);
  //   onChange(event);
  // };

  return (
    <div>
      <CustomSwitch
        checked={checked}
        onChange={onChange}
        inputProps={{ 'aria-label': 'CC Mui Theme Mode Switch' }}
        size="small"
        themeMode={themeMode}
      />
      {/* Render ThemeModeSetting and pass the mode as a prop */}
      {/* <ThemeModeSetting mode={themeMode} /> */}
    </div>
  );
};

export default CCMuiSwitch;

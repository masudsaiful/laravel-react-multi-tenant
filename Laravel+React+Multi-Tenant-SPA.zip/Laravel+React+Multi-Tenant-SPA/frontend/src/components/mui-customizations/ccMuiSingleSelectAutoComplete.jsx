import { Box, Chip, memo, useCallback, useEffect, useState } from 'react';

import { MenuItem, Select } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import CCMuiTooltip from 'components/mui-customizations/ccMuiTooltip';

import { useSetting } from "settings/settingContext";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function getStyles(currentItemValue, selectedItemsValue, theme, themeMode) {
  return {
    fontWeight:
      [selectedItemsValue].indexOf(currentItemValue) === -1
        ? 'inherit'
        : 700,
    backgroundColor:
      [selectedItemsValue].indexOf(currentItemValue) !== -1 
        && `${themeMode?.ccSelectSB}3d`,
  };
}

const CCMuiSingleSelectAutoComplete = memo(({ value, items = [], ...props }) => {
  const { themeMode } = useSetting();
  const theme = useTheme();
  const [selectedValue, setSelectedValue] = useState(value);

  // Sync state with props to handle nested updates correctly
  useEffect(() => {
    setSelectedValue(value);
  }, [value]);

  const ccSingleSelectStyle = useCallback((props, themeMode) => {
    return {
      '&.MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': {
        borderColor: `${themeMode?.ccSelectOC}`,
        color: `${themeMode?.ccSelectC}`,
      },
      '&.MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
        borderColor: themeMode?.ccSelectHLC,
        color: themeMode?.ccSelectHLC,
      },
      label: {
        color: themeMode?.ccSelectLC,
        "&:hover": {
          color: themeMode?.ccSelectHLC + "!important",
        },
      },
      '& .MuiChip-root': {
        backgroundColor: themeMode?.ccSelectChipB,
        color: themeMode?.ccSelectChipC,
      },
      ...props.sx,
    };
  }, [props.sx]);

  const renderValue = (selected) => (
    <>
    <CCMuiTooltip
      content={
        items.filter(
          itemValue => itemValue.id === (Number(selected) || String(selected))
        ) || []
      }
      title="Selected item(s)"
    />
    </>
  );

  const handleChange = (event) => {
    setSelectedValue(event.target.value);
    if (props.onChange) {
      props.onChange(event); // Call parent's onChange if provided
    }
  };

  return (
    <Select
      {...props}
      value={selectedValue}
      onChange={handleChange}
      renderValue={renderValue}
      MenuProps={MenuProps}
      sx={ccSingleSelectStyle(props, themeMode)}
    >
      {props.placeholder && (
        <MenuItem disabled value="" sx={{ color: 'green' }}>
          <em>{props.placeholder}</em>
        </MenuItem>
      )}
      {items.map((currentItem) => (
        <MenuItem
          key={`${currentItem.id}-${currentItem.value}`}
          value={currentItem.id}
          style={getStyles(currentItem.id, selectedValue, theme, themeMode)}
        >
          {currentItem.label} ({currentItem.value})
        </MenuItem>
      ))}
      {props.children}
    </Select>
  );
});

export default CCMuiSingleSelectAutoComplete;

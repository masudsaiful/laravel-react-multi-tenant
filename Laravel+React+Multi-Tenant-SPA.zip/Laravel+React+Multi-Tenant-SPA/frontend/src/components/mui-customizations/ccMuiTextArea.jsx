import {
  TextField, 
} from "@mui/material";

import { useAuth } from "auths/hooks/authHook";
import { useSetting } from "settings/settingContext";
import { authThemeMode } from "./styleCustomization";

import merge from 'lodash/merge';


const ccMuiTextFieldStyle = (switchMode, props) => {
  return merge({}, 
    {
      "& .MuiOutlinedInput-root": { 
        // Default outline styles
        "& .MuiOutlinedInput-notchedOutline": {
          borderColor: `${switchMode?.ccTextFieldOC}`,
        },
        // Hover outline styles
        "&:hover .MuiOutlinedInput-notchedOutline": {
          borderColor: `${switchMode?.ccTextFieldHOC}`,
        },
        // Focused outline styles (applies to password fields as well)
        "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
          borderColor: `${switchMode?.ccTextFieldFOC} !important`,
        },
      },
      // Targets the input label
      "& .MuiInputLabel-root": { 
        color: `${switchMode?.ccTextFieldLC}`,
        // Hover color for the label
        "&:hover": {
          color: `${switchMode?.ccTextFieldHLC}`, 
        },
        // Focused color for the label
        "&.Mui-focused": {
          color: `${switchMode?.ccTextFieldFLC} !important`, 
        },
      },
      "& .MuiFormHelperText-root": {
        margin: 0,
        color: `${switchMode?.ccTextFieldEC}`,
      },
    },
    // {
    //   fieldset: {
    //     borderColor: `${themeMode?.ccTree1}!important`,
    //     color: `${themeMode?.ccTree1}!important`,
    //   },
    //   label: {
    //     color: `${themeMode?.ccTree1}`,
    //     "&:hover": {
    //       color: `${themeMode?.ccGlow4}!important`,
    //     },
    //   },
    //   "& .MuiFormHelperText-root": {
    //     margin: 0,
    //     color: `${authThemeMode?.ccError2}`,
    //   }
    // },
    props?.sx || {} // Merge in custom styles from props
  )
};

const CCMuiTextArea = ({endAdornment, ...props}) => {
  const {isProfile} = useAuth();
  const {themeMode} = useSetting()
  const switchMode = isProfile ? themeMode : authThemeMode

  return (
    <TextField
      size="small"
      fullWidth
      multiline
      maxRows={3}
      InputProps={{
        ...props.InputProps,
        endAdornment: endAdornment,
      }}
      onChange={props.onChange}
      sx={ccMuiTextFieldStyle(switchMode, props)}
      {...props}
    >
      {props.children}
    </TextField>
  );
};

export default CCMuiTextArea;




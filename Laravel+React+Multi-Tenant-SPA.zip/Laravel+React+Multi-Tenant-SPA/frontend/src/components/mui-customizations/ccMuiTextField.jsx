import {TextField} from "@mui/material";
import { authThemeMode } from "./styleCustomization";

import { useAuth } from "auths/hooks/authHook";
import { useSetting } from "settings/settingContext";

import merge from 'lodash/merge';


const ccMuiTextFieldStyle = (switchMode, props) => {
  // return merge({}, 
  //   {
  //     "& .MuiOutlinedInput-root": { 
  //       color: `${switchMode?.ccTextFieldC}`,
  //       // Default outline styles
  //       "& .MuiOutlinedInput-notchedOutline": {
  //         borderColor: `${switchMode?.ccTextFieldOC}`,
  //       },
  //       // Hover outline styles
  //       "&:hover .MuiOutlinedInput-notchedOutline": {
  //         borderColor: `${switchMode?.ccTextFieldHOC}`,
  //       },
  //       // Focused outline styles (applies to password fields as well)
  //       "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
  //         borderColor: `${switchMode?.ccTextFieldFOC} !important`,
  //       },
  //     },
  //     // Targets the input label
  //     "& .MuiInputLabel-root": { 
  //       color: `${switchMode?.ccTextFieldLC}`,
  //       // Hover color for the label
  //       "&:hover": {
  //         color: `${switchMode?.ccTextFieldHLC}`, 
  //       },
  //       // Focused color for the label
  //       "&.Mui-focused": {
  //         color: `${switchMode?.ccTextFieldFLC} !important`, 
  //       },
  //     },
  //     "& .MuiFormHelperText-root": {
  //       margin: '0 !important',
  //       color: `${switchMode?.ccTextFieldEC}`,
  //     },
  //     "& .MuiFormHelperText-root.Mui-error": {
  //       margin: "0 !important", // Ensures no margin for errors
  //       color: `${switchMode?.ccTextFieldEC} !important`, // Error color
  //     },
  //     "& .Mui-error .MuiOutlinedInput-notchedOutline": {
  //       borderColor: `${switchMode?.ccTextFieldEC} !important`,
  //     },
  //     "& .Mui-error .MuiInputLabel-root": {
  //       color: `${switchMode?.ccTextFieldEC} !important`,
  //     },
  //     "& .MuiFormControl-root": {
  //       "&.MuiFormHelperText-root": {
  //         margin: '0 !important',
  //         color: `${authThemeMode?.ccTextFieldEC} !important`,
  //       }
  //     }
  //   },
  //   // {
  //   //   fieldset: {
  //   //     borderColor: `${themeMode?.ccTree1}!important`,
  //   //     color: `${themeMode?.ccTree1}!important`,
  //   //   },
  //   //   label: {
  //   //     color: `${themeMode?.ccTree1}`,
  //   //     "&:hover": {
  //   //       color: `${themeMode?.ccGlow4}!important`,
  //   //     },
  //   //   },
  //   //   "& .MuiFormHelperText-root": {
  //   //     margin: 0,
  //   //     color: `${authThemeMode?.ccError2}`,
  //   //   }
  //   // },
  //   props?.sx || {} // Merge in custom styles from props
  // )
  return merge({}, {
    // Outlined Input (TextField Border)
    "& .MuiOutlinedInput-root": {
      color: `${switchMode?.ccTextFieldC}`, // Text color
      "& .MuiOutlinedInput-notchedOutline": {
        borderColor: `${switchMode?.ccTextFieldOC}`, // Default border color
      },
      "&:hover .MuiOutlinedInput-notchedOutline": {
        borderColor: `${switchMode?.ccTextFieldHOC}`, // Hover border color
      },
      "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
        borderColor: `${switchMode?.ccTextFieldFOC} !important`, // Focused border color
      },
      "&.Mui-error .MuiOutlinedInput-notchedOutline": {
        borderColor: `${switchMode?.ccTextFieldEC} !important`, // Error border color
      },
    },
  
    // Input Label
    "& .MuiInputLabel-root": {
      color: `${switchMode?.ccTextFieldLC}`, // Default label color
      "&:hover": {
        color: `${switchMode?.ccTextFieldHLC}`, // Hover label color
      },
      "&.Mui-focused": {
        color: `${switchMode?.ccTextFieldFLC} !important`, // Focused label color
      },
      "&.Mui-error": {
        color: `${switchMode?.ccTextFieldEC} !important`, // Error label color
      },
    },
  
    // FormHelperText (Error Text)
    "& .MuiFormHelperText-root": {
      margin: "0 !important", // Reset margin
      color: `${switchMode?.ccTextFieldEC}`, // Default helper text color
    },
    "& .MuiFormHelperText-root.Mui-error": {
      color: `${switchMode?.ccTextFieldEC} !important`, // Error text color
      margin: "0 !important", // Error text margin
    },
  
    // FormControl (Parent Container)
    "& .MuiFormControl-root": {
      gridColumn: "span 1", // Keep existing format
      "& .MuiFormHelperText-root": {
        margin: "0 !important", // Ensure no margin globally
        color: `${switchMode?.ccTextFieldEC} !important`,
      },
      "& .Mui-error .MuiOutlinedInput-notchedOutline": {
        borderColor: `${switchMode?.ccTextFieldEC} !important`, // FormControl error outline
      },
      "& .Mui-error .MuiInputLabel-root": {
        color: `${switchMode?.ccTextFieldEC} !important`, // FormControl error label
      },
    },
  
    // Merge custom styles from props if provided
    ...props?.sx || {},
  });
};

const CCMuiTextField = ({
  endAdornment,
  type = "text",          // Default value for type
  size = "small",         // Default size
  fullWidth = true,       // Default to fullWidth
  ...props
}) => {
  const {isProfile} = useAuth();
  const {themeMode} = useSetting()
  const switchMode = isProfile ? themeMode : authThemeMode

  return (
    <TextField
      type={type}          // Apply the default or passed type
      size={size}          // Default or passed size
      fullWidth={fullWidth} // Default or passed fullWidth
      InputProps={{
        ...props.InputProps,
        endAdornment: endAdornment,
      }}
      onChange={props.onChange}
      {...props}
      sx={ccMuiTextFieldStyle(switchMode, props)}
    >
      {props.children}
    </TextField>
  );
};

export default CCMuiTextField;




import { Box, Chip, MenuItem, Select } from '@mui/material';
import { useTheme } from '@mui/material/styles';

import { useSetting } from "settings/settingContext";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;

const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function getStyles(currentItemValue, selectedItemsValue, theme, themeMode) {
  return {
    fontWeight:
      selectedItemsValue.indexOf(currentItemValue) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
    backgroundColor:
      selectedItemsValue.indexOf(currentItemValue) !== -1 
        && `${themeMode?.ccSelectSB}3d!important`,
  };
}

// Utility for deep merging objects
const deepMerge = (target, source) => {
  for (const key in source) {
    if (
      source[key] instanceof Object &&
      key in target &&
      target[key] instanceof Object
    ) {
      Object.assign(source[key], deepMerge(target[key], source[key]));
    }
  }
  return { ...target, ...source };
};

const ccMultiSelectStyle = (props, themeMode) => {
  return deepMerge(
    {
      '&.MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': {
        borderColor: `${themeMode?.ccSelectOC}`,
        color: `${themeMode?.ccSelectC}`,
      },
      '&.MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
        borderColor: themeMode?.ccSelectHLC,
        color: themeMode?.ccSelectHLC,
      },
      label: {
        color: themeMode?.ccSelectLC,
        "&:hover": {
          color: themeMode?.ccSelectHLC + "!important",
        },
      },
      '& .MuiChip-root': {
        backgroundColor: themeMode?.ccSelectChipB,
        color: themeMode?.ccSelectChipC,
      },
    },
    props.sx || {}
  );
};

const CCMultiSelect = ({ ...props }) => {
  const { themeMode } = useSetting();
  const theme = useTheme();

  const renderValue = (selected) => (
    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
      {selected.map((selectedValue) =>
        props.items
          .filter((itemValue) => itemValue.id === selectedValue)
          .map((itemValue) => (
            <Chip
              key={itemValue.id}
              label={itemValue.value}
              sx={deepMerge({ height: "23px" }, props.chipSx || {})}
            />
          ))
      )}
    </Box>
  );

  return (
    <Select
      onChange={props.onChange}
      renderValue={renderValue}
      MenuProps={MenuProps}
      sx={ccMultiSelectStyle(props, themeMode)}
      {...props}
    >
      {props.placeholder && (
        <MenuItem disabled value="" sx={props.menuItemSx || {}}>
          <em>{props.placeholder}</em>
        </MenuItem>
      )}
      {props.items.map((currentItem) => (
        <MenuItem
          key={currentItem.id}
          value={currentItem.id}
          sx={deepMerge(getStyles(currentItem.id, props.value, theme, themeMode), props.menuItemSx || {})}
        >
          {currentItem.label} ({currentItem.value})
        </MenuItem>
      ))}
      {props.children}
    </Select>
  );
};

export default CCMultiSelect;

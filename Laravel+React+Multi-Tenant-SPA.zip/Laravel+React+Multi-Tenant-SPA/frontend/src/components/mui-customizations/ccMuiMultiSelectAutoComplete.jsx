import { memo, useCallback, useEffect, useState } from 'react';
import { MenuItem, Select } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import CCMuiTooltip from 'components/mui-customizations//ccMuiTooltip';

import { useSetting } from "settings/settingContext";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;

const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

function getStyles(currentItemValue, selectedItemsValue, theme, themeMode) {
  return {
    fontWeight:
      selectedItemsValue.indexOf(currentItemValue) === -1
        ? 'inherit'
        : 700,
    backgroundColor:
      selectedItemsValue.indexOf(currentItemValue) !== -1 
        && `${themeMode?.ccSelectSB}3d`,
  };
}

const CCMuiMultiSelectAutoComplete = memo(({ value: parentValue, ...props }) => {
  const { themeMode } = useSetting();
  const theme = useTheme();
  const [selectedValues, setSelectedValues] = useState(parentValue || []);

  // Sync with parent props
  useEffect(() => {
    if (JSON.stringify(selectedValues) !== JSON.stringify(parentValue)) {
      setSelectedValues(parentValue || []);
    }
  }, [parentValue]);

  const handleChange = (event) => {
    const newValue = event.target.value;
    setSelectedValues(newValue);
    if (props.onChange) {
      props.onChange(newValue);
    }
  };

  const ccMultiSelectStyle = useCallback((props, themeMode) => {
    return {
      '&.MuiOutlinedInput-root .MuiOutlinedInput-notchedOutline': {
        borderColor: `${themeMode?.ccSelectOC}`,
        color: `${themeMode?.ccSelectC}`,
      },
      '&.MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline': {
        borderColor: themeMode?.ccSelectHLC,
        color: themeMode?.ccSelectHLC,
      },
      label: {
        color: themeMode?.ccSelectLC,
        "&:hover": {
          color: themeMode?.ccSelectHLC + "!important",
        },
      },
      '& .MuiChip-root': {
        backgroundColor: themeMode?.ccSelectChipB,
        color: themeMode?.ccSelectChipC,
      },
      ...props.sx,
    };
  }, [props.sx]);

  const renderValue = (selected) => (
    <CCMuiTooltip
      content={
        props.items.filter(
          (filterItem) => selected.includes(filterItem.id)
        ) || []
      }
      title="Selected item(s)"
    />
  );

  return (
    <Select
      value={selectedValues}
      onChange={handleChange}
      renderValue={renderValue}
      MenuProps={MenuProps}
      sx={ccMultiSelectStyle(props, themeMode)}
      {...props}
    >
      {props.placeholder && (
        <MenuItem disabled value="" sx={{ color: 'green' }}>
          <em>{props.placeholder}</em>
        </MenuItem>
      )}
      {props.items.map((currentItem) => (
        <MenuItem
          key={`${currentItem.id}-${currentItem.value}`} // Ensure each MenuItem has a unique key
          value={currentItem.id}
          style={getStyles(currentItem.id, selectedValues, theme, themeMode)}
        >
          {currentItem.label} ({currentItem.value})
        </MenuItem>
      ))}
      {props.children}
    </Select>
  );
});

export default CCMuiMultiSelectAutoComplete;

import { CircularProgress, Box } from "@mui/material"

import { useAuth } from "auths/hooks/authHook";
import { useSetting } from "settings/settingContext";
import { authThemeMode } from "./styleCustomization";


const CCMuiCircularLoader = (props) => {
  const {isProfile} = useAuth();
  const {themeMode} = useSetting()
  const switchMode = isProfile ? themeMode : authThemeMode

  return (
    <Box
      display="flex"
      justifyContent="center"
      alignItems="center"
    >
      <CircularProgress
        {...props}
        sx={{
          color: `${switchMode?.ccGlow4}`,
          ...props.sx,
        }}
        style={{
          ...props.style,
        }}
      />
    </Box>
  );
};

// const CCMuiCircularLoader = (props) => {
//   const {themeMode} = useSetting();
//   return (
//     <Box
//       display="flex"
//       justifyContent="center"
//       alignItems="center"
//       bgcolor={themeMode?.ccDark3}
//       {...props}
//     >
//       <CircularProgress 
//         sx={{ 
//           color: themeMode?.ccGlow2,
//           ...props.sx
//         }} 
//       />
//     </Box>
//   )
// }

export {CCMuiCircularLoader};
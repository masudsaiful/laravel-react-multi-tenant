import React, {useState, useEffect} from 'react';
import {Box, Button} from '@mui/material';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';

import { useAuth } from 'auths/hooks/authHook';
import { useMessage } from 'messages/messageContext';
import isEmptyUniversalCheck from 'utilities/isEmptyUniversalCheck';


const CCMuiSnackBar = () => {
  const { isProfile } = useAuth();
  const { message, messageDispatch } = useMessage();

  const [state, setState] = useState({
    open: false,
    vertical: 'top',
    horizontal: 'right',
  });

  const [currentMessage, setCurrentMessage] = useState(null);

  const { vertical, horizontal, open } = state;

  const handleClick = () => {
    setOpen(true);
  };

  const handleClose = async () => {
    setState({ ...state, open: false });
    await messageDispatch(null, null);
    setCurrentMessage(null);
  };

  useEffect(() => {
    const newMessage = message?.find((msg) => msg.success) || null;
    if (newMessage !== currentMessage) {
      setCurrentMessage(newMessage);
      setState({ ...state, open: !isEmptyUniversalCheck(newMessage) });
    }
  }, [message]);

  // const currentMessage = message?.find((msg) => msg.success) || null;

  return (
    <>
      {
        !isEmptyUniversalCheck(currentMessage) ?
          <Box sx={{ width: 500 }}>
            <Snackbar 
              open={open} 
              anchorOrigin={{ vertical, horizontal }} 
              autoHideDuration={2000} 
              onClose={handleClose}
              // message="I love snacks"
              key={vertical + horizontal}
            >
              <Alert
                onClose={handleClose}
                severity="success"
                variant="filled"
                sx={{ width: '100%' }}
              >
                {currentMessage?.success}
              </Alert>
            </Snackbar>
          </Box>
        : ''
      }
    </>
  );
}

export default CCMuiSnackBar;

import { useMemo } from "react";

import { Button } from "@mui/material";
import { AppRegistration } from "@mui/icons-material";

import { useAuth } from "auths/hooks/authHook";
import { useSetting } from "settings/settingContext";
import { authThemeMode } from "./styleCustomization";

import { merge } from "lodash";


// Deep merge for sx
const deepMergeStyleSx = (switchMode) => ({
  color: switchMode?.ccButtonC || "inherit",
  ":hover": {
    backgroundColor: switchMode?.ccButtonHB || "initial",
  },
  marginRight: '8px'
});

// Deep merge helper for inline styles
const deepMergeStyle = (defaultStyle, parentStyle) => merge({}, defaultStyle, parentStyle);

const CCMuiButton = ({ sx = {}, style = {}, ...props }) => {
  const { isProfile } = useAuth();
  const { themeMode } = useSetting();
  const switchMode = isProfile ? themeMode : authThemeMode;

  // Merge MUI sx styles deeply
  const mergedSx = useMemo(() => merge({}, deepMergeStyleSx(switchMode), sx), [switchMode, sx]);

  // Merge inline styles deeply
  const mergedStyle = useMemo(() => deepMergeStyle({}, style), [style]);

  return (
    <Button
      variant="contained"
      size="small"
      sx={mergedSx}
      style={mergedStyle} 
      {...props} 
    >
      {props.children}
    </Button>
  );
};

export default CCMuiButton;

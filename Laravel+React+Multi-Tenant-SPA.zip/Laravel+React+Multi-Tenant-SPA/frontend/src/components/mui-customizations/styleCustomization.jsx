import React, { forwardRef } from "react";
import { NavLink} from "react-router-dom";

import {
  Button,
  ToggleButton,
  Typography,
  Divider
} from "@mui/material";
import { createTheme } from '@mui/material/styles';
import { AppRegistration, Input } from "@mui/icons-material";
import FormatAlignJustifyIcon from "@mui/icons-material/FormatAlignJustify";
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';

import { useSetting } from "settings/settingContext";


const ccTheme = createTheme({
  typography: {
    fontFamily: 'Roboto, Arial, sans-serif',
    fontSize: 12, // Equivalent to 12px
  },
});

// CC All Used Colors
const lightThemeMode = {
  ccTransparent : 'transparent',

  ccMenuC: '#38393b', // Menu Color // Ash Black
  ccMenuB: '#dce9ff', // Menu Background // Fade Sky
  ccMenuHC: '#ffffff', // Menu Hover, Focus, Selected Color // White
  ccMenuHB1: '#b0d7ff', // Menu Hover, Focus, Selected Background // Sky
  ccMenuHB2: '#009dff', // Menu Hover, Focus, Selected Background // Blue
  ccMenuIC: '#009dff', // Menu Icon Color // Blue
  ccMenuTC: '#009dff', // Menu Typography Color // Blue
  ccMenuAC: '#009dff', // Menu Avatar Color // Blue
  ccMenuAB: '#b0d7ff', // Menu Abatar Background // Sky
  ccMenuCB: '#b0d7ff', // Menu Collapse Background // Sky
  ccMenuRC1: '#009dff', // Menu Ripple Color // Blue
  ccMenuRC2: '#ffffff', // Menu Ripple Color // White
  ccMenuTitleC: '#eff2f4', // Menu Title Color // Paper White
  ccMenuTitleB: '#4b656a', // Menu TItle Background // Metal

  ccButtonC: '#ffffff', // Button Color // White
  ccButtonBB: '#009dff', // Button Bluish Background // Blue
  ccButtonGB: '#008000', // Button Greenish Background // Tree Green
  ccButtonUB: '#3387ac', // Button Upload Background // Windows Blue
  ccButtonEB: '#9c27b0', // Button Error Background // Purple
  ccButtonDB: '#ff3c3c', // Button Delete Background // Red Orange
  ccButtonHB: '#536a8c', // Button Hover Background // Metal Light

  ccTextFieldC: '#38393b', // Text Field Color // Ash Black
  ccTextFieldOC: '#008000', // Text Field Outlined Color // Tree Green
  ccTextFieldHOC: '#009dff', // Text Field Hover Outlined Color // Blue
  ccTextFieldFOC: '#009dff', // Text Field Focus Outlined Color // Blue
  ccTextFieldLC: '#008000', // Text Field Label Color // Tree Green
  ccTextFieldHLC: '#009dff', // Text Field Hover Label Color // Blue
  ccTextFieldFLC: '#009dff', // Text Field Focus Label Color // Blue
  ccTextFieldEC: '#ff3c3c', // Text Field Error Color // Red Orange

  ccSelectC: '#008000', // Select Text color // Tree Green
  ccSelectOC: '#008000', // Select Outlined color // Tree Green
  ccSelectLC: '#008000', // Select Label color // Tree Green
  ccSelectHLC: '#009dff', // Select Hover Label color // Blue
  ccSelectSB: '#4b656a', // Select Selected Background // Metal,
  ccSelectChipC: '#eff2f4', // Select Chip Text Color // Paper White
  ccSelectChipB: '#3387ac', // Select Chip Background // Windows Blue,

  ccTooltipC: '#2f4d78', // Tooltip Color // Metal Deep
  ccTooltipB: '#eff2f4', // Tooltip Background // Fade Sky
  ccTooltipBC: '#3387ac', // Tooltip Border Color // Windows Blue,
  ccTooltipTC: '#4b656a', // Tooltip Title Color // Metal

  ccFooterC: '#eff2f4', // Footer Color // Paper White
  ccFooterB: '#2f4d78', // Footer Background // Metal Deep

  ccFontGlow1: '#eff2f4', // Paper White
  ccFontGlow2 : '#dce9ff', // Fade Sky
  ccFontGlow3: '#b0d7ff', // Sky
  ccFontGlow4: '#009dff', // Blue
  ccFontDark: '#38393b', // Ash Black

  ccWhite: '#ffffff', // White
  ccGlow1 : '#eff2f4', // Paper White
  ccGlow2 : '#dce9ff', // Fade Sky
  ccGlow3: '#b0d7ff', // Sky
  ccGlow4 : '#009dff', // Blue
  ccGlow5: "#3387ac", // Windows Blue,
  ccDark1 : '#4b656a', // Metal
  ccDark2 : '#2f4d78', // // Metal Deep
  ccDark3 : '#536a8c', // Metal Light
  
  ccError1 : "#9c27b0", // Purple
  ccError2 : "#ff3c3c", // Red Orange
  ccError3 : "#fffe00", // Yellow
  ccTree1 : '#008000', // Tree Green
  ccTree2 : '#008000', // Tree Green
}

const darkThemeMode = {
  ccTransparent : 'transparent',

  ccMenuC: '#a2a9b3', // Menu Color
  ccMenuB: '#3c4148', // Menu Background
  ccMenuHC: '#ffffff', // Menu Hover Color
  ccMenuHB1: '#3c4148', // Menu Hover Background
  ccMenuHB2: '#009dff', // Menu Hover, Focus, Selected Background
  ccMenuIC: '#a2a9b3', // Menu Icon Color
  ccMenuTC: '#ffffff', // Menu Typography Color
  ccMenuAC: '#a2a9b3', // Menu Avatar Color
  ccMenuAB: '#3c4148', // Menu Abatar Background
  ccMenuCB: '#3c4148', // Menu Collapse Background
  ccMenuRC1: '#ffffff', // Menu Ripple Color
  ccMenuRC2: '#ffffff', // Menu Ripple Color // White
  ccMenuTitleC: '#dddddd', // Menu Title Color
  ccMenuTitleB: '#5b5653', // Menu TItle Background
  
  ccButtonC: '#a2a9b3', // Button Color
  ccButtonBB: '#1e4d6b', // Button Bluish Background
  ccButtonGB: '#1f681f', // Button Greenish Background
  ccButtonUB: '#1d5e55', // Button Upload Background
  ccButtonEB: '#611e6d', // Button Error Background
  ccButtonDB: '#712e2e', // Button Delete Background
  ccButtonHB: '#686868', // Button Hover Background

  ccTextFieldC: '#a2a9b3', // Text Field Color
  ccTextFieldOC: '#53904f', // Text Field Outlined Color
  ccTextFieldHOC: '#009dff', // Text Field Hover Outlined Color
  ccTextFieldFOC: '#009dff', // Text Field Focus Outlined Color
  ccTextFieldLC: '#53904f', // Text Field Label Color
  ccTextFieldHLC: '#009dff', // Text Field Hover Label Color
  ccTextFieldFLC: '#009dff', // Text Field Focus Label Color
  ccTextFieldEC: '#712e2e', // Text Field Error Color

  ccSelectC: '#394b39', // Select Text color
  ccSelectOC: '#53904f', // Select Outlined color
  ccSelectLC: '#53904f', // Select Label color
  ccSelectHLC: '#009dff', // Select Hover Label color
  ccSelectSB: '#4b656a', // Select Selected Background // Metal,
  ccSelectChipC: '#a2a9b3', // Select Chip Text Color
  ccSelectChipB: '#3c4148', // Select Chip Background

  ccTooltipC: '#2f4d78', // Tooltip Color // Metal Deep
  ccTooltipB: '#eff2f4', // Tooltip Background // Fade Sky
  ccTooltipBC: '#3387ac', // Tooltip Border Color // Windows Blue,
  ccTooltipTC: '#4b656a', // Tooltip Title Color // Metal

  ccFooterC: '#a2a9b3', // Footer Color
  ccFooterB: '#3c4148', // Footer Background

  ccFontGlow1: '#eff2f4', // Paper White
  ccFontGlow2 : '#dce9ff', // Fade Sky
  ccFontGlow3: '#b0d7ff', // Sky
  ccFontGlow4: '#009dff', // Blue
  ccFontDark: '#38393b', // Ash Black

  ccWhite: '#303233',
  ccGlow1 : '#222526', // Iceberg
  ccGlow2 : '#3c4148', // Lavender Mist
  ccGlow3: '#3c4148', // Sky
  ccGlow4 : '#009dff', // Bright Blue
  ccGlow5: "#63696c", // Windows Blue,
  ccDark1 : '#5b5653', // Glacier Blue
  ccDark2 : '#747474', // Dusk Blue
  ccDark3 : '#686868', // Metalic Blue

  ccError1: '#d500f9', // Purple
  ccError2 : "#712e2e", // Red Orange
  ccError3 : "#fffe00", // Yellow
  ccTree1 : '#394b39', // Tree Green
  ccTree2 : '#53904f', // Tree Green
}

const authThemeMode = {
  ccGlow1 : '#eff2f4', // Paper White
  ccGlow2 : '#dce9ff', // Fade Sky
  ccGlow3: '#b0d7ff', // Sky
  ccGlow4 : '#009dff', // Blue
  ccGlow5: "#3387ac", // Windows Blue,
  ccDark3 : '#536a8c', // Metal Light

  ccButtonC: '#ffffff', // Button Color
  ccButtonBB: '#009dff', // Button Bluish Background
  ccButtonGB: '#008000', // Button Greenish Background
  ccButtonHB: '#686868', // Button Hover Background

  ccTextFieldC: '#38393b', // Text Field Color // Ash Black
  ccTextFieldOC: '#008000', // Text Field Outlined Color // Tree Green
  ccTextFieldHOC: '#009dff', // Text Field Hover Outlined Color // Blue
  ccTextFieldFOC: '#009dff', // Text Field Focus Outlined Color // Blue
  ccTextFieldLC: '#008000', // Text Field Label Color // Tree Green
  ccTextFieldHLC: '#009dff', // Text Field Hover Label Color // Blue
  ccTextFieldFLC: '#009dff', // Text Field Focus Label Color // Blue
  ccTextFieldEC: '#ff3c3c', // Text Field Error Color // Red Orange
  
  ccTree1 : '#008000', // Tree Green
  ccTree2 : '#008000', // Tree Green

  ccError1 : "#9c27b0", // Purple
  ccError2 : "#ff3c3c", // Red Orange
  ccError3 : "#fffe00", // Yellow
}

const errorThemeMode = {
  ccGlow1 : '#e7edf0', // Iceberg
  ccError1 : "#4d2055", // Warm Purple
  ccError3 : "#fffe00", // Sunny Yellow
}

const ccDark3 = '#536a8c' // Charter Blue Color, Basically main background
const ccDark2 = '#2f4d78' // Yale Color, Basically top bar background
const ccGlow1 = '#e7edf0' // Basically section background
const ccGlow2 = '#dce9ff' // Creame White Color, Basically Box Area background
const ccGlow4 = '#009dff' // Pale Conflower Blue Color, Basically Large font color
const ccGlow3 = '#b0d7ff' // Dodger Blue Color, Basically sometimes font, large font, icons and button color
const ccTree1 = '#008000' // Green Color, Basically sometimes font, large font, icons and button color
const ccGreyBlue = '#8394ad' // Shadow Blue, Basically small font, icons, buttons etc.
const ccDark1 = '#7fafcc' // Particularly to use inside content and menu bar etc.
const ccError2 = "#ff3c3c" // Orangish color, basically for border.
const ccError3 = "#fffe00" // Yellowsh color, basically for alert title.
const ccError1 = "#9c27b0" // Purpelish + pinkish (MUI secondary color) basically error and error border.
const ccGlow5 = "#3387ac" // Windows Blue
// End CC All Used Colors





// CC All Commpon Gap
const ccGap1 = 1
const ccGap2 = 2
const ccGap2p5 = 2.5
const ccGap3 = 3
const ccGap4 = 4
// End CC All Common Gap




// CC MUI Typography
const CCTypographyAuthTitle = (props) => {
  const {themeMode} = useSetting();
  return (
    <Typography
      variant="h4"
      {...props}
      sx={{
        fontWeight: 500,
        color: themeMode?.ccGlow4,
        ...props.sx
      }}
    >
      {props.children}
    </Typography>
  );
};

// End CC MUI Typography

// const ccSmallButtonStyleGreen = (themeMode, props) => {
//   return {
//     color: themeMode?.ccFontGlow1,
//     bgcolor: themeMode?.ccTree1,
//     ":hover": {
//       backgroundColor: themeMode?.ccDark3,
//     },
//     marginLeft: "16px",
//     ...props.sx,
//   }
// };
// const CCSmallButtonGreen = (props) => {
//   const {themeMode} = useSetting();
//   return (
//     <Button
//       size="small"
//       variant="contained"
//       endIcon={<Input />}
//       {...props}
//       sx={ccSmallButtonStyleGreen(themeMode, props)}
//       onClick={props.onClick}
//     >
//       {props.children}
//     </Button>
//   );
// };
// End CC MUI Button

const CCToggleJustify = (props) => {
  return (
    <ToggleButton
      sx={{
        width: props.width,
        height: props.height,
        color: "#b0d7ff",
        borderColor: "#b0d7ff",
        ":hover": {
          backgroundColor: "#536a8c",
        },
      }}
      value="justify"
      aria-label="justified"
      onClick={props.onClick}
    >
      <FormatAlignJustifyIcon />
    </ToggleButton>
  );
};

const CCRouterNavLink = (props) => {
  const {themeMode} = useSetting();
  return (
    <NavLink 
      to={`/`}
      style={({ isActive, isPending, isTransitioning }) => {
        return {
          fontWeight: isActive ? "bold" : "",
          color: isPending ? `${themeMode?.ccFontGlow1}` : isTransitioning ? themeMode?.ccError2 : themeMode?.ccGlow4,
          textDecoration: 'none',
          ...props.style,
        };
      }}
      {...props}
    >
      {props.children}
    </NavLink>
  );
};




// CC MUI Divider
// const CCMuiDividerHorizontal = ({ sx = {}, style = {}, ...props }) => {
//   const { themeMode } = useSetting();

//   return (
//     <Divider
//       orientation="horizontal"
//       {...props}
//       sx={{
//         height: '1px',
//         paddingTop: '0px!important',
//         marginTop: '0px!important',
//         pb: {
//           xs: `${ccGap2 * 8}px!important`,
//           sm: `${ccGap2 * 8}px!important`,
//           md: `${ccGap2p5 * 8}px!important`,
//           lg: `${ccGap2p5 * 8}px!important`,
//           xl: `${ccGap2p5 * 8}px!important`,
//         },
//         mb: {
//           xs: `${ccGap2 * 8}px!important`,
//           sm: `${ccGap2 * 8}px!important`,
//           md: `${ccGap2p5 * 8}px!important`,
//           lg: `${ccGap2p5 * 8}px!important`,
//           xl: `${ccGap2p5 * 8}px!important`,
//         },
//         borderBottom: '1px',
//         borderBottomStyle: 'solid',
//         borderBottomColor: `${themeMode?.ccTree1}30`,
//         ...sx, // Merge and allow overriding with `sx` prop
//       }}
//       style={{
//         ...style, // Merge and allow overriding with `style` prop
//       }}
//     />
//   );
// };

// const CCMuiDividerHorizontal = (props) => {
//   const {themeMode} = useSetting();
//   return (
//     <Divider
//       orientation="horizontal"
//       {...props}
//       sx={{
//         height: '1px',
//         paddingTop: '0px!important',
//         marginTop: '0px!important',
//         pb: {
//           xs: `${ccGap2*8}px!important`,
//           sm: `${ccGap2*8}px!important`,
//           md: `${ccGap2p5*8}px!important`,
//           lg: `${ccGap2p5*8}px!important`,
//           xl: `${ccGap2p5*8}px!important`,
//         },
//         mb: {
//           xs: `${ccGap2*8}px!important`,
//           sm: `${ccGap2*8}px!important`,
//           md: `${ccGap2p5*8}px!important`,
//           lg: `${ccGap2p5*8}px!important`,
//           xl: `${ccGap2p5*8}px!important`,
//         },
//         borderBottom: "1px",
//         borderBottomStyle: 'solid',
//         borderBottomColor: `${themeMode?.ccTree1}30`,
//         ...props.sx,
//       }}
//     />
//   );
// };
// const CCDividerVertical = (props) => {
//   const {themeMode} = useSetting();
//   return (
//     <Divider
//       orientation="vertical"
//       variant="middle"
//       flexItem={true} // If true will correct height when used inside flex container
//       {...props}
//       sx={{
//         paddingRight: "8px",
//         borderRight: "1px",
//         borderStyle: "solid",
//         borderColor: `${themeMode?.ccGlow3}`,
//         marginRight: "8px",
//         ...props.sx,
//       }}
//     />
//   );
// };
// End CC MUI Divider





// CC MUI Paper
// const CCPaper = styled(Paper)(({ theme }) => ({
//   ...theme,
//   padding: theme.spacing(2),
//   textAlign: "center",
//   color: theme.palette.text.secondary,
// }));
// const CCPaperWithoutBottomPadding = styled(Paper)(({ theme }) => ({
//   ...theme,
//   backgroundColor: theme.palette.mode === "dark" ? "#1A2027" : "#dce9ff",
//   padding: "20px 20px 0 20px",
//   textAlign: "center",
//   color: theme.palette.text.secondary,
// }));

// const CCPaperHeaderWrapper = styled(Paper)(({ theme }) => ({
//   backgroundColor: "#b0d7ff",
//   ...theme.typography.body2,
//   borderRadius: 0,
// }));

// const CCPaperHeaderTop = styled(Paper)(({ theme }) => ({
//   backgroundColor: "#2f4d78",
//   ...theme.typography.body2,
//   textAlign: "center",
//   color: "#b0d7ff",
//   borderRadius: 0,
// }));

// const CCPaperHeaderBottom = styled(Paper)(({ theme }) => ({
//   backgroundColor: "transparent",
//   ...theme.typography.body2,
//   textAlign: "center",
//   color: theme.palette.text.secondary,
//   borderRadius: 0,
// }));
// End CC MUI Paper




export {
  ccTheme,
  CCTypographyAuthTitle,
  CCToggleJustify,
  CCRouterNavLink,
  lightThemeMode,
  darkThemeMode,
  authThemeMode,
  errorThemeMode,
  ccGap1,
  ccGap2,
  ccGap2p5,
  ccGap4,
};

import {Divider} from "@mui/material";
import { ccGap2 } from "./styleCustomization";
import { ccGap2p5 } from "./styleCustomization";
import { authThemeMode } from "./styleCustomization";

import { useSetting } from "settings/settingContext";
import { useAuth } from "auths/hooks/authHook";



const CCMuiDividerHorizontal = ({ sx = {}, style = {}, ...props }) => {
  const {isProfile} = useAuth();
  const {themeMode} = useSetting()
  const switchMode = isProfile ? themeMode : authThemeMode

  return (
    <Divider
      orientation="horizontal"
      {...props}
      sx={{
        height: '1px',
        paddingTop: '0px!important',
        marginTop: '0px!important',
        pb: {
          xs: `${ccGap2 * 6}px!important`,
          sm: `${ccGap2 * 6}px!important`,
          md: `${ccGap2p5 * 6}px!important`,
          lg: `${ccGap2p5 * 6}px!important`,
          xl: `${ccGap2p5 * 6}px!important`,
        },
        mb: {
          xs: `${ccGap2 * 8}px!important`,
          sm: `${ccGap2 * 8}px!important`,
          md: `${ccGap2p5 * 8}px!important`,
          lg: `${ccGap2p5 * 8}px!important`,
          xl: `${ccGap2p5 * 8}px!important`,
        },
        borderBottom: '1px',
        borderBottomStyle: 'solid',
        borderBottomColor: `${switchMode?.ccTree1}61`,
        ...sx, // Merge and allow overriding with `sx` prop
      }}
      style={{
        ...style, // Merge and allow overriding with `style` prop
      }}
    />
  );
};

const CCMuiDividerVertical = (props) => {
  const { themeMode } = useSetting();

  return (
    <Divider
      orientation="vertical"
      variant="middle"
      flexItem={true} // If true will correct height when used inside flex container
      {...props}
      sx={{
        // Default styles for `sx`
        paddingRight: "8px",
        borderRight: "1px",
        marginRight: "8px",
        borderStyle: "solid",
        borderColor: themeMode?.ccGlow3,
        ...props.sx, // Merge and override styles in `sx`
      }}
      style={{
        // Ensure inline `style` prop merging
        ...props.style,
      }}
    />
  );
};

export {CCMuiDividerHorizontal, CCMuiDividerVertical};

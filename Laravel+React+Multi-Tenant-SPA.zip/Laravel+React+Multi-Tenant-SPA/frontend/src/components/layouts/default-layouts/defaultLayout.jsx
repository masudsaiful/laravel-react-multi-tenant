import * as React from "react";

import { CCMuiCircularLoader } from "components/mui-customizations/ccMuiCircularLoader";
import {
  Container, 
  Grid, 
  Box, 
  CssBaseline, 
} from "@mui/material";
import { 
  ccGap2p5,
  ccGap2,
  ccGap4,
} from "components/mui-customizations/styleCustomization";

import { useAuth } from "auths/hooks/authHook";
import { useSetting } from "settings/settingContext";
import Content from "components/layouts/content";
import Footer from "components/layouts/footer";
import Header from "components/layouts/header";
import DefaultSidebar from "components/layouts/default-layouts/defaultSidebar";


// import "@fontsource/roboto/300.css";
// import "@fontsource/roboto/400.css";
// import "@fontsource/roboto/500.css";
// import "@fontsource/roboto/700.css";


const DefaultLayout = () => {
  const {themeMode} = useSetting();
  const {isProfile, profileLoading} = useAuth();

  if (profileLoading) {
    return (
      <>
        <CssBaseline />
        <CCMuiCircularLoader />
      </>
    );
  }
  
  return (
    <>
      <CssBaseline />
      <Container
        disableGutters
        maxWidth="false"
      >
        <Grid
          container
          minHeight="100vh"
          bgcolor={themeMode?.ccDark3}
        >
          {/* Header, Sidebar and Content, Footer */}
          <Grid
            item
            container
            direction='row'
            alignContent='flex-start'
            spacing={{
              xs: ccGap2p5,
              sm: ccGap2p5,
              md: ccGap2p5,
              xl: ccGap2p5,
              lg: ccGap2p5,
            }}
          >
            {/* Header */}
            {isProfile && (
              <Grid
                item
                xs={12}
                sm={12}
                md={12}
                lg={12}
                xl={12}
              >
                <Header />
              </Grid>
            )}
            {/* End header */}

            {/* Sidebar and Content */}
            <Grid
              item
              container
              xs={12}
              sm={12}
              md={12}
              lg={12}
              xl={12}
              mb={ccGap4}
            >
              {/* Sidebar */}
              {isProfile && (
                <Grid
                  item
                  pl={{ 
                    xs:0, 
                    sm: 0, 
                    md: ccGap2p5, 
                    lg: ccGap2p5, 
                    xl: ccGap2p5,
                  }}
                  xs={12}
                  sm={12}
                  md={3.5}
                  lg={3.5}
                  xl={2.5}
                >
                  <DefaultSidebar />
                </Grid>
              )}
              {/* End sidebar */}

              {/* Content */}
              <Grid
                item
                pr={{ 
                  xs:ccGap2,
                  sm: ccGap2p5, 
                  md: ccGap2p5, 
                  lg: ccGap2p5, 
                  xl: ccGap2p5,
                }}
                pl={{
                  xs:ccGap2,
                  sm: ccGap2p5,
                }}
                xs={12}
                sm={12}
                md={8.5}
                lg={8.5}
                xl={9.5}
              >
                <Content />
              </Grid>
              {/* End Content */}
            </Grid>
            {/* End sidebar and content */}

            {/* Footer */}
            {isProfile && (
              <Grid
                item
                xs
              >
                <Footer />
              </Grid>
            )}
            {/* End footer */}
          </Grid>
          {/* End Header, Sidebar and Content, Footer */}
        </Grid>
      </Container>
    </>
  );
};

export default DefaultLayout;

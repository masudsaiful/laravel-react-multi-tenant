import * as React from 'react';

import { styled } from '@mui/material/styles';
import {Box, Drawer, IconButton, Typography} from '@mui/material';
import FormatListBulletedIcon from '@mui/icons-material/FormatListBulleted';
import {CCMuiDividerHorizontal} from "components/mui-customizations/ccMuiDivider";
import { useSetting } from "settings/settingContext";
import Menu from "components/layouts/menu";



const drawerWidth = 210;

const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
  justifyContent: 'flex-end',
}));

const DefaultSidebar = () => {
  const {themeMode} = useSetting();

  // const theme = useTheme();
  const [open, setOpen] = React.useState(true);

  // const handleDrawerOpen = () => {
  //   setOpen(true);
  // };
  
  // const handleDrawerClose = () => {
  //   setOpen(false);
  // };

  return (
    <>
      <Box
        display="flex"
        flexDirection="column"
        height="100%"
        // borderRadius={2}
        // bgcolor={themeMode?.ccGlow1}
        // sx={{
        //   height: '100%'
        // }}
      >
        <Box
          flexGrow={1}
          // mb={ccGap4}
        >
          <Drawer
            sx={{
              width: 'unset',
              height: '100%',
              flexShrink: 0,
              '& .MuiDrawer-paper': {
                width: 'unset',
                boxSizing: 'border-box',
                position: 'unset',
                bgcolor: themeMode?.ccGlow1,
                borderRadius: 2,
              },
            }}
            variant="persistent"
            anchor="left"
            open={open}
          >
            <DrawerHeader
              sx={{
                display:'flex',
                flexDirection:'row',
                justifyContent:'flex-start',
                alignItems:'flex-end',
                minHeight: '48px!important',
              }}
            >
              <IconButton 
                // onClick={handleDrawerClose}
                sx={{
                  paddingTop: 0,
                  paddingBottom: 0,
                }}
              >
                <FormatListBulletedIcon /> 
                <Typography 
                  variant='h6'
                  pl={1}
                >
                  Default Sidebar Menu
                </Typography> 
              </IconButton>
            </DrawerHeader>

            <CCMuiDividerHorizontal sx={{mb: 'opx'}} />
            <Menu />
          </Drawer>
        </Box>
      </Box>
    </>
  );
};

export default DefaultSidebar;

import React from "react";

import { CCMuiCircularLoader } from "components/mui-customizations/ccMuiCircularLoader";

import { useAuth } from "auths/hooks/authHook";
import AuthRouterService from "router/services/authRouterService";
import NonAuthContent from "components/layouts/nonAuthContent";
import AuthContent from "components/layouts/authContent";
import { PermissionProvider } from "components/permissions/permissionContext";
import useCurrentPages from "./hooks/currentPagesHook";


const Content = () => {
  const {currentFirstPath} = useCurrentPages();

  // const isProfileLoader = useLoaderData(); // Loader data provided from router
  const { isProfile, profileLoading } = useAuth();

  if (profileLoading) {
    return (
      <CCMuiCircularLoader />
    );
  }

  const nonAuthOutlet = <PermissionProvider currentFirstPath={currentFirstPath}><NonAuthContent /></PermissionProvider>
  const authOutlet = <AuthContent />;

  return (
    <AuthRouterService 
      authOutlet={authOutlet} 
      nonAuthOutlet={nonAuthOutlet}
    />
  )
};

export default Content;
// export {loader};

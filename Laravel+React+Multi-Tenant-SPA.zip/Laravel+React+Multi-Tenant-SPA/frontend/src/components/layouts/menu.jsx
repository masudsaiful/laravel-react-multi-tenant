import * as React from 'react';
import { useNavigate } from "react-router-dom";

import {ExpandLess, ExpandMore} from '@mui/icons-material';
import {CCMuiDividerHorizontal} from "components/mui-customizations/ccMuiDivider";
import {
  Box, 
  List, 
  ListItem, 
  ListItemButton, 
  ListItemIcon, 
  ListItemText,
  Typography,
  ListSubheader,
  Collapse
} from '@mui/material';

import {
  userRouter, 
  roleRouter, 
  rootChildRouter,
  permissionRouter,
} from 'router/services/routerService';
import wordsUpperCase from 'utilities/wordsUpperCase';
import { useSetting } from "settings/settingContext";


const listSubheaderSx = themeMode => ({
  py:1,
  color: themeMode?.ccMenuTitleC,
  backgroundColor: `${themeMode?.ccMenuTitleB}f0`,
  '& .MuiTypography-root': ({
    textTransform: 'uppercase'
  })
});

const listSx = (themeMode) => ({
  '& .MuiListItem-root' : {
    color: `${themeMode?.ccMenuC}`,
    backgroundColor: `${themeMode?.ccMenuB}`,
  },
  // '& .MuiTypography-root' : {
  //   // fontSize: '.85rem',
  // },
  // '& .MuiSvgIcon-root' : {
  //   // fontSize: '1.15rem',
  // },
  '& .MuiListItemIcon-root' : {
    pr: 1,
    color: `${themeMode?.ccMenuC}`,
    minWidth: '24px'
  },
  '& .MuiListItemButton-root' : {
    paddingTop: '4px',
    paddingBottom: '4px',
    paddingLeft: '6px',
    paddingRight: '6px',
    '&.Mui-selected': {
      color: `${themeMode?.ccMenuHC}`,
      backgroundColor: `${themeMode?.ccMenuHB2}`,
      '& .MuiListItemIcon-root': {
        color: `${themeMode?.ccMenuHC}`,
      }
    },
    '&:hover, &:focus': {
      color: `${themeMode?.ccMenuHC}`,
      backgroundColor: `${themeMode?.ccMenuHB2}`,
      '& .MuiListItemIcon-root': {
        color: `${themeMode?.ccMenuHC}`,
      }
    },
    "& .MuiTouchRipple-child": {
      backgroundColor: `${themeMode?.ccMenuRC2}`,
    },
  },
  '& .MuiCollapse-root': {
    '.MuiListItem-root' : {
      backgroundColor: `${themeMode?.ccMenuCB}`,
    },
    '.MuiListItemButton-root': {
      paddingLeft: '16px',
    },
    '& .MuiCollapse-root .MuiListItemButton-root': {
      paddingLeft: '32px',
    },
  },
});

const Menu = () => {
  const {themeMode} = useSetting();
  
  const navigate = useNavigate()
  const [selectedIndex, setSelectedIndex] = React.useState('');
  const [selectedState, setSelectedState] = React.useState('');
  const [open2, setOpen2] = React.useState([]);

  const handleClick = (e, path) => {
    e.preventDefault();

    const p = path.split('/')
    setSelectedState(p);

    setSelectedIndex(path);

    setOpen2((prevOpen) =>
      prevOpen.includes(path) ? prevOpen.filter((item) => item !== path) : [...prevOpen, path]
    );
    navigate(`/${path}`)
  };
  const isOpen = (path) => open2.includes(path);

  return (
    <>
      <List 
        component="nav"
        aria-labelledby="nested-list-subheader"
        sx={{...listSx(themeMode), pb: 0}}
        subheader={
          <ListSubheader 
            component="div" 
            id="nested-list-subheader"
            sx={{
              ...listSubheaderSx(themeMode)
            }}
          >
            <Typography variant='subtitle1'>
              Admin Area Items
            </Typography>
          </ListSubheader>
        }
      >
        {rootChildRouter.map((text1, index1) => (
          wordsUpperCase(text1.path) !== 'Edit' && (
            <Box key={index1}>
              <ListItem 
                disablePadding
              >
                <ListItemButton 
                  selected={
                    selectedIndex === `${text1.path}` || 
                    selectedState.includes(`${text1.path}`
                  )}
                  onClick={e => handleClick(e, `${text1.path}`)}
                >
                  <ListItemIcon>
                    {text1.icon}
                  </ListItemIcon>

                  <ListItemText
                    primary={wordsUpperCase(text1.path)} 
                  />
                  {text1.children ? isOpen(`${text1.path}`) ? <ExpandLess /> : <ExpandMore /> : ''}
                </ListItemButton>
              </ListItem>
              {text1.children && (
                <Collapse 
                  in={isOpen(`${text1.path}`)} 
                  timeout="auto" 
                  unmountOnExit
                >
                  <List component="div" disablePadding>
                  {text1.children.map((text2, index2) => (
                    wordsUpperCase(text2.path) !== 'Edit' && (
                      <Box key={index2}>
                        <ListItem 
                          disablePadding
                        >
                          <ListItemButton 
                            selected={selectedIndex === `${text1.path}/${text2.path}`}
                            onClick={e => handleClick(e, `${text1.path}/${text2.path}`)}
                          >
                            <ListItemIcon>
                              {text2.icon}
                            </ListItemIcon>

                            <ListItemText
                              primary={wordsUpperCase(text2.path)} 
                            />
                            {text2.children ? isOpen(`${text1.path}/${text2.path}`) ? <ExpandLess /> : <ExpandMore /> : ''}
                          </ListItemButton>
                        </ListItem>
                        {text2.children && (
                          <Collapse 
                            in={isOpen(`${text1.path}/${text2.path}`)} 
                            timeout="auto" 
                            unmountOnExit
                          >
                            <List component="div" disablePadding>
                            {text2.children.map((text3, index3) => (
                              wordsUpperCase(text3.path) !== 'Edit' && (
                                <Box key={index3}>
                                  <ListItem 
                                    disablePadding
                                  >
                                    <ListItemButton 
                                      selected={selectedIndex === `${text1.path}/${text2.path}/${text3.path}`}
                                      onClick={e => handleClick(e, `${text1.path}/${text2.path}/${text3.path}`)}
                                    >
                                      <ListItemIcon>
                                        {text3.icon}
                                      </ListItemIcon>

                                      <ListItemText 
                                        primary={wordsUpperCase(text3.path)} 
                                      />
                                    </ListItemButton>
                                  </ListItem>
                                </Box>
                              )
                            ))}
                            </List>
                          </Collapse>
                        )}
                      </Box>
                    )
                  ))}
                  </List>
                </Collapse>
              )}
              <CCMuiDividerHorizontal sx={{mb:'opx',pb:'0px'}}/>
            </Box>
          )
        ))}
      </List>

      <List 
        component="nav"
        aria-labelledby="nested-list-subheader"
        sx={{...listSx(themeMode), pb: 0}}
        subheader={
          <ListSubheader 
            component="div" 
            id="nested-list-subheader"
            sx={{
              ...listSubheaderSx(themeMode)
            }}
          >
            <Typography variant='subtitle1'>User Area Items</Typography>
          </ListSubheader>
        }
      >
        {userRouter.map((text1, index1) => (
          wordsUpperCase(text1.path) !== 'Edit' && (
            <Box key={index1}>
              <ListItem 
                disablePadding
              >
                <ListItemButton 
                  selected={
                    selectedIndex === `${text1.path}` || 
                    selectedState.includes(`${text1.path}`
                  )}
                  onClick={e => handleClick(e, `${text1.path}`)}
                >
                  <ListItemIcon>
                    {text1.icon}
                  </ListItemIcon>

                  <ListItemText 
                    primary={wordsUpperCase(text1.path)} 
                  />
                  {text1.children ? isOpen(`${text1.path}`) ? <ExpandLess /> : <ExpandMore /> : ''}
                </ListItemButton>
              </ListItem>
              {text1.children && (
                <Collapse 
                  in={isOpen(`${text1.path}`)} 
                  timeout="auto" 
                  unmountOnExit
                >
                  <List component="div" disablePadding>
                  {text1.children.map((text2, index2) => (
                    wordsUpperCase(text2.path) !== 'Edit' && (
                      <Box key={index2}>
                        <ListItem 
                          disablePadding
                        >
                          <ListItemButton 
                            selected={selectedIndex === `${text1.path}/${text2.path}`}
                            onClick={e => handleClick(e, `${text1.path}/${text2.path}`)}
                          >
                            <ListItemIcon>
                              {text2.icon}
                            </ListItemIcon>

                            <ListItemText
                              primary={wordsUpperCase(text2.path)} 
                            />
                            {text2.children ? isOpen(`${text1.path}/${text2.path}`) ? <ExpandLess /> : <ExpandMore /> : ''}
                          </ListItemButton>
                        </ListItem>
                        {text2.children && (
                          <Collapse 
                            in={isOpen(`${text1.path}/${text2.path}`)} 
                            timeout="auto" 
                            unmountOnExit
                          >
                            <List component="div" disablePadding>
                            {text2.children.map((text3, index3) => (
                              wordsUpperCase(text3.path) !== 'Edit' && (
                                <Box key={index3}>
                                  <ListItem 
                                    disablePadding
                                  >
                                    <ListItemButton 
                                      selected={selectedIndex === `${text1.path}/${text2.path}/${text3.path}`}
                                      onClick={e => handleClick(e, `${text1.path}/${text2.path}/${text3.path}`)}
                                    >
                                      <ListItemIcon>
                                        {text3.icon}
                                      </ListItemIcon>
                                      <ListItemText 
                                        primary={wordsUpperCase(text3.path)} 
                                      />
                                    </ListItemButton>
                                  </ListItem>
                                </Box>
                              )
                            ))}
                            </List>
                          </Collapse>
                        )}
                      </Box>
                    )
                  ))}
                  </List>
                </Collapse>
              )}
              <CCMuiDividerHorizontal sx={{mb:'opx',pb:'0px'}}/>
            </Box>
          )
        ))}

        {roleRouter.map((text1, index1) => (
          wordsUpperCase(text1.path) !== 'Edit' && (
            <Box key={index1}>
              <ListItem 
                disablePadding
              >
                <ListItemButton 
                  selected={selectedIndex === `${text1.path}` || 
                    selectedState.includes(`${text1.path}`
                  )}
                  onClick={e => handleClick(e, `${text1.path}`)}
                >
                  <ListItemIcon>
                    {text1.icon}
                  </ListItemIcon>

                  <ListItemText 
                    primary={wordsUpperCase(text1.path)} 
                  />
                  {text1.children ? isOpen(`${text1.path}`) ? <ExpandLess /> : <ExpandMore /> : ''}
                </ListItemButton>
              </ListItem>
              {text1.children && (
                <Collapse 
                  in={isOpen(`${text1.path}`)} 
                  timeout="auto" 
                  unmountOnExit
                >
                  <List component="div" disablePadding>
                  {text1.children.map((text2, index2) => (
                    wordsUpperCase(text2.path) !== 'Edit' && (
                      <Box key={index2}>
                        <ListItem 
                          disablePadding
                        >
                          <ListItemButton 
                            selected={selectedIndex === `${text1.path}/${text2.path}`}
                            onClick={e => handleClick(e, `${text1.path}/${text2.path}`)}
                          >
                            <ListItemIcon>
                              {text2.icon}
                            </ListItemIcon>

                            <ListItemText 
                              primary={wordsUpperCase(text2.path)} 
                            />
                            {text2.children ? isOpen(`${text1.path}/${text2.path}`) ? <ExpandLess /> : <ExpandMore /> : ''}
                          </ListItemButton>
                        </ListItem>
                        {text2.children && (
                          <Collapse 
                            in={isOpen(`${text1.path}/${text2.path}`)} 
                            timeout="auto" 
                            unmountOnExit
                          >
                            <List component="div" disablePadding>
                            {text2.children.map((text3, index3) => (
                              wordsUpperCase(text3.path) !== 'Edit' && (
                                <Box key={index3}>
                                  <ListItem 
                                    disablePadding
                                  >
                                    <ListItemButton 
                                      selected={selectedIndex === `${text1.path}/${text2.path}/${text3.path}`}
                                      onClick={e => handleClick(e, `${text1.path}/${text2.path}/${text3.path}`)}
                                    >
                                      <ListItemIcon>
                                        {text3.icon}
                                      </ListItemIcon>

                                      <ListItemText 
                                        primary={wordsUpperCase(text3.path)} 
                                      />
                                    </ListItemButton>
                                  </ListItem>
                                </Box>
                              )
                            ))}
                            </List>
                          </Collapse>
                        )}
                      </Box>
                    )
                  ))}
                  </List>
                </Collapse>
              )}
              <CCMuiDividerHorizontal sx={{mb:'opx',pb:'0px'}}/>
            </Box>
          )
        ))}

        {permissionRouter.map((text1, index1) => (
          wordsUpperCase(text1.path) !== 'Edit' && (
            <Box key={index1}>
              <ListItem 
                disablePadding
              >
                <ListItemButton 
                  selected={selectedIndex === `${text1.path}`}
                  onClick={e => handleClick(e, `${text1.path}`)}
                >
                  <ListItemIcon>
                    {text1.icon}
                  </ListItemIcon>

                  <ListItemText 
                    primary={wordsUpperCase(text1.path)} 
                  />
                </ListItemButton>
              </ListItem>
            </Box>
          )
        ))};
      </List>
    </>
  );
}

export default Menu;





































































// import { Link } from "react-router-dom";

// const Menu = () => {
//   return (
//     <>
//       <div id="menu">
//         <h2>Menu Items</h2>
//         <nav>
//           <ul>
//             <li>
//               <Link to={`/`}>Home</Link>
//             </li>
//             <li>
//               <Link to={`/dashboard`}>Dashboard</Link>
//             </li>
//             <li>
//               <Link to={`/profile`}>Profile</Link>
//             </li>
//             <li>
//               <Link to={`/about`}>About</Link>
//             </li>
//           </ul>
//         </nav>
//       </div>
//     </>
//   );
// };

// export default Menu;

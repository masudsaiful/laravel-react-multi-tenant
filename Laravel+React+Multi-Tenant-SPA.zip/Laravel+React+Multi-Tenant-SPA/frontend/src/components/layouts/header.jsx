import * as React from "react";
import { Link as RouterLink, useNavigate } from 'react-router-dom';

import Link from '@mui/material/Link';
import { styled, alpha } from '@mui/material/styles';
import { Settings} from "@mui/icons-material";
import SearchIcon from '@mui/icons-material/Search';
import CCMuiSwitch from "components/mui-customizations/ccMuiSwitch";
import { CCMuiDividerVertical } from "components/mui-customizations/ccMuiDivider";
import {
  Grid,
  Box,
  Paper,
  Typography,
  IconButton,
  InputBase,
} from "@mui/material";
import {
  ccGap2p5,
  ccGap2,
} from "components/mui-customizations/styleCustomization";

import { useSetting } from "settings/settingContext";
import { useAuth } from "auths/hooks/authHook";
import { useMessage } from "messages/messageContext";
import { useError } from "errors/errorHook";
import ApplicationBar from "components/layouts/applicationBar";


// const pages = ["Products", "Pricing", "Blog"];
// const settings = ["Profile", "Account", "Dashboard", "Logout"];

const Search = styled('div')(({ theme, themeMode }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  // backgroundColor: alpha(theme.palette.common.white, 0.45),
  backgroundColor: themeMode?.ccGlow1,
  '&:hover': {
    // backgroundColor: alpha(theme.palette.common.white, 0.65),
    backgroundColor: themeMode?.ccGlow2,
  },
  marginLeft: 0,
  width: '100%',
  [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(1),
    width: 'auto',
  },
}));

const SearchIconWrapper = styled('div')(({ theme, themeMode }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: themeMode?.ccFontGlow4,
}));

const StyledInputBase = styled(InputBase)(({ theme, thememode }) => ({
  color: thememode?.ccFontDark,
  width: '100%',
  '& .MuiInputBase-input': {
    padding: '5px 8px 5px 0',
    // padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    [theme.breakpoints.up('sm')]: {
      width: '12ch',
      '&:focus': {
        width: '20ch',
      },
    },
  },
}));

const Header = (props) => {
  const { handleLogout } = useAuth();
  const {themeMode} = useSetting();
  const {messageDispatch} = useMessage();
  const {ccGetError} = useError();
  const navigate = useNavigate();

  // Theme mode switch changes settings
  const {themeModeSwitchStateUpdate, handleThemeModeSwitchSetting} = useSetting();
  const handleThemeModeSwitchChange = event => {
    handleThemeModeSwitchSetting(event.target.checked);
  }

  const handleLogoutClick = async (e) => {
    e.preventDefault();
    const response = await handleLogout();
  
    // Message display after successful logged out through message context
    if (response.status === 'success') {
      await messageDispatch(response.status, response.message);
      // After logout navigate to
      navigate("/auth/login");
    } else {
      await ccGetError(response);
    }
  };

  React.useEffect(() => {

  },[])

  return (
    <>
      <Paper 
        elevation={3}
        sx={{
          backgroundColor: themeMode?.ccGlow3,
          borderRadius: 0,
        }}
      >
        {/* Top Bar switch, settings, login */}
        <Paper 
          elevation={0}
          sx={{
            color: themeMode?.ccFontGlow3,
            backgroundColor: themeMode?.ccDark2,
            borderRadius: 0
          }}
        >
          <Box
            px={{
              xs: ccGap2,
              sm: ccGap2p5,
              md: ccGap2p5,
              xl: ccGap2p5,
              lg: ccGap2p5,
            }}
          > 
            <Box 
              display="flex" 
              direction="row" 
              justifyContent="flex-end" 
              alignItems="center" 
              py={0.3}
            >
              {/* Top bar switch */}
              <CCMuiSwitch
                checked={themeModeSwitchStateUpdate ?? true} 
                onChange={handleThemeModeSwitchChange}
                disabled={themeModeSwitchStateUpdate === null}
              />

              <CCMuiDividerVertical style={{height:'12px'}}/>

              {/* Top bar settings */}
              <IconButton
                size="small"
                sx={{
                  p:0,
                  '& svg': {
                    color: themeMode?.ccFontGlow3,
                    transition: '0.2s',
                    transform: 'translateX(0) rotate(0)',
                  },
                  '&:hover, &:focus': {
                    bgcolor: 'unset',
                    '& svg:last-of-type': {
                      right: 0,
                      opacity: 1,
                    },
                  },
                  '&::after': {
                    content: '""',
                    position: 'absolute',
                    height: '80%',
                    display: 'block',
                    left: 0,
                    width: '1px',
                    bgcolor: 'unset',
                  },
                }}
              >
                <Settings sx={{width: '20px'}} />
              </IconButton>

              {/* <Settings sx={{width: '20px'}} /> */}
              <CCMuiDividerVertical sx={{height:'12px'}}/>

              {/* Top bar login */}
              <Typography 
                variant="error" 
                m={0}
              >
                <Link 
                  component={RouterLink}
                  sx={{
                    color:`${themeMode?.ccFontGlow3}`,
                    textDecoration: 'none',
                    "&:hover": {
                      color:`${themeMode?.ccFontGlow3}d1`
                    }
                  }}
                  onClick={handleLogoutClick}
                >
                  Logout
                </Link>
              </Typography>
            </Box>
          </Box>
        </Paper>
        {/* End Top Bar */}

        {/* Bottom Bar */}
        <Paper 
          elevation={0}
          sx={{
            backgroundColor: `${themeMode?.ccTransparent}`,
            borderRadius: 0,
          }}
        >
          {/* Bottom Top Bar */}
          {/* <RoleProvider> */}
          <ApplicationBar />
          {/* </RoleProvider> */}
          {/* End Bottom Top Bar */}

          {/* Bottom Bottom Bar */}
          <Grid
            container
            px={{
              xs: ccGap2,
              sm: ccGap2p5,
              md: ccGap2p5,
              xl: ccGap2p5,
              lg: ccGap2p5,
            }}
            py={0.25}
          >
            <Grid 
              item 
              xs={12} 
              sm={12} 
              md={12} 
              lg={12} 
              xl={12}
            >
              <Box 
                display="flex" 
                flexDirection="row" 
                justifyContent="flex-end" 
                alignItems="center" 
                height="40px"
              >
                {props.children}
                <Search themeMode={themeMode}>
                  <SearchIconWrapper themeMode={themeMode}>
                    <SearchIcon />
                  </SearchIconWrapper>
                  <StyledInputBase
                    thememode={themeMode}
                    id="search"
                    placeholder="Search…"
                    inputProps={{ 
                      'aria-label': 'search' 
                    }}
                  />
                </Search>
              </Box>
            </Grid>
          </Grid>
          {/* End Bottom Bottom Bar */}
        </Paper>
        {/* End Bottom Bar */}
      </Paper>
    </>
  );
};

export default Header;

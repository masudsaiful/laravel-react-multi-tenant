import React from "react";
import { Outlet } from "react-router-dom";


const AuthContent = () => {
  return <Outlet />
};

export default AuthContent;
// export {loader};

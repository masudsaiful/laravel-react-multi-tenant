import {
  Box, 
  Paper, 
  Typography
} from "@mui/material"; // Grid version 1
// import Grid from "@mui/material/Unstable_Grid2"; // Grid version 2

import { useSetting } from "settings/settingContext";


const Footer = () => {
  const {themeMode} = useSetting();

  return (
    <>
      <Box
        sx={{
          position: 'fixed',
          bottom: 0,
          textAlign: 'center',
          width: "100%",
        }}
      >
        <Paper
          sx={{
            background: themeMode?.ccFooterB,
            width: '100%',
            color: themeMode?.ccFooterC,
            borderRadius:0
          }}
        >
          <Typography 
            variant="caption" 
          >
            &copy; Copy right @ <strong>Crystal Code</strong>. All rights reserved <strong>2024</strong>.
          </Typography>
        </Paper>
      </Box>
    </>
  );
};

export default Footer;

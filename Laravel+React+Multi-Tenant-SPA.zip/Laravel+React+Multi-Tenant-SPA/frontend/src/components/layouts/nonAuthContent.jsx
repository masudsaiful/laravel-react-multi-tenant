import React from "react";
import { Outlet, useNavigate } from "react-router-dom";

import {Box, Paper, Button} from "@mui/material";
import ListAltOutlinedIcon from '@mui/icons-material/ListAltOutlined';
import PlaylistAddOutlinedIcon from '@mui/icons-material/PlaylistAddOutlined';
import PersonAddOutlinedIcon from '@mui/icons-material/PersonAddOutlined';
import CCMuiButton from "components/mui-customizations/ccMuiButton";
import {CCMuiDividerHorizontal} from "components/mui-customizations/ccMuiDivider";
import { 
  ccGap2p5,
  ccGap2,
} from "components/mui-customizations/styleCustomization";

import { usePermission } from "components/permissions/permissionContext";
import { useSetting } from "settings/settingContext";
import CCBreadcrumbs from "components/layouts/breadcrumb";
import useCurrentPages from "components/layouts/hooks/currentPagesHook";


// const useContentLoader = async () => {
//   const { isProfile } = useAuth();
//   const isProfileLoader = isProfile;
//   return {isProfileLoader};
// }

const NonAuthContent = () => {
  const {themeMode} = useSetting();
  const {permissionCreateChk} = usePermission();

  const { currentIndivPages, currentLastPath, currentFirstPath, currentFullPath} = useCurrentPages();

  React.useEffect(() => {
    // Perform any action needed when currentFullPath changes
    // console.log(`Current last path has changed: ${currentFullPath}`);
  }, [currentFullPath]);

  const navigate = useNavigate();
  const onCreateLink = () => {
    const linkToCreateUrl = 
    currentIndivPages
    .split(',')
    .map(p=> p==='list'?'create':p)
    .join('/')
    navigate(`/${linkToCreateUrl}`)
  }
  const onListLink = () => {
    const linkToCreateUrl = 
    currentIndivPages
    .split(',')
    .map(p=> p==='create'?'list':p)
    .join('/')
    navigate(`/${linkToCreateUrl}`)
  }
  const onFromEditToListLink = () => {
    const linkToCreateUrl = currentFirstPath+'/list'
    navigate(`/${linkToCreateUrl}`)
  }

  return (
    <Box
      display="flex"
      flexDirection="column"
      height="100%"
      p={{
        xs: ccGap2,
        sm: ccGap2p5,
        md: ccGap2p5,
        xl: ccGap2p5,
        lg: ccGap2p5,
      }}
      borderRadius={2}
      bgcolor={themeMode?.ccGlow2}
    >
      {/* Bread crumbs and create, list link */}
      <Box 
        display="flex" 
        flexDirection="row"
        alignItems="center"
        justifyContent="space-between"
      >
        <CCBreadcrumbs />

        {
          ((permissionCreateChk() === true) && (currentLastPath === 'list')) &&
          <CCMuiButton
            startIcon={currentFirstPath === 'user' 
              ? <PersonAddOutlinedIcon /> 
              : <PlaylistAddOutlinedIcon /> 
            }
            sx={{backgroundColor: themeMode?.ccButtonBB}}
            onClick={onCreateLink}
          >
            Create New {currentFirstPath}
          </CCMuiButton>
        }

        { currentLastPath === 'create'  &&
          <CCMuiButton
            startIcon={<ListAltOutlinedIcon />}
            sx={{backgroundColor: themeMode?.ccButtonGB}}
            onClick={onListLink}
          >
            View {currentFirstPath} List
          </CCMuiButton>
        }

        { /\/edit\//.test(currentFullPath)  &&
          <CCMuiButton
            startIcon={<ListAltOutlinedIcon />}
            onClick={onFromEditToListLink}
            sx={{backgroundColor: themeMode?.ccButtonGB}}
          >
            View {currentFirstPath} List
          </CCMuiButton>
        }
      </Box>

      {/* End bread crumbs and create, list link */}

      <CCMuiDividerHorizontal />
      
      <Paper
        elevation={3}
        gap={2}
        sx={{
          color: themeMode?.ccFontDark || 'inherit',
          flexGrow: 1,
          backgroundColor: themeMode?.ccGlow1,
          p: {
            xs: ccGap2,
            sm: ccGap2p5,
            md: ccGap2p5,
            xl: ccGap2p5,
            lg: ccGap2p5,
          },
        }}
      >
        <Outlet />
      </Paper>
    </Box>
  )
};

export default NonAuthContent;
// export {loader};

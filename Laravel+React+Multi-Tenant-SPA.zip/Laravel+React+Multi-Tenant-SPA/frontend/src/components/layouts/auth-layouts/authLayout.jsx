import * as React from "react";

import { Container, Grid, CssBaseline} from "@mui/material";
import CCMuiSnackBar from "components/mui-customizations/ccMuiSnackBar";

import Content from "components/layouts/content";
import { authThemeMode } from "components/mui-customizations/styleCustomization";


const AuthLayout = () => {
  return (
    <>
      <CssBaseline />
      <Container 
        disableGutters 
        // maxWidth="false"
        maxWidth={false}
      >
        <Grid
          container
          minHeight="100vh"
          bgcolor={authThemeMode?.ccDark3}
        >
          <Grid
            item
            container
            direction="column"
            justifyContent='center'
            alignItems='center'
            columns={12}
          >
            <Content />
          </Grid>
        </Grid>
      </Container>
      <CCMuiSnackBar />
    </>
  );
};

export default AuthLayout;

import React, { useState, useEffect } from 'react';

import { styled, useTheme } from '@mui/material/styles';
import MuiAppBar from '@mui/material/AppBar';
import MenuIcon from '@mui/icons-material/Menu';
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { CCMuiCircularLoader } from 'components/mui-customizations/ccMuiCircularLoader';
import { authThemeMode } from 'components/mui-customizations/styleCustomization';
import {
  Grid,
  Box,
  Drawer,
  Typography,
  IconButton,
  CssBaseline,
  Toolbar,
} from '@mui/material';
import {
  ccGap2p5,
  ccGap2,
  ccGap4,
} from 'components/mui-customizations/styleCustomization';

import { useSetting } from 'settings/settingContext';
import { useAuth } from 'auths/hooks/authHook';
import Content from 'components/layouts/content';
import Footer from 'components/layouts/footer';
import Header from 'components/layouts/header';
import Menu from 'components/layouts/menu';

// Define drawer widths based on breakpoints
const drawerWidths = {
  xs: 160,
  sm: 180,
  md: 230,
  lg: 240,
  xl: 290,
};

// Styled main content area
const Main = styled('main', { shouldForwardProp: (prop) => prop !== 'open' })(
  ({ theme, open }) => ({
    flexGrow: 1,
    padding: theme.spacing(12.5, 0, 2, 0),
    marginLeft: open ? 0 : `-${theme.drawerWidth}px`,
    transition: theme.transitions.create(['margin'], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen,
    }),
    ...(open && {
      width: `calc(100% - ${theme.drawerWidth}px)`,
      transition: theme.transitions.create(['margin'], {
        easing: theme.transitions.easing.easeOut,
        duration: theme.transitions.duration.enteringScreen,
      }),
      marginLeft: 0,
    }),
  })
);

// Styled AppBar
const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== 'open',
})(({ theme, open }) => ({
  transition: theme.transitions.create(['margin', 'width'], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    width: `calc(100% - ${theme.drawerWidth}px)`,
    marginLeft: `${theme.drawerWidth}px`,
    transition: theme.transitions.create(['margin', 'width'], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));

// Drawer header styling
const DrawerHeader = styled('div')(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  padding: theme.spacing(0, 1),
  ...theme.mixins.toolbar,
  justifyContent: 'flex-end',
}));

const DrawerLayout = () => {
  const { themeMode } = useSetting();
  const { isProfile, profileLoading } = useAuth();
  const [open, setOpen] = useState(true);
  const [drawerWidth, setDrawerWidth] = useState(drawerWidths.md);
  const theme = useTheme();

  const switchMode = isProfile ? themeMode : authThemeMode

  useEffect(() => {
    const updateDrawerWidth = () => {
      const screenWidth = window.innerWidth;
      if (screenWidth < theme.breakpoints.values.sm) setDrawerWidth(drawerWidths.xs);
      else if (screenWidth < theme.breakpoints.values.md) setDrawerWidth(drawerWidths.sm);
      else if (screenWidth < theme.breakpoints.values.lg) setDrawerWidth(drawerWidths.md);
      else if (screenWidth < theme.breakpoints.values.xl) setDrawerWidth(drawerWidths.lg);
      else setDrawerWidth(drawerWidths.xl);
    };
    updateDrawerWidth();
    window.addEventListener('resize', updateDrawerWidth);
    return () => window.removeEventListener('resize', updateDrawerWidth);
  }, [theme.breakpoints.values]);

  if (!isProfile && profileLoading) {
    return (
      <>
        <CssBaseline />
        <Box
          display="flex"
          justifyContent="center"
          alignItems="center"
          width="100%"
          height="100vh"
          bgcolor={`${switchMode?.ccDark3}`}
        >
          <CCMuiCircularLoader sx={{color: `${switchMode?.ccGlow3}`}} />
        </Box>
      </>
    );
  }

  theme.drawerWidth = drawerWidth; // Pass dynamic width to theme

  return (
    <>
      <CssBaseline />
      <Box 
        sx={{ display: 'flex', minHeight: '100vh' }} 
        bgcolor={themeMode?.ccDark3}
      >
        <CssBaseline />

        {/* Header and Drawer Menu */}
        {isProfile && (
          <>
            <AppBar 
              position="fixed" 
              open={open} 
              sx={{bgcolor: 'transparent', boxShadow: 'unset'}}
            >
              <Header>
                <Toolbar sx={{ flexGrow: 1, pl: '12px!important' }}>
                  <IconButton
                    color={`${themeMode?.ccButtonC}`}
                    aria-label="open drawer"
                    onClick={() => setOpen(true)}
                    edge="start"
                    sx={{ mr: 2, ...(open && { display: 'none' }) }}
                  >
                    <MenuIcon />
                  </IconButton>
                  <Typography variant="h6" noWrap component="div">
                    {/* Persistent Drawer */}
                  </Typography>
                </Toolbar>
              </Header>
            </AppBar>

            <Drawer
              sx={{
                width: drawerWidth,
                flexShrink: 0,
                '& .MuiDrawer-paper': {
                  width: drawerWidth,
                  boxSizing: 'border-box',
                  bgcolor: themeMode?.ccGlow1,
                },
              }}
              variant="persistent"
              anchor="left"
              open={open}
            >
              <DrawerHeader
                sx={{minHeight: "30px!important", height: "30px!important"}}
              >
                <IconButton 
                  onClick={() => setOpen(false)}                   
                  sx={{color: `${themeMode?.ccMenuC}`, py:0.3}}
                >
                  {theme.direction === 'ltr' ? <ChevronLeftIcon /> : <ChevronRightIcon />}
                </IconButton>
              </DrawerHeader>
              <Menu />
            </Drawer>
          </>
        )}

        {/* Main Content */}
        <Main open={open}>
          <DrawerHeader />
          <Grid 
            container 
            spacing={ccGap2p5}
          >
            <Grid 
              item 
              container
              xs={12} 
              mb={ccGap4}
            >
              <Grid
                item
                pr={{ 
                  xs:ccGap2,
                  sm: ccGap2p5, 
                  md: ccGap2p5, 
                  lg: ccGap2p5, 
                  xl: ccGap2p5,
                }}
                pl={{
                  xs:ccGap2,
                  sm: ccGap2p5,
                }}
                xs={12}
                sm={12}
                md={12}
                lg={12}
                xl={12}
              >
                <Content />
              </Grid>
            </Grid>
          </Grid>
        </Main>

        {/* Content */}
        {/* Footer conent */}
        {isProfile && (
          <AppBar 
            position="fixed" 
            open={open} 
            sx={{ 
              alignItems: 'center' 
            }}
          >
            <Footer />
          </AppBar>
        )}
        {/* End footer content */}
        {/* </Container> */}
      </Box>
    </>
  );
};

export default DrawerLayout;

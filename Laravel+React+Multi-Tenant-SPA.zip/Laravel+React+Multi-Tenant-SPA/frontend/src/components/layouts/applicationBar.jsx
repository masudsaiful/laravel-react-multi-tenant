import React, {useState} from "react";
import { useNavigate } from "react-router-dom";

import { Settings, PersonAdd, Logout} from "@mui/icons-material";
import MenuIcon from "@mui/icons-material/Menu";
import AdbIcon from "@mui/icons-material/Adb";
import MailIcon from "@mui/icons-material/Mail";
import NotificationsIcon from "@mui/icons-material/Notifications";
import PersonOutlinedIcon from '@mui/icons-material/PersonOutlined';
import VerifiedUserOutlinedIcon from '@mui/icons-material/VerifiedUserOutlined';
import ManageAccountsTwoToneIcon from '@mui/icons-material/ManageAccountsTwoTone';
import CCMuiButton from "components/mui-customizations/ccMuiButton";
import {CCMuiDividerHorizontal} from "components/mui-customizations/ccMuiDivider";
import {
  Box,
  AppBar,
  Typography,
  Menu,
  MenuItem,
  Avatar,
  Tooltip,
  Button,
  Toolbar,
  Badge,
  ListItemIcon,
  IconButton,
} from "@mui/material";
import {
  CCRouterNavLink,
  ccGap2,
  ccGap2p5,
} from "components/mui-customizations/styleCustomization";

import { useSetting } from "settings/settingContext";
import { useAuth } from "auths/hooks/authHook";
import { useRole, useRoleDispatch } from "components/roles/roleContext";
import { useMessage } from "messages/messageContext";
import { useError } from "errors/errorHook";
import CCLogo, { CCLogoTypography } from "components/layouts/logo"; 
import onlyFirstLetterCapital from "utilities/onlyFirstLetterCapital";


const pages = ["Products", "Pricing", "Blog"];
const settings = ["Profile", "Account", "Dashboard", "Logout"];

//Vite way to get asset image
const logoExists = new URL('../../assets/images/crystalcodelogo.png', import.meta.url).href;

const ApplicationBar = () => {
  const {themeMode} = useSetting();

  const navigate = useNavigate();
  const { isProfile, profile, fetchProfile, handleLogout } = useAuth();
  const { role, allPagingRoles, fetchAllRoles } = useRole();
  const roleDispatch = useRoleDispatch();

  const [anchorElNav, setAnchorElNav] = useState(null);
  const [anchorElUser, setAnchorElUser] = useState(null);

  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleClick = async (event) => {
    setAnchorEl(event.currentTarget);

    // Ensure fresh profile datas
    await fetchProfile(); 
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };
  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  // Error context errors to display 
  const {ccGetError} = useError();
  const {message, messageDispatch} = useMessage();

  const handleLogoutClick = async (e) => {
    e.preventDefault();
    setAnchorEl(null);
    const response = await handleLogout();

    // Message display after successful logged out through message context
    if (response.status === 'success') {
      await messageDispatch(response.status, response.message);
      // After login navigate to
      navigate("/auth/login");
    } else {
      await ccGetError(response);
    }
  };
  
  const menuItemSx = themeMode => ({
    '&.MuiMenuItem-root': {
      color: themeMode?.ccMenuC,
      '& .MuiListItemIcon-root': {
        color: themeMode?.ccMenuIC,
      },
      '& .MuiTypography-root': {
        color: themeMode?.ccMenuTC,
      },
      '& .MuiAvatar-root': {
        bgcolor: themeMode?.ccMenuAB,
        color: themeMode?.ccMenuAC
      },
      '&:hover': {
        bgcolor: `${themeMode?.ccMenuHB1}`,
        color: themeMode?.ccMenuHC,
        '& .MuiListItemIcon-root': {
          color: themeMode?.ccMenuHC,
        },
      },
      "& .MuiTouchRipple-child": {
        backgroundColor: `${themeMode?.ccMenuRC1}!important`,
      },
    },
  });

  // useEffect(() => {
  //   const roleData = allPagingRoles ? allPagingRoles.find(r => r.id === role.id) : null;
  //   roleDispatch({
  //     type: 'set',
  //     role: {
  //       ...role,
  //       ...roleData,
  //     }
  //   })
  // }, [allPagingRoles])

  return (
    <AppBar 
      position="static"
      sx={{
        background: `${themeMode?.ccDark3}`,
        zIndex: (theme) => theme.zIndex.drawer + 1
      }}
    >
      <Box
        px={{
          xs: ccGap2,
          sm: ccGap2p5,
          md: ccGap2p5,
          lg: ccGap2p5,
          xl: ccGap2p5,
        }}
      >
        <Toolbar 
          disableGutters
        >
          {/* Logo */}
          <CCRouterNavLink
            to={`/`}
          >
            {
              typeof logoExists !== 'undefined' && logoExists ? (
                <CCLogo
                  src={logoExists}
                  style={{
                    padding: '10px 10px 10px 0'
                  }}
                />
              ) : (
                <CCLogoTypography 
                  variant="h6"
                >
                  L O G O
                </CCLogoTypography>
              )
            }
          </CCRouterNavLink>
          {/* End Logo */}
          
          {/* Menu in small device breakpoints */}
          <Box 
            sx={{ 
              flexGrow: 1, 
              display: { 
                xs: "flex", 
                md: "none" } 
            }}
          >
            <IconButton
              size="large"
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleOpenNavMenu}
              color="inherit"
            >
              <MenuIcon />
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorElNav}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
              }}
              keepMounted
              transformOrigin={{
                vertical: "top",
                horizontal: "left",
              }}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
              sx={{
                display: { 
                  xs: "block", 
                  md: "none" 
                },
              }}
            >
              {pages.map((page) => (
                <MenuItem 
                  key={page} 
                  onClick={handleCloseNavMenu}
                >
                  <Typography 
                    textAlign="center"
                  >
                    {page}
                  </Typography>
                </MenuItem>
              ))}
            </Menu>
          </Box>
          {/* End menu in small device breakpoints */}

          {/* Extra icon in small device breakpoints */}
          <AdbIcon 
            sx={{ 
              color: `${themeMode?.ccFontGlow3}`,
              display: { 
                xs: "flex", 
                md: "none" 
              }, 
              mr: 1 
            }}
          />
          {/* End extra icon in small device breakpoints */}

          {/* Extra text in small device breakpoints */}
          <Typography
            variant="h5"
            noWrap
            component="a"
            href="#app-bar-with-responsive-menu"
            sx={{
              mr: 2,
              display: { xs: "flex", md: "none" },
              flexGrow: 1,
              fontFamily: "monospace",
              fontWeight: 700,
              letterSpacing: ".3rem",
              color: `${themeMode?.ccFontGlow3}`,
              textDecoration: "none",
            }}
          >
            LOGO
          </Typography>
          {/* End extra text in small device breakpoints */}

          {/* Menu in large device breakpoints */}
          <Box 
            sx={{ 
              flexGrow: 1, 
              display: { 
                xs: "none", 
                md: "flex" 
              },
            }}
          >
            {pages.map((page) => (
              <CCMuiButton
                key={page}
                sx={{ 
                  my: 2,
                  display: "block" 
                }}
                onClick={handleCloseNavMenu}
              >
                {page}
              </CCMuiButton>
            ))}
          </Box>
          {/* End menu in large device breakpoints */}

          {/* Mails notifications and Profile accounts */}
          <Box 
            sx={{ 
              flexGrow: 0,
              color: themeMode?.ccFontGlow3,
            }}
          >
            {/* Mails and notifications */}
            <IconButton
              size="large"
              aria-label="show 4 new mails"
              color="inherit"
            >
              <Badge 
                badgeContent={4} 
                color="error"
              >
                <MailIcon />
              </Badge>
            </IconButton>
            <IconButton
              size="large"
              aria-label="show 17 new notifications"
              color="inherit"
            >
              <Badge 
                badgeContent={17} 
                color="error"
              >
                <NotificationsIcon />
              </Badge>
            </IconButton>
            {/* End mail and notifications */}

            {
              // Another Style of Account Settings
              /* <Tooltip 
                title="Open settings"
              >
                <IconButton
                  onClick={handleOpenUserMenu}
                  sx={{ 
                    p: 0, 
                    ml: 2,
                  }}
                >
                  <Avatar
                    alt="Remy Sharp"
                    src="/static/images/avatar/2.jpg"
                    sx={{
                      height:"30px",
                      width:"30px",
                      backgroundColor: themeMode?.ccFontGlow3,
                    }}
                  />
                </IconButton>
              </Tooltip>
              <Menu
                sx={{ 
                  mt: "45px" 
                }}
                id="menu-appbar"
                anchorEl={anchorElUser}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={Boolean(anchorElUser)}
                onClose={handleCloseUserMenu}
              >
                {settings.map((setting) => (
                  <MenuItem 
                    key={setting} 
                    onClick={handleCloseUserMenu}
                  >
                    <Typography 
                      textAlign="center"
                    >
                      {setting}
                    </Typography>
                  </MenuItem>
                ))}
              </Menu> */
            }

            {/* Profile accounts */}

              <Tooltip 
                title="Account settings"
              >
                <IconButton
                  onClick={handleClick}
                  size="small"
                  sx={{ ml: 1, p: 0 }}
                  aria-controls={open ? 'account-menu' : undefined}
                  aria-haspopup="true"
                  aria-expanded={open ? 'true' : undefined}
                >
                  <Avatar 
                    sx={{ 
                      background: `${themeMode?.ccFontGlow4}`,
                      width: 32, 
                      height: 32, 
                    }}
                  >
                    {`${profile ? onlyFirstLetterCapital(profile.name) : ''}`}
                  </Avatar>
                </IconButton>
              </Tooltip>

              <Menu
                anchorEl={anchorEl}
                id="account-menu"
                open={open}
                onClose={handleClose}
                onClick={handleClose}
                PaperProps={{
                  elevation: 0,
                  sx: {
                    bgcolor: themeMode?.ccGlow1,
                    overflow: 'visible',
                    filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
                    mt: 1.5,
                    '& .MuiAvatar-root': {
                      width: 32,
                      height: 32,
                      ml: -0.5,
                      mr: 1,
                    },
                    '&::before': {
                      content: '""',
                      display: 'block',
                      position: 'absolute',
                      top: 0,
                      right: 14,
                      width: 10,
                      height: 10,
                      bgcolor: themeMode?.ccWhite,
                      transform: 'translateY(-50%) rotate(45deg)',
                      zIndex: 0,
                    },
                  },
                }}
                transformOrigin={{ horizontal: 'right', vertical: 'top' }}
                anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
              >
                <MenuItem sx={{...menuItemSx(themeMode)}}>
                  <ListItemIcon>
                    <PersonOutlinedIcon fontSize="small" /> 
                  </ListItemIcon>
                  {`Welcome! ${profile ? profile.name : ''}`}
                </MenuItem>

                <MenuItem sx={{...menuItemSx(themeMode)}}>
                  <ListItemIcon>
                    <VerifiedUserOutlinedIcon fontSize="small" /> 
                  </ListItemIcon>
                  {`Username: ${profile ? profile.username : ''}`}
                </MenuItem>

                <MenuItem sx={{...menuItemSx(themeMode)}}>
                  <ListItemIcon
                    sx={{
                      color:`${themeMode?.ccMenuIC}!important`
                    }} 
                  >
                    <ManageAccountsTwoToneIcon fontSize="small" /> 
                  </ListItemIcon>
                  <Typography variant="subtitle2">
                    Role: {profile?.roles?.map(role => role.title).join(', ')}
                  </Typography>
                </MenuItem>

                <MenuItem 
                  sx={{...menuItemSx(themeMode)}}
                  onClick={handleClose}
                >
                  <Avatar/> Profile
                </MenuItem>

                <MenuItem
                  sx={{...menuItemSx(themeMode)}} 
                  onClick={handleClose}
                >
                  <Avatar /> My account
                </MenuItem>

                <CCMuiDividerHorizontal 
                  sx={{
                    pb: '8px',
                    mb: '8px!important',
                  }}
                />

                <MenuItem 
                  sx={{...menuItemSx(themeMode)}} 
                  onClick={handleClose}
                >
                  <ListItemIcon>
                    <PersonAdd fontSize="small" />
                  </ListItemIcon>
                  Add another account
                </MenuItem>

                <MenuItem 
                  sx={{...menuItemSx(themeMode)}} 
                  onClick={handleClose}
                >
                  <ListItemIcon>
                    <Settings fontSize="small" />
                  </ListItemIcon>
                  Settings
                </MenuItem>

                <MenuItem 
                  sx={{...menuItemSx(themeMode)}}
                  onClick={handleLogoutClick}
                >
                  <ListItemIcon>
                    <Logout fontSize="small" />
                  </ListItemIcon>
                  Logout
                </MenuItem>
              </Menu>

            {/* End profile accounts */}

          </Box>
          {/* End profile accounts */}
          
        </Toolbar>
      </Box>
    </AppBar>
  )
}

export default ApplicationBar
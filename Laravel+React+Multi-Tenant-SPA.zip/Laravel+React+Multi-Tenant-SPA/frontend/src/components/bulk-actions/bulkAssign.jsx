import React, {useEffect} from "react";

import { Box } from "@mui/material";
import Button from "@mui/material/Button";
import DeleteIcon from "@mui/icons-material/Delete";
import AssignmentTurnedInOutlinedIcon from '@mui/icons-material/AssignmentTurnedInOutlined';
import DisabledByDefaultOutlinedIcon from '@mui/icons-material/DisabledByDefaultOutlined';
import { 
  CCSmallButtonGreen,
} from 'components/mui-customizations/styleCustomization';

import { 
  swalLoginRegisterAlert 
} from "components/swal-customizations/styleCustomization";

import { usePermission } from "components/permissions/permissionContext";
import { useSetting } from "settings/settingContext";
import { useRole } from "components/roles/roleContext";
import { useError } from "errors/errorHook";
import axiosInstance from "plugins/axiosInstance";
import wordsUpperCase from "utilities/wordsUpperCase";


const BulkDelete = ({
  setBulkSelectedIds,
  bulkSelectedIds,
  apiResource,
  apiRelationMethod,
  apiRelationAction,
  afterDeleteRefreshTo,
}) => {
  const {themeMode} = useSetting();
  const {permissionEditUpdateChk, permissionDeleteChk} = usePermission();
  const {allRoles} = useRole();
  const { ccGetError } = useError();

  useEffect(() => {
    //
  }, [allRoles])

  const handleBulkDelete = async () => {
    try {
      swalLoginRegisterAlert.fire({
        title: 'Are you sure?', 
        text: "You won't be able to revert this!", 
        confirmButtonText: "Yes, delete it!",
        icon: "warning",
        showCancelButton: true,
        color: themeMode?.ccError1,
        confirmButtonColor: themeMode?.ccTree1,
        cancelButtonColor: themeMode?.ccError1,
        background: themeMode?.ccGlow1,
      }).then(async result => {
        if (result.isConfirmed) {
          // Promise.all(...) Sends all the requests to the backend simultaneously.
          // The backend 'delete' resource controller method receives each DELETE request individually
          // Even though Promise.all(...) sent simultaneously.
          // await Promise.all(selectedIds.map((id) => axiosInstance.delete(`/users/${id}`)));

          // Send a single delete request with an array of selected IDs using backend bulk action API.
          // Post method used here for delete to send req with body params purposes.
          const result = await axiosInstance.post(`/${apiResource}/${apiRelationAction}/bulkDelete`, { 
            ids: bulkSelectedIds,
            relationMethod: apiRelationMethod,
          } );
          if(result && result.data && result.data.status === "success") {
            setBulkSelectedIds([]);
            await afterDeleteRefreshTo();
            swalLoginRegisterAlert.fire({
              title: `Deleted ${wordsUpperCase(result.data.status)}!`, 
              text: result.data.message, 
              icon: "success",
              iconColor: themeMode?.ccTree1,
              color: themeMode?.ccError1,
              confirmButtonColor: themeMode?.ccGlow4,
              background: themeMode?.ccGlow1,
              timer: 11500, // alert timer
            });
          }
        }
      });
    } catch (error) {
      await ccGetError(error);
    }
  };

  return (
    <>
      {bulkSelectedIds.length > 0 && (
        <Box sx={{mb:2}}>
          {
            permissionDeleteChk() === true &&
            <Button
              size="small"
              variant="contained"
              color="secondary"
              startIcon={<DeleteIcon />}
              onClick={handleBulkDelete}
              sx={{
                mr: 1,
                color: `${themeMode?.ccButtonC}`,
                ":hover": {
                  backgroundColor: themeMode?.ccDark3,
                },
              }}
            >
              Bulk Deleted
            </Button>
          }

          {
            permissionEditUpdateChk() === true &&
            <>
              <CCSmallButtonGreen 
                startIcon={<AssignmentTurnedInOutlinedIcon />}
                endIcon=""
                sx={{ml:0, mr: 1}}
              >
                Bulk Assigned
              </CCSmallButtonGreen>

              <CCSmallButtonGreen 
                startIcon={<DisabledByDefaultOutlinedIcon />}
                endIcon=""
                sx={{
                  ml:0,
                  backgroundColor:themeMode?.ccError1,
                  color: `${themeMode?.ccButtonC}`,
                  ":hover": {
                    backgroundColor: themeMode?.ccDark3,
                  },
                }}
              >
                Bulk Unassigned
              </CCSmallButtonGreen>
            </>
          }
        </Box>
      )}
    </>
  );
};

export default BulkDelete;

import { useState, useCallback, useEffect } from "react";

import { useTheme } from '@mui/material/styles';
import DeleteIcon from "@mui/icons-material/Delete";
import StartSharpIcon from '@mui/icons-material/StartSharp';
import AssignmentTurnedInOutlinedIcon from '@mui/icons-material/AssignmentTurnedInOutlined';
import DisabledByDefaultOutlinedIcon from '@mui/icons-material/DisabledByDefaultOutlined';
import CCMultiSelect from "components/mui-customizations/multiSelectCustomization";
import CCMuiSnackBar from "components/mui-customizations/ccMuiSnackBar";
import CCMuiButton from "components/mui-customizations/ccMuiButton";
import { 
  Box, 
  FormControl, 
  FormHelperText, 
  InputLabel, 
  OutlinedInput, 
} from "@mui/material";

import { 
  swalLoginRegisterAlert 
} from "components/swal-customizations/styleCustomization";

import { useMessage } from "messages/messageContext";
import { useSetting } from "settings/settingContext";
import { usePermission } from "components/permissions/permissionContext";
import { useError } from "errors/errorHook";
import isEmptyUniversalCheck from "utilities/isEmptyUniversalCheck";
import axiosInstance from "plugins/axiosInstance";
import wordsUpperCase from "utilities/wordsUpperCase";


const BulkAction = ({  
  setBulkSelectedIds, 
  bulkSelectedIds,
  apiResource,
  apiResourceRelationMethod,
  apiResourceRelationType,
  apiResourceRelationAction,
  afterDeleteRefreshTo,
}) => {
  const {themeMode} = useSetting();

  const [apiResourceRelationData, SetApiResourceRelationData] = useState([]);
  const [apiResourceRelationIds, SetApiResourceRelationIds] = useState([]);
  const [errorState, setErrorState] = useState('');
  const [placeholderState, setPlaceholderState] = useState('');

  const theme = useTheme();
  const { ccGetError } = useError();
  const {messageDispatch} = useMessage('');
  const {permissionEditUpdateChk, permissionDeleteChk} = usePermission();

  const apiResourceRelationActionChk = !isEmptyUniversalCheck(apiResourceRelationAction) &&
  apiResourceRelationAction.split(',') || [];
  
  const handleLoadActionData = async (action) => {
    try {
      if (!isEmptyUniversalCheck(apiResourceRelationMethod) &&
        !isEmptyUniversalCheck(apiResource) &&
        !isEmptyUniversalCheck(action) &&
        (action === 'assign' || action === 'unassign')) {
        const result = await axiosInstance.get(`/${apiResourceRelationMethod}/${action}/bulk`, { 
          params: {
            relationMethod: apiResource,
          }
        });

        if(result && result.data && result.data.status === "success") {
          const allRoles = await result.data.allRoles;
          const mappedAllRoles = allRoles.map(r=>{
            if (r.name && r.title) {
              return { id: r.id, label: r.title, value: r.name }; // Map item if it has 'id' and 'title' or 'name
            } 
            if (r.username && r.name) {
              return { id: r.id, label: r.name, value: r.username }; // Handle other cases
            }
          })
          SetApiResourceRelationData(mappedAllRoles);
          setPlaceholderState(action);
          await messageDispatch(result.data.status, `${action} resources loaded in the Role field`);
        }
      }
    } catch (error) {
      ccGetError(error);
    }
  }

  const handleBulkAction = async (action) => {
    try {
      if ((isEmptyUniversalCheck(apiResourceRelationMethod) || 
        isEmptyUniversalCheck(apiResourceRelationType)) &&
        (!isEmptyUniversalCheck(bulkSelectedIds) &&
        !isEmptyUniversalCheck(apiResource) &&
        !isEmptyUniversalCheck(action))) {
        if ( action === 'delete') {
          // console.log(`${apiResource}-${bulkSelectedIds}-${action}-${apiResourceRelationMethod}-${apiResourceRelationType}-${apiResourceRelationIds}`);
          swalLoginRegisterAlert.fire({
            title: 'Are you sure?', 
            text: `Missing of relation method, type etc. which causes 
            only delete selected records  without relationship records.
            You won't be able to revert this!`, 
            confirmButtonText: `Yes, confirm bulk ${action}!`,
            icon: "warning",
            showCancelButton: true,
            color: themeMode?.ccError1,
            confirmButtonColor: themeMode?.ccTree1,
            cancelButtonColor: themeMode?.ccError1,
            background: themeMode?.ccGlow1,
          }).then(async result => {
            if (result.isConfirmed) {
              const result = await axiosInstance.post(`/${apiResource}/${action}/bulk`, { 
                ids: bulkSelectedIds,
              });
              if(result && result.data && result.data.status === "success") {
                setBulkSelectedIds([]);
                await afterDeleteRefreshTo();
                swalLoginRegisterAlert.fire({
                  title: `Bulk ${action} ${wordsUpperCase(result.data.status)}!`, 
                  text: result.data.message, 
                  icon: "success",
                  iconColor: themeMode?.ccTree1,
                  color: themeMode?.ccError1,
                  confirmButtonColor: themeMode?.ccGlow4,
                  background: themeMode?.ccGlow1,
                  timer: 11500, // alert timer
                });
              }
            }
          });
        } else {
          // console.log(`${apiResource}-${bulkSelectedIds}-${action}-${apiResourceRelationMethod}-${apiResourceRelationType}-${apiResourceRelationIds}`);
          swalLoginRegisterAlert.fire({
            title: 'Sorry?', 
            text: `You didn't provide either relation method or relation type or relation ids.`, 
            confirmButtonText: `Please, try next time to ${action}!`,
            icon: "warning",
            showCancelButton: true,
            color: themeMode?.ccError1,
            confirmButtonColor: themeMode?.ccTree1,
            cancelButtonColor: themeMode?.ccError1,
            background: themeMode?.ccGlow1,
          })
        }
      } else {
        if (action === 'delete') {
          swalLoginRegisterAlert.fire({
            title: 'Are you sure?', 
            text: "You won't be able to revert this!", 
            confirmButtonText: `Yes, confirm bulk ${action}!`,
            icon: "warning",
            showCancelButton: true,
            color: themeMode?.ccError1,
            confirmButtonColor: themeMode?.ccTree1,
            cancelButtonColor: themeMode?.ccError1,
            background: themeMode?.ccGlow1,
          }).then(async result => {
            if (result.isConfirmed) {
              const result = await axiosInstance.post(`/${apiResource}/${action}/bulk`, { 
                ids: bulkSelectedIds,
                relationMethod: apiResourceRelationMethod,
                relationType: apiResourceRelationType,
              });
              if(result && result.data && result.data.status === "success") {
                setBulkSelectedIds([]);
                await afterDeleteRefreshTo();
                swalLoginRegisterAlert.fire({
                  title: `Bulk ${action} ${wordsUpperCase(result.data.status)}!`, 
                  text: result.data.message, 
                  icon: "success",
                  iconColor: themeMode?.ccTree1,
                  color: themeMode?.ccError1,
                  confirmButtonColor: themeMode?.ccGlow4,
                  background: themeMode?.ccGlow1,
                  timer: 11500, // alert timer
                });
              }
            }
          });
        } else {
          if (isEmptyUniversalCheck(apiResourceRelationIds)) {
            swalLoginRegisterAlert.fire({
              title: 'Sorry?', 
              text: `You didn't provide either relation method or relation type or relation ids.`, 
              confirmButtonText: `Please, try next time to ${action}!`,
              icon: "warning",
              showCancelButton: true,
              color: themeMode?.ccError1,
              confirmButtonColor: themeMode?.ccTree1,
              cancelButtonColor: themeMode?.ccError1,
              background: themeMode?.ccGlow1,
            })
          } else {
            swalLoginRegisterAlert.fire({
              title: 'Are you sure?', 
              text: "You won't be able to revert this!", 
              confirmButtonText: `Yes, confirm bulk ${action}!`,
              icon: "warning",
              showCancelButton: true,
              color: themeMode?.ccError1,
              confirmButtonColor: themeMode?.ccTree1,
              cancelButtonColor: themeMode?.ccError1,
              background: themeMode?.ccGlow1,
            }).then(async result => {
              if (result.isConfirmed) {
                // Promise.all(...) Sends all the requests to the backend simultaneously.
                // The backend 'delete' resource controller method receives each DELETE request individually
                // Even though Promise.all(...) sent simultaneously.
                // await Promise.all(selectedIds.map((id) => axiosInstance.delete(`/users/${id}`)));
      
                // Send a single delete request with an array of selected IDs using backend bulk action API.
                // Post method used here for delete to send req with body params purposes.
                const result = await axiosInstance.post(`/${apiResource}/${action}/bulk`, { 
                  ids: bulkSelectedIds,
                  relationMethod: apiResourceRelationMethod,
                  relationType: apiResourceRelationType,
                  relationIds: apiResourceRelationIds,
                });
                if(result && result.data && result.data.status === "success") {
                  setBulkSelectedIds([]);
                  await afterDeleteRefreshTo();
                  swalLoginRegisterAlert.fire({
                    title: `Bulk ${action} ${wordsUpperCase(result.data.status)}!`, 
                    text: result.data.message, 
                    icon: "success",
                    iconColor: themeMode?.ccTree1,
                    color: themeMode?.ccError1,
                    confirmButtonColor: themeMode?.ccGlow4,
                    background: themeMode?.ccGlow1,
                    timer: 11500, // alert timer
                  });
                }
              }
            });
          }
        }
      };
    } catch (error) {
      await ccGetError(error);
    }
  };

  const handleSelectOptionChange = useCallback((event) => {
    const { name, value } = event.target;
    const selectedValue = Array.isArray(value) && value.length > 0 ? value : Number(value) > 0 ? [value] : [];
    let selectError = '';

    if (selectedValue.length === 0) {
      selectError = `Required valid ${name} to select`;
    } else {
      selectError = ''
    }

    SetApiResourceRelationIds(selectedValue);
    setErrorState(selectError);
  }, [apiResourceRelationIds]);

  const renderMultiSelectField = (name, label, items, value = '', placeholder='', error = "") => (
    <FormControl 
      sx={{
        flex: { 
          xs: '1 0 calc(100% - 8px)', 
          sm: '1 0 calc(50% - 8px)', 
          md: '1 0 calc(50% - 8px)', 
          lg: '1 0 calc(20% - 8px)', 
          xl: '1 0 calc(20% - 8px)'
        },
        '& .MuiOutlinedInput-input': {
          minHeight: '24px',
          paddingY: '6px' 
        }
      }} 
      size="small" 
      required error={!!error}
      fullWidth={false}
    >
      <InputLabel id={`${name}-label`} sx={{ color: themeMode?.ccTree1 }}>{label}</InputLabel>
      <CCMultiSelect
        name={name}
        value={value}
        id={name}
        labelId={`${name}-label`}
        placeholder={placeholder}
        onChange={handleSelectOptionChange}
        input={<OutlinedInput id={`${name}-select`} label={label} />}
        items={items}
        multiple
      />
      <FormHelperText sx={{ mx: 0, color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  useEffect(() => {
    if (!isEmptyUniversalCheck(bulkSelectedIds)) {
      if (isEmptyUniversalCheck(apiResource) || 
        isEmptyUniversalCheck(apiResourceRelationActionChk)) {
        ccGetError({
          errors: {
            status: 'Failed, resource informations missing.',
            message: 'Need to provide resource and action(s) to access bulk operations.'
          }
        })
      }
    }
  }, [bulkSelectedIds])

  return (
    <>
      {
        /**
         * Must provide 'apiResource', 'bulkSelectedIds' and 'relationAction'. 
         * To visible bulk button at least need the above informations.
         * Others permission set necessary to visible bulk buttons.
         */
      }

      {(!isEmptyUniversalCheck(apiResource) && 
        !isEmptyUniversalCheck(bulkSelectedIds) &&
        !isEmptyUniversalCheck(apiResourceRelationActionChk)) &&
        (permissionDeleteChk() === true || 
        permissionEditUpdateChk() === true) && (
        <>
        <Box
          display="flex" 
          flexWrap="wrap" 
          justifyContent="center" 
          alignItems="center" 
          mb={1}
          gap={1}
        >
          {
            apiResourceRelationActionChk.map(a=>{
              if (a === 'delete' && permissionDeleteChk() === true) {
                return (
                  <CCMuiButton
                    key={a}
                    startIcon={<DeleteIcon />}
                    onClick={() => handleBulkAction(a)}
                    sx={{
                      mr: 0,
                      flex: { 
                        xs: '1 0 calc(100% - 8px)', 
                        sm: '1 0 calc(50% - 8px)', 
                        md: '1 0 calc(50% - 8px)', 
                        lg: '1 0 calc(20% - 8px)', 
                        xl: '1 0 calc(20% - 8px)' 
                      },
                      bgcolor: themeMode?.ccButtonDB
                    }}
                  >
                    Bulk {a}
                  </CCMuiButton>
                )
              }

              if (a === 'assign' && permissionEditUpdateChk() === true) {
                return (
                  <CCMuiButton 
                    key={a}
                    startIcon={<AssignmentTurnedInOutlinedIcon />}
                    onClick={() => handleLoadActionData(a)}
                    sx={{
                      mr: 0,
                      flex: { 
                        xs: '1 0 calc(100% - 8px)', 
                        sm: '1 0 calc(50% - 8px)', 
                        md: '1 0 calc(50% - 8px)', 
                        lg: '1 0 calc(20% - 8px)', 
                        xl: '1 0 calc(20% - 8px)' 
                      },
                      backgroundColor:`${themeMode?.ccButtonGB}`,
                    }}
                  >
                    Load {a}
                  </CCMuiButton>
                )
              }

              if (a === 'unassign' && permissionEditUpdateChk() === true) {
                return (
                  <CCMuiButton 
                    key={a}
                    startIcon={<DisabledByDefaultOutlinedIcon />}
                    onClick={() => handleLoadActionData(a)}
                    sx={{
                      mr: 0,
                      flex: { 
                        xs: '1 0 calc(100% - 8px)', 
                        sm: '1 0 calc(50% - 8px)', 
                        md: '1 0 calc(50% - 8px)', 
                        lg: '1 0 calc(20% - 8px)', 
                        xl: '1 0 calc(20% - 8px)' 
                      },
                      backgroundColor:themeMode?.ccButtonEB,
                    }}
                  >
                    Load {a}
                  </CCMuiButton>
                )
              }

              return null;
            })
          }

          {
            ((apiResourceRelationActionChk.includes('assign') ||
            apiResourceRelationActionChk.includes('unassing')) &&
            permissionEditUpdateChk() === true) && 
            !isEmptyUniversalCheck(apiResourceRelationMethod) && (
              renderMultiSelectField(
                `${apiResourceRelationMethod}`, 
                `${wordsUpperCase(apiResourceRelationMethod)}`, 
                apiResourceRelationData, 
                apiResourceRelationIds, 
                `List of item (s) to ${placeholderState}`,
                errorState,
              )
            )
          }

          {
            !isEmptyUniversalCheck(placeholderState) && 
            !isEmptyUniversalCheck(apiResourceRelationIds) && (
              <CCMuiButton 
                endIcon={<StartSharpIcon />}
                onClick={() => handleBulkAction(placeholderState)}
                sx={{
                  mr:0,
                  flex: { 
                    xs: '1 0 calc(100% - 8px)', 
                    sm: '1 0 calc(20% - 8px)', 
                    md: '1 0 calc(20% - 8px)', 
                    lg: '1 0 calc(20% - 8px)', 
                    xl: '1 0 calc(20% - 8px)' 
                  },
                  backgroundColor:themeMode?.ccButtonEB,
                }}
              >
                Bulk {placeholderState}
              </CCMuiButton>
            )
          }

          {/* {
            permissionDeleteChk() === true &&
            apiResourceRelationActionChk.includes('delete') && (
              <Button
                size="small"
                variant="contained"
                color="secondary"
                startIcon={<DeleteIcon />}
                onClick={handleBulkDelete}
                sx={{
                  mr: 1,
                  color: `${themeMode?.ccFontGlow1}`,
                  ":hover": {
                    backgroundColor: themeMode?.ccDark3,
                  },
                }}
              >
                Bulk Deleted
              </Button>
            )
          }

          {
            permissionEditUpdateChk() === true &&
            apiResourceRelationActionChk.includes('assign') && (
              <CCSmallButtonGreen 
                startIcon={<AssignmentTurnedInOutlinedIcon />}
                endIcon=""
                sx={{ml:0, mr: 1}}
              >
                Bulk Assigned
              </CCSmallButtonGreen>
            )
          }

          {
            permissionEditUpdateChk() === true &&
            apiResourceRelationActionChk.includes('unassign') && (
              <CCSmallButtonGreen 
                startIcon={<DisabledByDefaultOutlinedIcon />}
                endIcon=""
                sx={{
                  ml:0,
                  backgroundColor:themeMode?.ccError1,
                  color: `${themeMode?.ccFontGlow1}`,
                  ":hover": {
                    backgroundColor: themeMode?.ccDark3,
                  },
                }}
              >
                Bulk Unassigned
              </CCSmallButtonGreen>
            )
          } */}
        </Box>
        </>
      )}
      <CCMuiSnackBar />
    </>
  );
}

export default BulkAction;
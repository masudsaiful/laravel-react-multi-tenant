import React, { useState, useEffect, useCallback } from "react";

import CCUserDataGrid from "src/components/mui-customizations/ccUserDataGrid";

import { useUser } from "components/users/userContext";
import BulkAction from "components/bulk-actions/bulkAction";


// Minimum loading duration in milliseconds
const MIN_LOADING_DURATION = 300;

const UserList = () => {
  const {
    allPagingUsers,
    rowCount,
    page,
    pageSize,
    sortModel,
    filterModel,
    setPageRef,
    setPageSizeRef,
    setSortModel,
    setFilterModel,
    fetchAllUsers,
    loading,
  } = useUser();

  // State for managing bulk selected rows
  const [bulkSelectedIds, setBulkSelectedIds] = useState([]);

  // State for handling UI loading duration
  const [isMinLoading, setIsMinLoading] = useState(false);

  // Effect to handle data fetching with minimum loading duration
  useEffect(() => {
    const loadStartTime = Date.now();
    // Set UI loading state
    setIsMinLoading(true);
    // Fetch user data and handle minimum loading duration
    fetchAllUsers()
      .catch(() => {
        // Ignore fetch cancellation errors
      })
      .finally(() => {
        const loadDuration = Date.now() - loadStartTime;
        const remainingDuration = MIN_LOADING_DURATION - loadDuration;
        setTimeout(() => setIsMinLoading(false), Math.max(0, remainingDuration));
      });
  }, [fetchAllUsers]);

  // Combined loading state
  const isLoading = loading || isMinLoading;

  // Memoized callback to prevent unnecessary re-renders
  const handleSetBulkSelectedIds = useCallback((ids) => setBulkSelectedIds(ids),[]);

  return (
    <CCUserDataGrid
      rows={allPagingUsers}
      rowCount={rowCount}
      page={page}
      setPage={!isLoading && setPageRef} // Prevent page change during loading
      pageSize={pageSize}
      setPageSize={!isLoading && setPageSizeRef}
      sortModel={sortModel}
      setSortModel={setSortModel}
      filterModel={filterModel}
      setFilterModel={setFilterModel}
      fetchAllUsers={fetchAllUsers}
      bulkSelectedIds={bulkSelectedIds}
      setBulkSelectedIds={handleSetBulkSelectedIds}
      loading={isLoading}
    >
      <BulkAction
        setBulkSelectedIds={handleSetBulkSelectedIds}
        bulkSelectedIds={bulkSelectedIds}
        apiResource="users"
        apiResourceRelationMethod="roles"

        /** 
         * apiResourceRelationType="manyToMany" or "oneToMany" or "oneToOne"
         * apiResourceRelationAction="delete" or "delete,assign" or 
         * 'delete,assign,unassign' or any combinations of these
         *
         */
        apiResourceRelationType="manyToMany"
        apiResourceRelationAction="delete,assign,unassign"
        afterDeleteRefreshTo={fetchAllUsers}
      />
    </CCUserDataGrid>
  );
};

export default UserList;

import React, { useState, useEffect, useCallback } from "react";
import { Visibility, VisibilityOff } from '@mui/icons-material';

import CCMuiTextField from "components/mui-customizations/ccMuiTextField";
import CCSingleSelect from "components/mui-customizations/singleSelectCustomization";
import CCMultiSelect from "components/mui-customizations/multiSelectCustomization";
import { useTheme } from '@mui/material/styles';
import { 
  Box, 
  FormControl, 
  FormHelperText, 
  InputLabel, 
  OutlinedInput, 
  InputAdornment, 
  IconButton 
} from '@mui/material';

import { useRole } from "components/roles/roleContext";
import { useUser, useUserDispatch } from "components/users/userContext";
import { useSetting } from "settings/settingContext";
import isNonValidEmail from "utilities/isNonValidEmail";
import isNonValidString from "utilities/isNonValidString";


// Status items to select
const selectStatus = [
  { id: 1, value: 'Enable' },
  { id: 2, value: 'Disable' },
];

const UserFields = ({children, errorState, setErrorState, option}) => {
  const {themeMode} = useSetting();
  // Edited or created user using user context
  const { user } = useUser();
  const { allRoles, fetchAllRoles } = useRole();
  const theme = useTheme();
  const userDispatch = useUserDispatch();

  // Selected status state
  const [selectedStatus, setSelectedStatus] = useState([]);

  // Role list state using role context to select
  const [selectRoles, setSelectRoles] = useState([]);
  const [showPassword, setShowPassword] = useState(false);


  // Fetch roles when component mounts (and if roles change)
  // useEffect(() => {
  //   if (allRoles.length === 0) {
  //     fetchAllRoles();  // Lazy load roles if not already loaded
  //   }
  // }, []);

  // Map roles to select options
  useEffect(() => {
    const mappedRoles = allRoles.map(role => ({
      id: role.id, label: role.title, value: role.name
    }))
    setSelectRoles(mappedRoles)
  }, [allRoles])

  // Confirmed initial selected state and error state set
  useEffect(() => {
    fetchAllRoles(); 
    // if (user && user.status && Array.isArray(user.status) && user.status.length > 0) {
    //   setSelectedStatus(user.status[0]);
    // } else {
    //   setSelectedStatus('');
    // }
  
    // if (user && user.role && Array.isArray(user.role) && user.role.length > 0) {
    //   setSelectedStatus(user.role);
    // } else {
    //   setSelectedStatus([]);
    // }

    setErrorState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
      }
    }));
  }, []);

  // Toggle password visibility
  const handleClickShowPassword = useCallback(() => {
    setShowPassword(prevState => !prevState);
  }, []);

  const handleMouseDownPassword = useCallback((event) => {
    event.preventDefault();
  }, []);

  // Updated field states to user context, updated error states
  const handleFieldChange = useCallback(event => {
    const { name, value } = event.target;

    // const error = 
    // name === 'email'
    // ? value.trim() === "" 
    //   ? `Required ${name} field` 
    //   : !validateEmail(value) 
    //     ? `Invalid ${name} format` 
    //     : ""
    // : value.trim() === "" 
    //   ? `Required ${name} field` 
    //   : !validateField(value) 
    //     ? `Invalid ${name} format` 
    //     : "";

    const error = 
    name === 'email'
    ? isNonValidEmail(value)
      ? `Required valid ${name} field` 
      : ''
    : isNonValidString(value)
      ? `Invalid ${name} format` 
      : '';

    userDispatch({
      type: 'changed', 
      user: { 
        ...user, 
        [name]: value 
      } 
    });

    setErrorState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: error
      }
    }));
  }, [user, userDispatch, setErrorState]);


  // Password changes status and error update if any
  const handlePasswordChange = useCallback(event => {
    const { name, value } = event.target;

    const passwordError = value.length > 0 && value.length < 8 ? 'Password must be at least 8 characters' : '';
    const passwordConfirmationError = value !== user.password_confirmation ? 'Passwords do not match' : '';

    userDispatch({
      type: 'set', 
      user: { 
        ...user, 
        [name]: value,
      } 
    });

    setErrorState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: passwordError,
        passwordConfirmation: passwordConfirmationError
      }
    }));
  }, [user, userDispatch, setErrorState]);

  // Confirm password changes status and error update if any
  const handlePasswordConfirmationChange = event => {
    const { name, value } = event.target;

    userDispatch({
      type: 'changed', 
      user: { 
        ...user, 
        [name]: value 
      } 
    });

    setErrorState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        passwordConfirmation: value !== user.password ? 'Passwords do not match' : ''
      }
    }));
  };


  const handleSelectOptionChange = useCallback((event) => {
    const { name, value } = event.target;
    const selectedValue = Array.isArray(value) && value.length > 0 ? value : Number(value) > 0 ? [value] : [];
    let selectError = '';

    if (selectedValue.length === 0) {
      selectError = `Required valid ${name} to select`;
    } else {
      selectError = ''
    }

    // Update the context with the selected value
    userDispatch({
      type: 'changed',
      user: {
        ...user,
        [name]: selectedValue,
      }
    });
    
    // Update the error state with errors if any
    setErrorState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: selectError
      }
    }));
  }, [user, userDispatch, setErrorState]);

  const renderTextField = (name, label, type = "text", value = "", error = "") => (
    <FormControl sx={{ gridColumn: "span 1" }} required error={!!error}>
      <CCMuiTextField
        type={type === "password" ? (showPassword ? "text" : type) : type}
        name={name}
        id={name}
        label={label}
        value={type === "password" ? value ? value : "" : value}
        placeholder={`Enter ${label.toLowerCase()}`}
        required={type === "password" ? option === 'edited' ? false : true : true}
        onChange={
          name.includes("password")
            ? name === "password"
              ? handlePasswordChange
              : handlePasswordConfirmationChange
            : handleFieldChange
        }
        autoComplete={type === "password" ? "new-password" : "on"}
        endAdornment={
          type === "password" && (
            <InputAdornment position="end">
              <IconButton
                aria-label="toggle password visibility"
                onClick={handleClickShowPassword}
                onMouseDown={handleMouseDownPassword}
                edge="end"
              >
                {showPassword ? <VisibilityOff /> : <Visibility />}
              </IconButton>
            </InputAdornment>
          )
        }
      />
      <FormHelperText sx={{margin:0}}>{error}</FormHelperText>
    </FormControl>
  );

  const renderSelectField = (name, label, items, value = '', error = "") => (
    <FormControl sx={{ gridColumn: "span 1" }} size="small" required error={!!error}>
      <InputLabel id={`${name}-label`} sx={{ color: themeMode?.ccTree2 }}>{label}</InputLabel>
      <CCSingleSelect
        name={name}
        value={value}
        id={name}
        labelId={`${name}-label`}
        onChange={handleSelectOptionChange}
        input={<OutlinedInput id={`${name}-select`} label={label} />}
        items={items}
        // multiple
      />
      <FormHelperText sx={{ m:0, color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  const renderMultiSelectField = (name, label, items, value = '', error = "") => (
    <FormControl sx={{ gridColumn: "span 1" }} size="small" required error={!!error}>
      <InputLabel id={`${name}-label`} sx={{ color: themeMode?.ccTree2 }}>{label}</InputLabel>
      <CCMultiSelect
        name={name}
        value={value}
        id={name}
        labelId={`${name}-label`}
        onChange={handleSelectOptionChange}
        input={<OutlinedInput id={`${name}-select`} label={label} />}
        items={items}
        multiple
      />
      <FormHelperText sx={{ m:0, color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  return (
    <Box
      component="form"
      sx={{
        display: 'grid',
        gridTemplateColumns: 'repeat(3, 1fr)',    
        gap: 2,
        width: '100%',
      }}
      noValidate
      autoComplete="off"
    >
      {renderTextField('name', 'Name', 'text', user.name, errorState.errors.name)}
      {renderTextField('username', 'Username', 'text', user.username, errorState.errors.username)}
      {renderTextField('email', 'E-mail', 'email', user.email, errorState.errors.email)}
      {renderTextField('password', 'Password', 'password', user.password, errorState.errors.password)}
      {renderTextField('password_confirmation', 'Password Confirmation', 'password', user.password_confirmation, errorState.errors.passwordConfirmation)}
      {renderSelectField('status', 'Status', selectStatus, user.status[0], errorState.errors.status)}
      {renderMultiSelectField('roles', 'Role title (name)', selectRoles, user.roles, errorState.errors.roles)}                                                             
      {children}
    </Box>
  );
};

export default UserFields;
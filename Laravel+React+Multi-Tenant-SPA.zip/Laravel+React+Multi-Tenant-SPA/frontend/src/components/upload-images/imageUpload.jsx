import React from "react";
import { useNavigate } from "react-router-dom";

import {Box, Avatar, Typography} from '@mui/material';
import CloudUploadTwoToneIcon from '@mui/icons-material/CloudUploadTwoTone';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import CCMuiButton from "components/mui-customizations/ccMuiButton";

import { useSetting } from "settings/settingContext";
import { useAuth } from "auths/hooks/authHook";
import profileImage from "static/images/profile-image.png"



const ImageUpload = () => {
  const {themeMode} = useSetting();
  const { profile } = useAuth();

  const navigate = useNavigate();

  return (
    <Box
      display="flex"
      flexDirection="row"
      justifyContent="flex-start"
      alignItems="flex-start"
      pb={2}
    >
      <Avatar
        variant="rounded"
        alt="Crystal Code" // If no image first letter of alt text
        src={profileImage}
        // sx={{ width: 96, height: 96,  bgcolor: deepOrange[500]}}
        sx={{ width: 152, height: 152,  bgcolor: themeMode?.ccFontGlow1}}
      />
      <Box
        display="flex"
        flexDirection="column"
        sx={{pl:2}}
      >
        <Box>
          <CCMuiButton 
            startIcon={<CloudUploadTwoToneIcon />}
            sx={{px: 1, bgcolor: themeMode?.ccButtonUB}}
          >
            Upload Image
          </CCMuiButton>

          <CCMuiButton 
            startIcon={<CancelOutlinedIcon />}
            sx={{
              px: 1,
              mr: 0,
              bgcolor:themeMode?.ccButtonEB, 
            }}
          >
            Cancle
          </CCMuiButton>
        </Box>
        <Typography 
          variant="caption"
          sx={{mt:1}}
        >
          Max size of 100K
        </Typography>
      </Box>
    </Box>
  );
}
export default ImageUpload;

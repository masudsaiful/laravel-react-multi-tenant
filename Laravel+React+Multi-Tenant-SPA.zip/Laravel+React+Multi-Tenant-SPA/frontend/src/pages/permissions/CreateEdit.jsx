import React, {useEffect, useCallback } from "react"

import { Box, Stack } from "@mui/material";
import { 
  ccGap1,
  ccGap2,
} from 'components/mui-customizations/styleCustomization';

import { useUser } from "components/users/userContext";
import { useRole } from "components/roles/roleContext";
import { useAuth } from "auths/hooks/authHook";
import CreateEditForm from "components/permissions/createEditFrom";


const PermissionCreateEdit = () => {
  return (
    <Stack 
      direction="column" 
      justifyContent="flex-start" 
      alignItems="flex-start" 
      spacing={{
        xs: ccGap1,
        sm: ccGap1,
        md: ccGap2,
        xl: ccGap2,
        lg: ccGap2,
      }}
    >
      <Box
        display="flex"
        alignSelf="stretch"
      >
        <CreateEditForm />
      </Box>
    </Stack>
  );
};

export default PermissionCreateEdit;

import React, { useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";

import { Box, Grid, Paper} from "@mui/material";
import {PersonAdd, AppRegistration, Input} from "@mui/icons-material";
import CCMuiTextField from "components/mui-customizations/ccMuiTextField";
import CCMuiButton from "components/mui-customizations/ccMuiButton";
import {CCMuiDividerHorizontal} from "components/mui-customizations/ccMuiDivider";
import { CCMuiCircularLoader } from "components/mui-customizations/ccMuiCircularLoader";
import {
  CCTypographyAuthTitle,
  ccGap2p5,
} from "components/mui-customizations/styleCustomization";

import { useAuth } from "auths/hooks/authHook";
import { useError } from "errors/errorHook";
import { authThemeMode } from "components/mui-customizations/styleCustomization";
import Swal from "sweetalert2";
import wordsUpperCase from "utilities/wordsUpperCase";
import isNonValidEmail from "utilities/isNonValidEmail";
import isNonValidString from "utilities/isNonValidString";
import wordsSeperateByUpperCase from "utilities/wordsSeperateByUpperCase";
import isEmptyUniversalCheck from "utilities/isEmptyUniversalCheck";

const Register = () => {
  const {handleRegister} = useAuth();
  const navigate = useNavigate();
  const {ccGetError} = useError();

  const [loading, setLoading] = useState(false);
  const [errorState, setErrorState] = useState({
    name: "",
    username: "",
    email: "",
    password: "",
  });
  const [data, setData] = useState({
    name: "",
    username: "",
    email: "",
    password: "",
    password_confirmation: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    const error = 
    name === 'email'
    ? !isNonValidEmail(value) || isEmptyUniversalCheck(value)
      ? ''
      : `Required valid ${name} field`
    : !isNonValidString(value) || isEmptyUniversalCheck(value)
      ? ''
      : `Required valid ${name} field`

    setErrorState(prevState => ({
      ...prevState,
      [name]: error
    }));

    setData({
      ...data,
      [name]: value,
    });
  };

// Password changes status and error update if any
  const handlePasswordChange = useCallback(event => {
    const { name, value } = event.target;

    const error = value.length > 0 && value.length < 8 ? 'Password must be at least eight(8) characters' : '';
    const passwordConfirmationError = value !== data.password_confirmation ? 'Passwords do not match' : '';

    setErrorState(prevState => ({
      ...prevState,
      [name]: error,
      password_confirmation: passwordConfirmationError
    }));

    setData({
      ...data,
      [name]: value,
    });
  }, [data, setData, setErrorState]);

  // Confirm password changes status and error update if any
  const handlePasswordConfirmationChange = event => {
    const { name, value } = event.target;

    setErrorState(prevState => ({
      ...prevState,
      [name]: value !== data.password ? 'Passwords do not match' : ''
    }));

    setData({
      ...data,
      [name]: value,
    });
  };

  // const handleSubmit = async (e) => {
  //   e.preventDefault();
  //   try {
  //     const result = await handleRegister(data);
  //     if(result) {
  //       Swal.fire({
  //         title: "Success!", 
  //         text: "Your are registered. Require login to access",
  //         icon: "success",
  //         iconColor: themeMode?.ccGlow4,
  //         color: themeMode?.ccGlow4,
  //         confirmButtonColor: themeMode?.ccGlow4,
  //         background: ccGlow1,
  //       }) 
  //       navigate("/auth/login")
  //     } else {
  //       // showError('Invalid Registration');
  //       // Swal.fire("Error", "Invalid login details", "error");
  //       // console.log('get n show', await ccGetError({errors: {message: 'Problems with data loading.'}});)
  //       // console.log('only message', ccShowError)
  //       // console.log('only message1', ccError)
  //       navigate("/auth/register");
  //     }
  //   } catch (error) {
  //     // showError('Invalid Registration');
  //     // Swal.fire("Error", "Registration failed", "error");
  //   }
  // };

  const handleSubmit = async (e) => {
    if (Object.keys(errorState).filter(key => errorState[key]).length > 0) {
      await ccGetError({errors: errorState})
    } else {
      try {
        e.preventDefault();
        setLoading(true);
        const result = await handleRegister(data);
        if(result && result.data && typeof result.data.user !== 'undefined' ) {
          if (result && result.data && result.data.status === 'success') {
            Swal.fire({
              title: `${wordsUpperCase(result.data.status)}!`, 
              text: result.data.message, 
              icon: "success",
              iconColor: authThemeMode?.ccGlow4,
              color: authThemeMode?.ccGlow4,
              confirmButtonColor: authThemeMode?.ccGlow4,
              background: authThemeMode?.ccGlow1,
            }) 
            setLoading(false);
            navigate("/auth/login")
          } else {
            setLoading(false);
            navigate("/auth/register");
          }
        } else {
          setLoading(false);
          await ccGetError(result)
        }
      } catch (error) {
        setLoading(false);
        await ccGetError(error)
      }
    }
  };

  const handleRedirectToLogin = () => {
    navigate("/auth/login");
  };

  return (
    <Grid
      container
      item
      display="flex"
      alignItems="center"
      justifyContent="center"
      bgcolor={authThemeMode?.ccDark3}
    >
      <Paper
        elevation={4}
        sx={{
          p: ccGap2p5,
          backgroundColor: authThemeMode?.ccGlow2,
          width: {
            xs: "90%",
            sm: "70%",
            md: 500,
            lg: 600,
            xl: 600,
          }
        }}
      >
        <CCTypographyAuthTitle
          display="flex"
          justifyContent="center"
          alignItems="center"
          sx={{
            color: authThemeMode?.ccGlow4,
          }}
        >
          <PersonAdd fontSize="medium"  sx={{marginRight: '5px'}} /> 
          Register
          {loading && <CCMuiCircularLoader size="1.15rem" sx={{ml:1}} />}
        </CCTypographyAuthTitle>

        <CCMuiDividerHorizontal sx={{borderBottomColor: `${authThemeMode?.ccTree1}50`}} />

        <form>
          <Paper 
            elevation={2}
            sx={{
              p: ccGap2p5,
              backgroundColor: authThemeMode?.ccGlow1
            }}
          >
            <CCMuiTextField 
              type="text"
              name="name"
              id="name"
              label={"Name"}
              placeholder="Enter name"
              // error
              required
              onChange={handleChange} 
              sx={{
                marginBottom: '12px'
              }}
              helperText={
                wordsSeperateByUpperCase(
                  errorState.name
                )
              }
            />
            <CCMuiTextField
              type="text"
              name="username"
              id="username"
              label={"Username"}
              placeholder="Enter username"
              // helperText="Incorrect entry."
              // error
              required
              onChange={handleChange} 
              sx={{
                marginBottom: '12px'
              }}
              helperText={
                wordsSeperateByUpperCase(
                  errorState.username
                )
              }
            />
            <CCMuiTextField
              type="email"
              name="email"
              id="email"
              label={"E-mail"}
              placeholder="Insert E-mail"
              // helperText="Incorrect entry."
              // error
              required
              onChange={handleChange} 
              sx={{
                marginBottom: '12px'
              }}
              helperText={
                wordsSeperateByUpperCase(
                  errorState.email
                )
              }
            />
            <CCMuiTextField
              type="password"
              name="password"
              id="password"
              label={"Password"}
              placeholder="Enter password"
              autoComplete="off"
              // error
              required
              onChange={handlePasswordChange} 
              sx={{
                marginBottom: '12px'
              }}
              helperText={
                wordsUpperCase(
                  errorState.password
                )
              }
            />
            <CCMuiTextField
              type="password"
              name="password_confirmation"
              id="password_confirmation"
              label={"Password Confirmation"}
              placeholder="Confirm password"
              autoComplete="off"
              // error
              required
              onChange={handlePasswordConfirmationChange} 
              helperText={
                wordsUpperCase(
                  errorState.password_confirmation
                )
              }
            />
          </Paper>
          <Box
            display="flex"
            justifyContent="flex-end"
            sx={{ marginTop: "20px" }}
          >
            <CCMuiButton
              endIcon={<Input />}
              sx={{bgcolor: authThemeMode?.ccButtonGB}}
              onClick={handleRedirectToLogin}
            >
              Login
            </CCMuiButton>

            <CCMuiButton 
              endIcon={<AppRegistration />}
              sx={{bgcolor: authThemeMode?.ccButtonBB, mr:0}}
              onClick={handleSubmit}
            >
              Registration
            </CCMuiButton>
          </Box>
        </form>
      </Paper>
    </Grid>
  );
};

export default Register;

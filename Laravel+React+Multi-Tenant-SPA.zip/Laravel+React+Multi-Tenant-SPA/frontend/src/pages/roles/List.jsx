import React from "react";
import { Box, Stack } from "@mui/material";
import { RoleProvider } from "components/roles/roleContext";
import RoleList from "components/roles/roleList";
import { 
  ccGap1,
  ccGap2,
} from 'components/mui-customizations/styleCustomization';


const List = () => {
  return (
    <Stack 
      direction="column" 
      justifyContent="flex-start" 
      alignItems="flex-start" 
      spacing={{
        xs: ccGap1,
        sm: ccGap1,
        md: ccGap2,
        xl: ccGap2,
        lg: ccGap2,
      }}
    >
      <Box
        display="flex"
        alignSelf="stretch"
      >
        {/* <RoleProvider> */}
          <RoleList />
        {/* </RoleProvider> */}
      </Box>
    </Stack>
  );
};

export default List;

import React from "react";
import { useParams } from 'react-router-dom';

import {Box, Stack} from '@mui/material';
import { 
  ccGap1,
  ccGap2,
} from "components/mui-customizations/styleCustomization"

import { RoleProvider } from "components/roles/roleContext";
import CreateEditForm from "components/roles/createEditForm";



const RoleEdit = () => {
  const { id } = useParams();
  
  return (
    <Stack 
      direction="column" 
      justifyContent="flex-start" 
      alignItems="flex-start" 
      spacing={{
        xs: ccGap1,
        sm: ccGap1,
        md: ccGap2,
        xl: ccGap2,
        lg: ccGap2,
      }}
    >
      {/* Create Edit Form */}
      <Box
        display="flex"
        alignSelf="stretch"
      >
        {/* <RoleProvider> */}
          <CreateEditForm 
            option="edited" 
            id={Number(id)} 
          />
        {/* </RoleProvider> */}
      </Box>
      {/* End Create Edit Form */}

      {/* Empty box */}
      {/* <Box
        display="flex"
        flexDirection="row"
      >
      </Box> */}
      {/* End empty box */}
    </Stack>
  );
};

export default RoleEdit;

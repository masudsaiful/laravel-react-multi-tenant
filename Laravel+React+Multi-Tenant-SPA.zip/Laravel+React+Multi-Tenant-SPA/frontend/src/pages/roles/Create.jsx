import React from "react";
import {Box, Stack} from '@mui/material';
import { 
  ccGap1,
  ccGap2,
} from "components/mui-customizations/styleCustomization"

import CreateEditForm from "components/roles/createEditForm";


const RoleCreate = () => {

  return (
    <Stack 
      direction="column" 
      justifyContent="flex-start" 
      alignItems="flex-start" 
      spacing={{
        xs: ccGap1,
        sm: ccGap1,
        md: ccGap2,
        xl: ccGap2,
        lg: ccGap2,
      }}
    >
      {/* Create Edit Form */}
      <Box
        display="flex"
        alignSelf="stretch"
      >
        {/* <RoleProvider> */}
          <CreateEditForm 
            option="created"
          />
        {/* </RoleProvider> */}
      </Box>
      {/* End Create Edit Form */}

      {/* Empty box */}
      {/* <Box
        display="flex"
        flexDirection="row"
      >
        something here...
      </Box> */}
      {/* End empty box */}
    </Stack>
  );
};

export default RoleCreate;

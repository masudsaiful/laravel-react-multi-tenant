import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

import { Box, Grid, Paper} from "@mui/material";
import {Login as LoginIcon, AppRegistration, Input} from "@mui/icons-material";
import CCMuiTextField from "components/mui-customizations/ccMuiTextField";
import CCMuiButton from "components/mui-customizations/ccMuiButton";
import {CCMuiDividerHorizontal} from "components/mui-customizations/ccMuiDivider";
import { CCMuiCircularLoader } from "components/mui-customizations/ccMuiCircularLoader";
import {
  CCTypographyAuthTitle,
  ccGap2p5,
} from "components/mui-customizations/styleCustomization"

import { useAuth } from "auths/hooks/authHook";
import { useError } from "errors/errorHook";
import wordsUpperCase from "utilities/wordsUpperCase";
import { authThemeMode } from "components/mui-customizations/styleCustomization";
import isNonValidEmail from "utilities/isNonValidEmail";
import isNonValidString from "utilities/isNonValidString";
import wordsSeperateByUpperCase from "utilities/wordsSeperateByUpperCase";
import isEmptyUniversalCheck from "utilities/isEmptyUniversalCheck";

import { 
  swalLoginRegisterAlert 
} from "components/swal-customizations/styleCustomization";


const Login = () => {
  const {handleLogin} = useAuth();
  const {ccGetError} = useError();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(false);
  const [errorState, setErrorState] = useState({
    email_or_username: "",
  });
  const [credentials, setCredentials] = useState({
    email_or_username: "",
    password: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    const error = 
    name === 'email_or_username'
    ? !isNonValidEmail(value) || !isNonValidString(value) || isEmptyUniversalCheck(value)
      ? ''
      : `Required valid ${name} field`
    : ''

    setErrorState(prevState => ({
      ...prevState,
      [name]: error
    }));

    setCredentials({
      ...credentials,
      [name]: value,
    });
  };

  // const handleSubmit = async (e) => {
  //   e.preventDefault();
  //   try {
  //     const result = await handleLogin(credentials);
  //     if(result) {
  //       swalLoginRegisterAlert.fire({
  //         title: "Success!", 
  //         text: "Your are logged in", 
  //         icon: "success",
  //         iconColor: themeMode?.ccTree1,
  //         color: themeMode?.ccTree1,
  //         confirmButtonColor: themeMode?.ccTree1,
  //         background: ccGlow1,
  //       }) 
  //       navigate("/dashboard")
  //     } else {
  //       navigate("/auth/login")
  //     }
  //   } catch (error) {
  //     // alert()
  //     // Swal.fire("Error", "Invalid login details", "error");
  //   }
  // };

  const handleSubmit = async (e) => {
    if (errorState?.email_or_username) {
      await ccGetError({errors: errorState})
    } else {
      try {
        e.preventDefault();
        setLoading(true);
        const result = await handleLogin(credentials);
        if (result && result.data && typeof result.data.status !== 'undefined') {
          if (result && result.data && result.data.status === 'success') {
            swalLoginRegisterAlert.fire({
              title: `${wordsUpperCase(result.data.status)}!`, 
              text: result.data.message, 
              icon: "success",
              iconColor: authThemeMode?.ccTree1,
              color: authThemeMode?.ccTree1,
              confirmButtonColor: authThemeMode?.ccTree1,
              background: authThemeMode?.ccGlow2,
            }) 
            setLoading(false);
            navigate("/dashboard")
          } else {
            setLoading(false);
            navigate("/auth/login")
          }
        } else {
          setLoading(false);
          await ccGetError(result)
        }
      } catch (error) {
        setLoading(false);
        await ccGetError(error)
      }
    }
  };

  const handleRedirectToRegistration = () => {
    navigate("/auth/register");
  };

  return (
    <>
      <Grid
        item
        display="flex"
        alignItems="center"
        justifyContent="center"
        bgcolor={authThemeMode?.ccDark3}
      >
        <Paper
          elevation={4}
          sx={{
            p: ccGap2p5,
            backgroundColor: authThemeMode?.ccGlow2,
            width: {
              xs: "90%",
              sm: "80%",
              md: 500,
              lg: 600,
              xl: 600,
            }
          }}
        >
          <CCTypographyAuthTitle
            display="flex"
            justifyContent="center"
            alignItems="center"
            sx={{
              color: authThemeMode?.ccTree1,
            }}
          >
            <>
            <LoginIcon fontSize="medium" sx={{marginRight: '5px'}} /> 
            Login 
            {loading && <CCMuiCircularLoader size="1.15rem" sx={{ml:1, color:`${authThemeMode?.ccTree1}`}} />}
            </>
          </CCTypographyAuthTitle>

          <CCMuiDividerHorizontal 
            sx={{borderBottomColor: `${authThemeMode?.ccTree1}50`}} 
          />

          <form>
            <Paper 
              elevation={2}
              sx={{
                p: ccGap2p5,
                backgroundColor: authThemeMode?.ccGlow1
              }}
            >
              <CCMuiTextField 
                type="text"
                name="email_or_username"
                id="email_or_username"
                label={"E-mail or Username"}
                placeholder="Enter E-mail or Username"
                sx={{
                  marginBottom: '12px'
                }}
                helperText={
                  wordsSeperateByUpperCase(
                    errorState.email_or_username
                  )
                }
                // error
                required
                onChange={handleChange} 
              />
              <CCMuiTextField
                type="password"
                name="password"
                id="password"
                label={"Password"}
                placeholder="Enter password"
                // helperText="Incorrect entry."
                autoComplete="off"
                // helperText={errorState.password)
                // error
                required
                onChange={handleChange}
              />
            </Paper>
            <Box
              display="flex"
              justifyContent="flex-end"
              sx={{ 
                marginTop: "20px" 
              }}
            >
              <CCMuiButton 
                endIcon={<AppRegistration />}
                sx={{bgcolor: authThemeMode?.ccButtonBB}}
                onClick={handleRedirectToRegistration}
              >
                Register Now
              </CCMuiButton>

              <CCMuiButton 
                endIcon={<Input />}
                sx={{bgcolor: authThemeMode?.ccButtonGB, mr:0}}
                onClick={handleSubmit}
              >
                Login
              </CCMuiButton>
            </Box>
          </form>
        </Paper>
      </Grid>
    </>
  );
};

export default Login;

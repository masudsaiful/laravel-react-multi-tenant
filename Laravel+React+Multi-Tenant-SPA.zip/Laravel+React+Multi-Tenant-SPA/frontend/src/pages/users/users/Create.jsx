import React from "react";

import {Box, Stack} from '@mui/material';
import { 
  ccGap1,
  ccGap2,
} from "components/mui-customizations/styleCustomization"

import ImageUpload from "components/upload-images/imageUpload";
import CreateEditForm from "components/users/createEditForm";


const UserCreate = () => {

  return (
    <Stack 
      direction="column" 
      justifyContent="flex-start" 
      alignItems="flex-start" 
      spacing={{
        xs: ccGap1,
        sm: ccGap1,
        md: ccGap2,
        xl: ccGap2,
        lg: ccGap2,
      }}
    >
      {/* upload image */}
      <ImageUpload />
      {/* End upload image */}

      {/* Create Edit Form */}
      <Box
        display="flex"
        alignSelf="stretch"
      >
        {/* <RoleProvider> */}
          <CreateEditForm 
            option="created"
          />
        {/* </RoleProvider> */}
      </Box>
      {/* End Create Edit Form */}

      {/* Empty box */}
      {/* <Box
        display="flex"
        flexDirection="row"
      >
      </Box> */}
      {/* End empty box */}
    </Stack>
  );
};

export default UserCreate;

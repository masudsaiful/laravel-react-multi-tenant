import React from "react";
import { Box, Stack } from "@mui/material";

import { 
  ccGap1,
  ccGap2,
} from 'components/mui-customizations/styleCustomization';

import UserList from "components/users/userList";


const List = () => {
  return (
    <Stack 
      direction="column" 
      justifyContent="flex-start" 
      alignItems="flex-start" 
      spacing={{
        xs: ccGap1,
        sm: ccGap1,
        md: ccGap2,
        xl: ccGap2,
        lg: ccGap2,
      }}
    >
      <Box
        display="flex"
        alignSelf="stretch"
      >
        {/* <RoleProvider> */}
          <UserList />
        {/* </RoleProvider> */}
      </Box>
    </Stack>
  );
};

export default List;

import * as React from 'react';

import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Slider from '@mui/material/Slider';
import FormControlLabel from '@mui/material/FormControlLabel';
import Checkbox from '@mui/material/Checkbox';
import HighlightOutlinedIcon from '@mui/icons-material/HighlightOutlined';

import { useSetting } from "settings/settingContext";
import { PieChart } from '@mui/x-charts/PieChart';



// Data derived from https://gs.statcounter.com/os-market-share/desktop/worldwide/2023
// And https://gs.statcounter.com/os-market-share/mobile/worldwide/2023
// And https://gs.statcounter.com/platform-market-share/desktop-mobile-tablet/worldwide/2023
// For the month of December 2023

// Define the color palette
const colorPalette = [
  '#A1DD70','#0A97B0 ','#00CCDD','#9694FF','#219B9D', 
  '#9B7EBD','#37AFE1','#08C2FF','#9EDF9C','#BF2EF0',
];

// const deletedUsersType = [
//   {
//     label: 'Deleted Enable',
//     value: 70.48,
//   },
//   {
//     label: 'Deleted Disable',
//     value: 28.8,
//   },
// ];

// const existingUsersType = [
//   {
//     label: 'Existing Enable',
//     value: 72.72,
//   },
//   {
//     label: 'Existing Disable',
//     value: 16.38,
//   },
// ];

// const users = [
//   {
//     label: 'Deleted Users',
//     value: 59.12,
//   },
//   {
//     label: 'Esisting Users',
//     value: 40.88,
//   },
// ];

const normalize = (v, v2) => Number.parseFloat(((v * v2) / 100).toFixed(2));

// const deletedExistingUsers = [
//   ...deletedUsersType.map((v) => ({
//     ...v,
//     label: v.label,
//     value: normalize(v.value, users[0].value),
//   })),
//   ...existingUsersType.map((v) => ({
//     ...v,
//     label: v.label,
//     value: normalize(v.value, users[1].value),
//   })),
//   ...users.map((v) => ({
//     ...v,
//     label: v.label,
//     value: v.value,
//   })),
// ];

const valueFormatter = item => (item.label === 'Users' || item.label === 'Deleted' || item.label === 'Existing') ? `Total: ${item.value}` : `${item.value}%`;

let size = {
  height: 400,
}

const CCMuiPieChart = ({dataset}) => {
  const {themeMode} = useSetting();

  const [radius, setRadius] = React.useState(50);
  const [itemNb, setItemNb] = React.useState(5);
  const [skipAnimation, setSkipAnimation] = React.useState(false);

  // Check if all values in the dataset are zero
  const isDataEmpty = dataset.every((item) => item.value === 0);

  const deletedExistingUsers = [
    ...dataset.map((v) => ({
      ...v,
      label: v.label,
      value: v.value,
    })),
  ];
  
  const handleItemNbChange = (event, newValue) => {
    if (typeof newValue !== 'number') {
      return;
    }
    setItemNb(newValue);
  };
  const handleRadius = (event, newValue) => {
    if (typeof newValue !== 'number') {
      return;
    }
    setRadius(newValue);
  };

  return (
    <Box sx={{ width: '100%'}}>
      {isDataEmpty ? (
        <>
          <Typography 
            variant="subtitle2" 
            textAlign="center"
            color={themeMode?.ccDark3}
            mt={0.5}
          >
            Users based pie chart 
          </Typography>
          <Typography 
            variant="body2" 
            textAlign="center"
            color={themeMode?.ccDark3}
            mb={3}
            // fontSize={12}   
          >
            (
              <HighlightOutlinedIcon 
                sx={{ 
                  // fontSize: 14, 
                  verticalAlign: 'middle', 
                  color:themeMode?.ccError1,
                  mr: 0.5,
                }} 
              /> 
              No data available
            )
          </Typography>
        </>
      ) : (
        <>
          <PieChart
            margin={{ top: 80}}
            {...size}
            series={[
              {
                data: deletedExistingUsers.slice(0, itemNb),
                innerRadius: radius,
                arcLabel: (params) => params.label ?? '',
                arcLabelMinAngle: 20,
                valueFormatter,
              },
            ]}
            skipAnimation={skipAnimation}
            slotProps={{
              legend: {
                direction: 'row',
                position: { vertical: 'top', horizontal: 'middle' },
                padding: 0,
                itemGap: 10,
                markGap: 5,
                itemMarkWidth: 20,
                itemMarkHeight: 13,
                itemNumber: 20,
                labelStyle: {
                  // fontSize: 16,
                },
              },
            }}
            colors={colorPalette} // Apply the color palette here
          />
          <FormControlLabel
            checked={skipAnimation}
            control={
              <Checkbox onChange={(event) => setSkipAnimation(event.target.checked)} />
            }
            label="skipAnimation"
            labelPlacement="end"
          />
          <Typography id="input-item-number" gutterBottom>
            Number of items
          </Typography>
          <Slider
            value={itemNb}
            onChange={handleItemNbChange}
            valueLabelDisplay="auto"
            min={1}
            max={9}
            aria-labelledby="input-item-number"
          />
          <Typography id="input-radius" gutterBottom>
            Radius
          </Typography>
          <Slider
            pl={2}
            value={radius}
            onChange={handleRadius}
            valueLabelDisplay="auto"
            min={15}
            max={100}
            aria-labelledby="input-radius"
          />
        </>
      )}
    </Box>
  );
}

export default CCMuiPieChart;

import React, { useState, useEffect } from "react"

import {Paper, Typography} from '@mui/material';
import HighlightOutlinedIcon from '@mui/icons-material/HighlightOutlined';
import { CCMuiCircularLoader } from "components/mui-customizations/ccMuiCircularLoader";

import { useSetting } from "settings/settingContext";
import { useError } from "errors/errorHook";
import { useAuth } from "auths/hooks/authHook";
import axiosInstance from "plugins/axiosInstance";
import isEmptyUniversalCheck from "utilities/isEmptyUniversalCheck";
import CCMuiPieChart from "./mui-customization/ccMuiPieChart";


const PieChart = () => {
  const {themeMode} = useSetting();
  // Error context errors to display 
  const {ccGetError} = useError();
  // Show, hide datas
  const [showLoading, setShowLoading] = useState(false);

  // From API record states
  const [dataset, setDataset] = useState([]);
  const [isDataset, setIsDataset] = useState(false);

  const {isProfile} = useAuth();

  const handleLoadPieCharts = async () => {
    try {
      setShowLoading(true);
      const result = await axiosInstance.get(`users/pie/charts`)
      if(result?.data?.status === 'success') {
        setDataset(result.data.dataset);
        setIsDataset(true);
        setShowLoading(false);
        navigate("/dashboard")
      }
    } catch (error) {
      console.log = () => {}; // Suppress error temporarily
      await ccGetError(error)
    }
  }

  // Fetch data when the component loads (default values)
  useEffect(() => {
    if (isProfile) {
      handleLoadPieCharts();
    }
  }, [isProfile]);

  return (
    <>
      {isDataset && !isEmptyUniversalCheck(dataset) && (
        <Paper 
          elevation={3}
          sx={{
            padding: "15px",
            background: themeMode?.ccGlow1,
          }}
        >
          <Typography 
            variant="subtitle2" 
            textAlign="center"
            color={themeMode?.ccFontDark}
            mt={0.5}
          >
            User based datas 
          </Typography>
          <Typography 
            variant="body2" 
            textAlign="center"
            color={themeMode?.ccFontDark}
            mb={3}
            // fontSize={12}   
          >
            (
              <HighlightOutlinedIcon 
                sx={{ 
                  // fontSize: 14, 
                  verticalAlign: 'middle', 
                  color: themeMode?.ccError1 || themeMode?.ccError1,
                  mr: 0.5,
                }} 
              /> 
              Datas, based on availability
            )
            </Typography>
          <CCMuiPieChart dataset={dataset} />
        </Paper>
      )}

      { showLoading &&
        <CCMuiCircularLoader />
      }
    </>
  )
}

export default PieChart;
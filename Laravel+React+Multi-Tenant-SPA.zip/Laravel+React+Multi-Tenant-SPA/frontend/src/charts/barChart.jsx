import React, { useState, useEffect } from "react"

import {Box, Paper, Typography} from '@mui/material';
import SaveAsTwoToneIcon from '@mui/icons-material/SaveAsTwoTone';
import CancelOutlinedIcon from '@mui/icons-material/CancelOutlined';
import HighlightOutlinedIcon from '@mui/icons-material/HighlightOutlined';
import CCMuiBarChart from "charts/mui-customization/ccMuiBarChart";
import CCMuiButton from "components/mui-customizations/ccMuiButton";
import { CCMuiCircularLoader } from "components/mui-customizations/ccMuiCircularLoader";

import { useAuth } from "auths/hooks/authHook";
import { useSetting } from "settings/settingContext";
import { useError } from "errors/errorHook";
import axiosInstance from "plugins/axiosInstance";
import ChartFields from "charts/chartFields";
import wordsUpperCase from "utilities/wordsUpperCase";


// Init chart states
const initChartStates = {
  type: ['roles'],
  period: [1],
  particulars: [],
  years: [],
}

// Init errors
const initErrors = {
  errors: {
    type: '',
    period: '',
  }
}

const BarChart = () => {
  const {isProfile} = useAuth();

  const {themeMode} = useSetting()
  // Error state
  const [errorState, setErrorState] = useState(initErrors);
  // Error context errors to display 
  const {ccGetError} = useError();
  // Chart state
  const [chartState, setChartState] = useState(initChartStates);

  // Show, hide datas
  const [showAllDynamicItems, setShowAllDynamicItems] = useState(true); // Make false not to see initial mount
  const [showAllYears, setShowAllYears] = useState(true); // Make false not to see initial mount
  const [showLoading, setShowLoading] = useState(false);

  // From API record states
  const [dataset, setDataset] = useState([]);
  const [isDataset, setIsDataset] = useState(false);

  const handleSubmit = async (e = null) => {
    if (e) e.preventDefault(); 
    
    // Fetch errors if any otherwise triggering to submit
    if (Object.keys(errorState.errors).filter(key => errorState.errors[key]).length > 0) {
      await ccGetError(errorState)
      setIsDataset(false);
    } else {

      try {
        setShowLoading(true);
        const result = await axiosInstance.post(`/${chartState.type[0]}/bar/charts`, chartState)
        if(result?.data?.status === 'success') {
          setDataset(result.data.dataset);
          setIsDataset(true);
          setShowLoading(false);
          navigate("/dashboard")
        }
      } catch (error) {
        console.log = () => {}; // Suppress error temporarily
        await ccGetError(error)
      }
    }
  }

  const handleCancel = () => {
    setChartState ( prevState => ({
      ...prevState,
      ...initChartStates,
    }));
    setShowAllDynamicItems(false);
    setShowAllYears(false);
    setErrorState(initErrors);
    setIsDataset(false);
  }

  // Fetch data when the component loads (default values)
  useEffect(() => {
    if (isProfile) {
      handleSubmit();
    }
  }, [isProfile]);

  return (
    <ChartFields 
      initChartStates={initChartStates}
      errorState={errorState} 
      setErrorState={setErrorState}
      chartState={chartState} 
      setChartState={setChartState}
      showAllDynamicItems={showAllDynamicItems}
      setShowAllDynamicItems={setShowAllDynamicItems}
      showAllYears={showAllYears}
      setShowAllYears={setShowAllYears}
      setIsDataset={setIsDataset}
    >
      {/* Save, Cancel Button */}
      <Box 
        sx={{
          gridColumn: {
            xs: 'span 12',
            sm: 'span 12',
            md: 'span 3',
            lg: 'span 3',
            xl: 'span 3',
          // textAlign: 'center'
          }
        }}
      >
        <CCMuiButton 
          startIcon={<SaveAsTwoToneIcon />}
          onClick={handleSubmit}
          sx={{bgcolor: themeMode?.ccButtonBB, px: 1.5}}
        >
          Submit
        </CCMuiButton>

        <CCMuiButton 
          startIcon={<CancelOutlinedIcon />}
          sx={{
            px: 1.5,
            mr: 0,
            bgcolor: themeMode?.ccButtonEB, 
          }}
          onClick={handleCancel}
        >
          Cancel
        </CCMuiButton>
      </Box>
      {/* End Save, Cancel Button */}

      {/* Chart dataset */}
      <Box 
        sx={{
          gridColumn: {
            xs: 'span 12',
            sm: 'span 12',
            md: 'span 3',
            lg: 'span 3',
            xl: 'span 3',
          },
        }}
      >
        {isDataset && dataset && dataset.length > 0 && (
          <Paper 
            elevation={3}
            sx={{
              padding: "10px",
              background: themeMode?.ccGlow1,
              mt:4.5
            }}
          >
            <Typography 
              variant="subtitle2" 
              textAlign="center"
              color={themeMode?.ccFontDark}
              mt={0.5}
            >
              {
              `${wordsUpperCase(chartState.type[0]) || ''} based  ${chartState.period && chartState.period[0] === 1 ? ' monthly' : ' yearly'} users`
              } 
            </Typography>
            <Typography 
              variant="body2" 
              textAlign="center"
              color={themeMode?.ccFontDark}
              mb={3}
              // fontSize={12}   
            >
              (
                <HighlightOutlinedIcon 
                  sx={{ 
                    // fontSize: 14, 
                    verticalAlign: 'middle', 
                    color: themeMode?.ccError1 || themeMode?.ccError1,
                    mr: 0.5,
                  }} 
                /> 
                Datas, based on availability, based on {new Date().getFullYear()} if no year selected.)
            </Typography>
            <CCMuiBarChart dataset={dataset} />
          </Paper>
        )}

        {/* Circular Progress Loader */}
        {showLoading && (
          <CCMuiCircularLoader />

          // <Typography 
          //   variant="subtitle1" 
          //   textAlign="center"
          //   mt={5}
          //   p={1}
          //   color={themeMode?.ccError1}
          //   border={1}
          // >
          //   <RunningWithErrorsIcon                   
          //     sx={{ 
          //       fontSize: 20, 
          //       verticalAlign: 'middle', 
                
          //       mr: 0.5,
          //     }}  
          //   />
          //   No dataset found
          // </Typography>

        )}
      </Box>
    </ChartFields>
  )
}

export default BarChart;
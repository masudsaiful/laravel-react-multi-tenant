import React, { useState, useEffect, useRef } from "react";

import { useTheme } from '@mui/material/styles';
import CCSingleSelect from "components/mui-customizations/singleSelectCustomization";
import CCMultiSelect from "components/mui-customizations/multiSelectCustomization";
import { 
  Box, 
  FormControl, 
  FormHelperText, 
  InputLabel, 
  OutlinedInput,
} from '@mui/material';

import { useAuth } from "auths/hooks/authHook";
import { useError } from "errors/errorHook";
import { useSetting } from "settings/settingContext";
import PieChart from "./pieChart";
import axiosInstance from "plugins/axiosInstance";


// Status items to select
const selectTypeItems = [
  { id: 'roles', value: 'Role' },
  { id: 'users', value: 'User' },
]

const selectPeriodItems = [
  { id: 1, value: 'Month' },
  { id: 2, value: 'Year' },
];

const ChartFields = ({
  children, 
  initChartStates,
  chartState, 
  setChartState, 
  errorState, 
  setErrorState, 
  showAllDynamicItems,
  setShowAllDynamicItems,
  showAllYears,
  setShowAllYears,
  setIsDataset,
}) => {
  
  const {themeMode} = useSetting();
  
  // Load allRoles and show conditionally based on type
  // const {allRoles} = useRole();

  const {ccGetError} = useError();

  const [ selectChartDynamicItems, setSelectChartDynamicItems] = useState([]);
  const [ selectChartYearItems, setSelectChartYearItems] = useState([]);
  const [ allChartDynamicItems, setAllChartDynamicItems] = useState([]);
  const [ allChartYearItems, setAllChartYearItems] = useState([]);

  // Theme to customize form
  const theme = useTheme();

  const {isProfile} = useAuth();

  // Handler to fetch data when changes (type, period)
  const loadAllChartRoles = async (resource) => {
    try {
      // const result = await axiosInstance.get(`roles/bar/charts`);
      const result = await axiosInstance.get(`/${resource}/bar/charts`)
      if(result?.data?.status === 'success') {
        setAllChartDynamicItems(await result.data.allChartRecords);
        setAllChartYearItems(await result.data.allChartYearRecords);
      } else {
        setAllChartDynamicItems([]);
        setAllChartYearItems([]);
      }
    } catch (error) {
      console.log = () => {}; // Suppress error temporarily
      await ccGetError(error);
    }
  }

  // Confirmed initial datas state and errors state set
  useEffect(() => {
    if (isProfile) {
      loadAllChartRoles(initChartStates.type || []); // On this if init chart form fields want to open

      setChartState ( prevState => ({
        ...prevState,
        ...chartState
      }));

      setErrorState(prevState => ({
        ...prevState,
        errors: {
          ...prevState.errors,
        }
      }));
    }
  }, [isProfile, setErrorState, setChartState]);

  // // Formatting roles fields data for drop down field
  // useEffect(()=> {
  //   const mappedRoles = allRoles.map(role => ({
  //     id: role.id, value: role.title
  //   }))
  //   setSelectChartDynamicItems(mappedRoles);
  // }, [setSelectChartDynamicItems, allRoles])

  
  // Formatting data for drop down fields
  useEffect(()=> {
    const mappedRoles = allChartDynamicItems.map(item => {
      if (item && item.id && item.title) {
        return { id: item.id, value: item.title }; // Map item if it has 'id' and 'value'
      } else {
        return { id: item, value: item }; // Handle other cases
      }
    });
    setSelectChartDynamicItems(mappedRoles);

    const mappedYears = allChartYearItems.map(year => ({
      id: year, value: year
    }));
    setSelectChartYearItems(mappedYears);
  }, [allChartDynamicItems, allChartYearItems])


  const handleSelectOptionChange = async (event) => {
    const { name, value } = event.target;
    const selectedValue = (Array.isArray(value)) && (value.length > 0) 
    ? value 
    : (typeof value === 'string' || typeof value === 'number' 
      ? [value]
       : []);

    let selectError = '';

    // Dynamic items fields toggle based on must select type
    if ( name === 'type') {
      setChartState({
        ...initChartStates
      });
      await loadAllChartRoles(value);
      setShowAllDynamicItems(true);

    } else if (name === 'period') {
      setShowAllYears(true);
      
    }

    if (selectedValue.length > 0) {
      selectError = ''
    } else {
      name === 'period' || name === 'type'  
      ? selectError = `Required valid ${name} to select`
      : selectError = '';
    }

    // Update chart state
    setChartState ( prevState => ({
      ...prevState,
      [name]: selectedValue,
    }));

    // Update the error state with errors if any
    setErrorState(prevState => ({
      ...prevState,
      errors: {
        ...prevState.errors,
        [name]: selectError
      }
    }));
    setIsDataset(false);
  };

  const getGridColumn = (name, breakpoint) => {
    if (breakpoint === 'md' || breakpoint === 'lg' ||  breakpoint === 'xl') {
      if (name === 'particulars') {
        return 'span 3';
      }else if( name === 'years') {
        return '3 / span 1'; // taking 1 column from 3rd column
      }
    }
  };

  const getGridRow = (name, breakpoint) => {
    if (breakpoint === 'md' || breakpoint === 'lg' ||  breakpoint === 'xl') {
      if (name === 'particulars') {
        return '2 / span 2'; // taking two rows from 2nd rows
      }else if( name === 'years') {
        return '1 / span 1';
      } else {
        return 'span 12'
      }
    }
  };

  const renderSelectField = (name, label, items, value = '', error = "") => (
    <FormControl
      sx={{ 
        gridColumn: {
          xs: "span 12", 
          sm: "span 12", 
          md: "span 1", 
          lg: 'span 1', 
          xl: 'span 1'
        }
      }} 
      size="small" 
      required error={false}
    >
      <InputLabel id={`${name}-label`} sx={{ color: themeMode?.ccTree2 }}>{label}</InputLabel>
      <CCSingleSelect
        name={name}
        value={value}
        id={name}
        labelId={`${name}-label`}
        onChange={handleSelectOptionChange}
        input={<OutlinedInput id={`${name}-select`} label={label} />}
        items={items}
        // multiple
      />
      <FormHelperText 
        sx={{ 
          color: error ? theme.palette.error.main : 'inherit' 
        }}
      >
        {error}
      </FormHelperText>
    </FormControl>
  );

  const renderMultiSelectField = (name, label, items, value = '', required=false, placeholder='', error = "") => (
    <FormControl 
      sx={{ 
        gridColumn: {
          xs: "span 12",
          sm: "span 12", 
          md: getGridColumn(name, 'md'),
          lg: getGridColumn(name, 'lg'),
          xl: getGridColumn(name, 'xl'),
        }, 
        gridRow: {
          xs: getGridRow(name, 'xs'),
          sm: getGridRow(name, 'sm'),
          md: getGridRow(name, 'md'),
          lg: getGridRow(name, 'lg'),
          xl: getGridRow(name, 'xl'),
        }
      }} 
      size="small" 
      required={required}
      error={false}
    >
      <InputLabel id={`${name}-label`} sx={{ color: themeMode?.ccTree2 }}>{label}</InputLabel>
      <CCMultiSelect
        name={name}
        value={value}
        id={name}
        labelId={`${name}-label`}
        placeholder={placeholder}
        onChange={handleSelectOptionChange}
        input={<OutlinedInput id={`${name}-select`} label={label} />}
        items={items}
        multiple
      />
      <FormHelperText sx={{ color: error ? theme.palette.error.main : 'inherit' }}>{error}</FormHelperText>
    </FormControl>
  );

  return (
    <Box
      component="form"
      sx={{
        display: 'grid',
        gridTemplateColumns: {
          xs:'repeat(12, 1fr)',
          sm:'repeat(12, 1fr)',
          md:'repeat(6, 1fr)',
          lg:'repeat(6, 1fr)',
          xl:'repeat(6, 1fr)',
        },
        gap: 1,
        width: '100%',
      }}
      noValidate
      autoComplete="on"
    >
      {renderSelectField('type', 'Type', selectTypeItems, chartState.type[0], errorState.errors.type)}
      {renderSelectField('period', 'Period', selectPeriodItems, chartState.period[0], errorState.errors.period)}
      { showAllDynamicItems && (
        renderMultiSelectField('particulars', 'Particular (s)', selectChartDynamicItems, chartState.particulars, false, 'List of item (s)', errorState.errors.particulars)
      )} 
      { showAllYears && (
        renderMultiSelectField('years', 'Year(s)', selectChartYearItems, chartState.years, false, errorState.errors.years)
      )} 

      <Box 
        sx={{
          gridColumn: {
            xs: 'span 12',
            sm: 'span 12',
            md: '4 / span 3',
            lg: '4 / span 3',
            xl: '4 / span 3',
          },
          gridRow: {
            xs: "1 / span 6",
            sm: "1 / span 6",
            md: "1 / span 6",
            lg: "1 / span 6",
            xl: "1 / span 6",
          },
          mb: {
            xs: 3,
            sm: 3,
          }
        }}
      >
        <PieChart />
      </Box>

      {children}
    </Box>
  );
};

export default ChartFields;
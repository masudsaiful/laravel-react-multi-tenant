<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Setting\SettingController;

Route::prefix('settings')
    ->namespace('Setting')
    ->middleware('auth:sanctum')
    ->group(function () {
        Route::post('theme-mode', [SettingController::class, 'prepareThemeMode']);
        Route::get('theme-mode/{id}', [SettingController::class, 'getThemeMode']);
    });

<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\User\UserController;

Route::middleware('auth:sanctum')
    ->namespace('User')
    ->group(function () {
        Route::apiResource('users', UserController::class);
    });

<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Role\RoleController;

Route::middleware('auth:sanctum')
    ->namespace('Role')
    ->group(function () {
        Route::apiResource('roles', RoleController::class);
    });

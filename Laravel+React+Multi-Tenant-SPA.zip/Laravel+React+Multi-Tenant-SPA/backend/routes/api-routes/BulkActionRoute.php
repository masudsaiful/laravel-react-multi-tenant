<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\BulkAction\BulkActionController;

/*
|--------------------------------------------------------------------------
| API Bulk Action Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
| dynamic route parameter ({resource}) to capture the URL segment e.g, 'users'
| dynamic route parameter ({resource}) to capture the URL segment e.g, 'users'
|
*/

// Route::prefix('{resource}/{resourceType}')
//   ->middleware('auth:sanctum')
//   ->namespace('BulkAction')
//   ->group(function () {
//     Route::post('bulkDelete', [BulkDetachController::class, 'bulkDelete']);
//     Route::get('bulkActionAttach', [BulkActionAttachController::class, 'bulkActionAttach']);
//     Route::get('bulkActionDetach', [BulkActionDetachController::class, 'bulkActionDetach']);
//   });

  // Route::prefix('{resource}/{action}')
  // ->middleware('auth:sanctum')
  // ->namespace('BulkAction')
  // ->group(function () {
  //     Route::match(['post'], 'bulk', function ($resource, $action) {
  //       return app(BulkActionController::class)->bulkAction(request(), $resource, $action);
  //     });
  //     Route::match(['get'], 'bulk', function ($resource, $action) {
  //       return app(BulkActionController::class)->bulkFetch(request(), $resource, $action);
  //     });
  // });

  Route::middleware('auth:sanctum')
  ->namespace('BulkAction')
  ->group(function () {
      Route::post('{resourceName}/{actionName}/bulk', [BulkActionController::class, 'bulkAction']);
      Route::get('{resourceName}/{actionName}/bulk', [BulkActionController::class, 'bulkFetch']);
  });

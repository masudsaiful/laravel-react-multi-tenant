<?php
ini_set('memory_limit', '256M'); // Prevent memory issues
set_time_limit(30); // Prevent script timeout

// Read the π digits from the file
$piDigits = file_get_contents("pi_1million.txt");
if (!$piDigits) {
    die("Error: Could not read π file.");
}

// Remove spaces and newlines (if any exist)
$piDigits = preg_replace("/\s+/", "", $piDigits);

// Ensure "3." is removed correctly
if (substr($piDigits, 0, 2) === "3.") {
    $piDigits = substr($piDigits, 2); // Remove "3."
} else {
    $piDigits = substr($piDigits, 1); // Remove just "3" if "." isn't present
}

// Count occurrences of "6969"
$count = substr_count($piDigits, "6969");

if ($count > 0) {
    echo '"6969" found ' . $count . ' times in π’s first 1M digits!';
} else {
    echo '"6969" NOT found in π’s first 1M digits!';
}
?>

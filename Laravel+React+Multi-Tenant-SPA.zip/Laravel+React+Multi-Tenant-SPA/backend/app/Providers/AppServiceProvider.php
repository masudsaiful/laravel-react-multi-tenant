<?php

namespace App\Providers;

use App\Models\Role\Role;
use App\Models\User\User;
// In AppServiceProvider.php
use Laravel\Sanctum\Sanctum;
use App\Policies\Role\RolePolicy;
use App\Policies\User\UserPolicy;
use App\Policies\Auth\ProfilePolicy;

use Illuminate\Support\Facades\Gate;
use App\Models\Permission\Permission;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\ServiceProvider;
use App\Listeners\Chart\RoleBarChartListener;
use App\Policies\Permission\PermissionPolicy;
use App\Repositories\QueryRepository\UserQueryRepository\UserSqlQueryRepository;
use App\Repositories\QueryRepository\UserQueryRepository\UserQueryRepository;
use App\Repositories\FilteringRepository\UserFilteringRepository\UserSqlFilteringRepository;
use App\Repositories\FilteringRepository\UserFilteringRepository\UserFilteringRepository;
use App\Repositories\SortingRepository\UserSortingRepository\UserSqlSortingRepository;
use App\Repositories\SortingRepository\UserSortingRepository\UserSortingRepository;
use App\Repositories\MappingRepository\UserMappingRepository\UserMappingRepository;
use App\Repositories\DescendantRepository;



class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $repositories = [
            UserSqlQueryRepository::class,
            UserQueryRepository::class,
            UserSqlFilteringRepository::class,
            UserFilteringRepository::class,
            UserSqlSortingRepository::class,
            UserSortingRepository::class,
            UserMappingRepository::class,
            DescendantRepository::class,
        ];
        
        // // User Sql Query Repository
        // $this->app->singleton(UserSqlQueryRepository::class, function ($app) {
        //     return new UserSqlQueryRepository();
        // });

        foreach ($repositories as $repository) {
            $this->app->singleton($repository, $repository);
        }
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Observer can also be registered in boot method of the specific model.
        // User::observe(UserObserver::class);
        // Role::observe(RoleObserver::class);

        // For manually event registered
        // Event::listen(
        //     UserEvent::class,
        //     UserListener::class,
        //     RoleEvent::class,
        //     RoleListener::class,
        //     RoleBarChartListener::class,
        // );

        //Sanctum::ignoreCsrfToken(true);
        // config(['session.domain' => env('SESSION_DOMAIN', '.localhost:3000')]);

        // Policies register
        Gate::policy(Permission::class, PermissionPolicy::class);
        Gate::policy(User::class, UserPolicy::class);
        Gate::policy(Role::class, RolePolicy::class);
        Gate::define('view-profile', [ProfilePolicy::class, 'view']);
        Gate::define('update-profile', [ProfilePolicy::class, 'update']);
    }
}

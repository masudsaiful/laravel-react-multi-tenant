<?php

namespace App\Repositories\FilteringRepository\RoleFilteringRepository;

class RoleFilteringRepository
{
    /**
     * Apply filtering to the data.
     *
     * @param $data query builder instance.
     * @param array|string|null $filterModel The filtering criteria.
     * @return <filtered query builder>.
     */
    public function applyEloqFiltering($query, $filterModel)
    {
        // Step 1: Validate input types
        if (($query instanceof \Illuminate\Support\Collection)) {
            throw new \InvalidArgumentException('Expected $data to be a Query Builder Instance.');
        }

        if (empty($filterModel)) {
            return $query;
        }

        if (is_string($filterModel)) {
            $filterModel = json_decode($filterModel, true);
        }

        if (empty($filterModel) || !is_array($filterModel)) {
            throw new \InvalidArgumentException('Expected $filterModel to be a non-empty array or valid JSON string.');
        }

        // Step 2: Process filtering using a pipeline pattern
        if (isset($filterModel['items']) && !empty($filterModel['items'])) {
            foreach ($filterModel['items'] as $filter) {
                if (isset($filter['field'], $filter['value'])) {
                    $field = $filter['field'];
                    $value = $filter['value'];

                    if (!$field || !$value) {
                        continue; // Skip if field or value is missing
                    }

                    $value = strtolower(trim($value));

                    $query = $this->applyFilter($query, $field, $value);
                }
            }
        }

        return $query;
    }

    private function applyFilter($query, $field, $value)
    {
        switch ($field) {
            case 'status':
                return $this->filterByStatus($query, $value);
            default:
                return $this->filterByGeneralField($query, $field, $value);
        }
    }

    private function filterByStatus($query, $value)
    {
        $statusMap = [
            'enable' => 1,
            'disable' => 2,
        ];
        $statusValue = $statusMap[$value] ?? null;

        $query->whereJsonContains('roles.status', $statusValue);

        return $query;
    }

    private function filterByGeneralField($query, $field, $value)
    {
        return $query->where($field, 'LIKE', "%$value%");
    }
}

<?php

namespace App\Repositories\FilteringRepository\UserFilteringRepository;

use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;

use App\Models\User\User;

class UserSqlFilteringRepository
{
    /**
     * Apply filtering to the data.
     *
     * @param \Illuminate\Support\Collection $data The data to filter.
     * @param array|string|null $filterModel The filtering criteria.
     * @return \Illuminate\Support\Collection The filtered data.
     */
    public function applyFiltering($data, $filterModel)
    {
        // Step 1: Validate input types
        if (!($data instanceof \Illuminate\Support\Collection)) {
            throw new \InvalidArgumentException('Expected $data to be a Laravel Collection.');
        }

        if (empty($filterModel)) {
            return $data;
        }

        if (is_string($filterModel)) {
            $filterModel = json_decode($filterModel, true);
        }

        if (empty($filterModel) || !is_array($filterModel)) {
            throw new \InvalidArgumentException('Expected $filterModel to be a non-empty array or valid JSON string.');
        }

        // Step 2: Process filtering using a pipeline pattern
        if (isset($filterModel['items']) && !empty($filterModel['items'])) {
            foreach ($filterModel['items'] as $filter) {
                if (isset($filter['field'], $filter['value'])) {
                    $field = $filter['field'];
                    $value = $filter['value'];

                    if (!$field || !$value) {
                        continue; // Skip if field or value is missing
                    }

                    $value = strtolower(trim($value));

                    $data = $this->applyFilter($data, $field, $value);
                }
            }
        }

        return $data;
    }

    private function applyFilter($data, $field, $value)
    {
        switch ($field) {
            case 'status':
                return $this->filterByStatus($data, $value);
            case 'roles':
                return $this->filterByRoles($data, $value);
            default:
                return $this->filterByGeneralField($data, $field, $value);
        }
    }

    private function filterByStatus($data, $value)
    {
        $statusMap = [
            'enable' => [1],
            'disable' => [2],
        ];
        $statusValue = $statusMap[$value] ?? null;

        if ($statusValue) {
            $data = $data->filter(function ($item) use ($statusValue) {
                $itemStatus = is_array($item->status) ? $item->status : json_decode($item->status, true);
                return is_array($itemStatus) && !empty(array_intersect($itemStatus, $statusValue));
            });
        }

        return $data;
    }

    private function filterByRoles($data, $value)
    {
        return $data->filter(function ($item) use ($value) {
            return $item->roles->contains(function ($role) use ($value) {
                return stripos($role->title, $value) !== false || stripos($role->name, $value) !== false;
            });
        });
    }

    private function filterByGeneralField($data, $field, $value)
    {
        return $data->filter(function ($item) use ($field, $value) {
            return stripos(strtolower($item->$field), $value) !== false;
        });
    }
}

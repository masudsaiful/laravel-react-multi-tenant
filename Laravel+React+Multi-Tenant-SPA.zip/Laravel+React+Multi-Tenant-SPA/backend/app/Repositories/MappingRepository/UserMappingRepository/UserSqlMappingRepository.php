<?php

namespace App\Repositories\MappingRepository\UserMappingRepository;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;

use App\Models\User\User;

class UserSqlMappingRepository
{
    /**
     * Apply relationship mapping with optimized performance.
     *
     * This method retrieves users with their roles where the role's status is active (1),
     * ensuring optimized query execution while avoiding the N+1 query problem.
     *
     * @param \Illuminate\Support\Collection $collection The collection of users.
     * @return \Illuminate\Database\Eloquent\Collection The mapped user collection with roles.
     */
    public function applySqlRelationMapping($collection)
    {
        $userIds = $collection->pluck('id');
        $query = User::with([
            'roles' => function ($q) {
                $q->whereJsonContains('roles.status', 1);
            },
        ])->whereIn('users.id', $userIds)
        ->latest();

        return $this->applyMapping($query);
    }

    /**
     * Process and map user roles and permissions while optimizing memory usage.
     *
     * This method processes users in chunks to minimize memory consumption and ensures
     * that permissions are correctly mapped based on user roles and specific filtering conditions.
     *
     * @param \Illuminate\Database\Eloquent\Builder $query The user query builder instance.
     * @return \Illuminate\Database\Eloquent\Collection The processed user collection with loaded permissions.
     */
    public function applyMapping($query)
    {
        $processedUsers = collect();

        $query->chunk(100, function ($chunk) use ($processedUsers) {
            // Process each chunk of users
            $chunk->each(function ($user) use ($processedUsers) {
                $user->roles->load(['permissions' => function ($q) use ($user) { 

                    /**
                     * Retrieve permissions based on the user's roles and conditions:
                     * - Include permissions where `user_id` contains the user.
                     * - Include permissions with an empty `user_id` if no conflicts exist.
                     * - Exclude permissions where `user_id` contains other users but not the current user.
                     * - Exclude permissions of 'user_id' blank for same model of 'user_id' contains user.
                     */
                    $q->where(function($wn) use ($user) {
                        $wn->whereJsonContains('permissions.user_id', $user->id)
                        ->orWhere(function($ow) {
                            $ow->whereJsonLength('permissions.user_id', 0);
                        });
                    })
                    ->whereNot(function ($query) use ($user) {
                        // $permissionModels = DB::table('permissions')
                        // ->whereJsonContains('permissions.user_id', $user->id)
                        // ->pluck('model');
                        $cloneQuery = clone $query;
                        $permissionModels = $cloneQuery->whereJsonContains(
                            'permissions.user_id', $user->id
                        )->pluck('model');

                        if ($permissionModels->isNotEmpty()) { 
                            $query->when(
                                $permissionModels,
                                function (Builder $sq, $permissionModels) {
                                    $sq->whereJsonLength('permissions.user_id', 0)
                                    ->whereIn('permissions.model', $permissionModels);
                                },
                                function (Builder $sq, $user){
                                    $sq->whereJsonContains('permissions.user_id', '!=', $user->id);
                                },
                            );
                        } else {
                            $query->whereJsonContains('permissions.user_id', !$user->id)
                            ->whereJsonLength('permissions.user_id', '>', 0);

                        }
                    });
                }]);

                // Append processed user to the collection
                $processedUsers->push($user);
            });
        });

        return $processedUsers;
    }
}

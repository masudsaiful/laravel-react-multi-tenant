<?php

namespace App\Repositories\MappingRepository\UserMappingRepository;

// class UserMappingRepository
// {
//     /**
//      * Apply relationship mapping with optimized performance
//      *
//      * @return \Illuminate\Support\LazyCollection
//      */
//     public function applyEloqRelationMapping($query)
//     {
//         $query->with([
//             'roles' => function ($q) {
//                 $q->whereJsonContains('roles.status', 1)->with('permissions');
//             },
//         ])->latest();

//         return $this->applyMapping($query);
//     }

//     /**
//      * Apply relationship and status filtering
//      *
//      * @return \Illuminate\Support\LazyCollection
//      */
//     public function applyEloqStatusRelationMapping($query)
//     {
//         $query->with([
//             'roles' => function ($q) {
//                 $q->whereJsonContains('roles.status', 1)->with('permissions');
//             },
//         ])
//         ->whereJsonContains('users.status', 1)
//         ->latest();

//         return $this->applyMapping($query);
//     }

//     /**
//      * Process and map data lazily to reduce memory usage
//      *
//      * @return \Illuminate\Support\LazyCollection
//      */
//     public function applyMapping($query)
//     {
//         // Use lazy() to handle large datasets
//         return $query->cursor()->map(function ($user) {
//             $user->roles->each(function ($role) use ($user) {
//                 $role->permissions()->where(function($q) use($role, $user) {
//                     $q->where('permissions.role_id', $role->id)
//                     ->where(function ($sq) use ($user) {
//                         $sq->whereJsonContains('permissions.user_id', $user->id);
//                         $sq->orWhere(function ($ssq) {
//                             $ssq->whereJsonLength('permissions.user_id', 0);
//                         });
//                     });
//                 });
//             });

//             return $user;
//         });
//     }
// }




class UserMappingRepository
{
    /**
     * Apply relationship mapping to retrieve users with their roles and permissions.
     * Ensures that roles have active statuses and permissions are eager-loaded.
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query The query builder instance.
     * @return \Illuminate\Support\LazyCollection Lazily processed collection of users.
     */
    public function applyEloqRelationMapping($query)
    {
        $query->with([
            'roles' => function ($q) {
                $q->whereJsonContains('roles.status', 1)->with('permissions');
            },
        ])->latest();

        return $this->applyMapping($query);
    }

    /**
     * Apply relationship mapping with an additional filter for active users.
     * Ensures that roles have active statuses and permissions are eager-loaded.
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query The query builder instance.
     * @return \Illuminate\Support\LazyCollection Lazily processed collection of active users.
     */
    public function applyEloqStatusRelationMapping($query)
    {
        $query->with([
            'roles' => function ($q) {
                $q->whereJsonContains('roles.status', 1)->with('permissions');
            },
        ])
        ->whereJsonContains('users.status', 1)
        ->latest();

        return $this->applyMapping($query);
    }

    /**
     * Process and map data using lazy loading to reduce memory usage.
     * Filters permissions based on user_id presence and avoids redundant permissions.
     * Ensures proper collection indexing and minimizes in-memory processing.
     * 
     * @param \Illuminate\Database\Eloquent\Builder $query The query builder instance.
     * @return \Illuminate\Support\Collection A properly indexed processed collection of users.
     */
    public function applyMapping($query)
    {
        // Declare a collection to store results
        $processedUsers = collect();

        // Use lazy() to handle large datasets
        $query->cursor()->each(function ($user) use ($processedUsers) {
            $user->roles->each(function ($role) use ($user) {
                                    /**
                 * Retrieve permissions based on the user's roles and conditions:
                 * - Include permissions where `user_id` contains the user.
                 * - Include permissions with an empty `user_id` if no conflicts exist.
                 * - Exclude permissions where `user_id` contains other users but not the current user.
                 * - Exclude permissions of 'user_id' blank for same model of 'user_id' contains user.
                 */
                $permissionUsers = $role->permissions->filter(function ($permission) use($user) {
                    return collect($permission->user_id)->contains($user->id) || empty($permission->user_id);
                });

                $permissionModels = $permissionUsers->filter(function ($permission) use($user) {
                    return collect($permission->user_id)->contains($user->id);
                });

                $permissionModels = $permissionModels->pluck('model');

                $permissionUsers1 = $permissionUsers->reject(function ($permission) use($permissionModels) {
                    return collect($permissionModels)->contains($permission->model) && collect($permission->user_id)->isEmpty();
                });

                // Correctly assign filtered permissions to the role
                $role->setRelation('permissions', $permissionUsers1->values());
            });

            // Push processed user into the collection
            $processedUsers->push($user);
        });

        // Ensure proper re-indexing [0,1,2,3...] before returning
        return $processedUsers;
    }
}





// class UserMappingRepository
// {
//     /**
//      * Apply relationship mapping
//      *
//      * @return \Illuminate\Support\LazyCollection
//      */
//     public function applyEloqRelationMapping($query)
//     {
//         $query->with([
//             'roles' => function ($q) {
//                 $q->whereJsonContains('roles.status', 1)->with('permissions');
//             },
//         ])->latest();

//         return $this->applyMapping($query);
//     }

//     /**
//      * Apply relationship and status filtering mapping
//      *
//      * @return \Illuminate\Support\LazyCollection
//      */
//     public function applyEloqStatusRelationMapping($query)
//     {
//         $query->with([
//             'roles' => function ($q) {
//                 $q->whereJsonContains('roles.status', 1)->with('permissions');
//             },
//         ])
//         ->whereJsonContains('users.status', 1)
//         ->latest();

//         return $this->applyMapping($query);
//     }

//     /**
//      * Process and map data lazily to reduce memory usage
//      *
//      * @return \Illuminate\Support\LazyCollection
//      */
//     public function applyMapping($query)
//     {
//         // Use lazy() to handle large datasets
//         return $query->lazy()->map(function ($user) {
//             $user->roles->each(function ($role) use ($user) {
//                 $permissionUsers = $role->permissions->filter(function ($permission) use($user) {
//                     return collect($permission->user_id)->contains($user->id) || empty($permission->user_id);
//                 });

//                 $permissionModels = $permissionUsers->filter(function ($permission) use($user) {
//                     return collect($permission->user_id)->contains($user->id);
//                 });

//                 $permissionModels = $permissionModels->pluck('model');

//                 $permissionUsers = $permissionUsers->reject(function ($permission) use($permissionModels) {
//                     return collect($permissionModels)->contains($permission->model) && collect($permission->user_id)->isEmpty();
//                 });

//                 // Replace role permissions with filtered results
//                 return $permissionUsers;
//             });

//             return $user;
//         });
//     }
// }


// class UserMappingRepository {
//     /**
//      * Datas lazy loading relationship models
//      *
//      * @return <collections>
//      */
//     public function applyEloqRelationMapping($query)
//     {
//         $query->with([
//             'roles' => function ($q) {
//                 $q->whereJsonContains('roles.status', 1);
//             },
//             'roles.permissions',
//         ])
//         ->latest();

//         return $this->applyMapping($query);
//     }

//     /**
//      * Datas lazy loading relationship models
//      * filtered by status
//      *
//      * @return <collections>
//      */
//     public function applyEloqStatusRelationMapping($query)
//     {
//         $query->with([
//             'roles' => function ($q) {
//                 $q->whereJsonContains('roles.status', 1);
//             },
//             'roles.permissions',
//         ])
//         ->whereJsonContains('users.status', 1)
//         ->latest();

//         return $this->applyMapping($query);
//     }

//     /**
//      * Datas lazy loading relationship models
//      *
//      * @return <collections>
//      */
//     public function applyMapping($query) {
//         // Iterate over query to filter permissions
//         return $query->cursor()->map(function ($user) {
//             $user->roles->each(function ($role) use ($user) {
//                 $role->permissions = $role->permissions->filter(function ($permission) use ($role, $user) {
//                     return collect($permission->user_id)->contains($user->id) || empty($permission->user_id);
//                 });
//             });
        
//             return $user;
//         });
//     }
// }
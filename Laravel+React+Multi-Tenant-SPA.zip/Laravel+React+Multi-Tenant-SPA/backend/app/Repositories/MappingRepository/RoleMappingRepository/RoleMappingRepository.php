<?php

namespace App\Repositories\MappingRepository\RoleMappingRepository;

class RoleMappingRepository {
    /**
     * Datas lazy loading relationship models
     *
     * @return <collections>
     */
    public function applyEloqRelationMapping($query)
    {
        $query->with('permissions')->latest();

        return $this->applyMapping($query);
    }

    /**
     * Datas lazy loading relationship models
     * filtered by status
     *
     * @return <collections>
     */
    public function applyEloqStatusRelationMapping($query)
    {
        $query->with('permissions')
        ->whereJsonContains('roles.status', 1)
        ->latest();

        return $this->applyMapping($query);
    }

    /**
     * Datas lazy loading relationship models
     *
     * @return <collections>
     */
    public function applyMapping($query)
    {
        return $query->get();
    }
}
<?php

namespace App\Repositories\DescendantRepository\DescendantUserRepository;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

use App\Models\User\DescendantUser;

class DescendantUserRepository
{
    /**
     * Fetch all descendant records using Eloquent.
     *
     * Retrieves descendant records for a given model class and user ID,
     * including all records created by the user and their entire hierarchy.
     * Applies filters, sorting, and pagination.
     *
     * @param string $modelClass The Eloquent model class to query.
     * @param int $authId The ID of the authenticated user.
     * @param int $page The current page number for pagination.
     * @param int $pageSize The number of records per page.
     * @param array|object $filterModel Filtering criteria as an array or JSON object.
     * @param array|object $sortModel Sorting criteria as an array or JSON object.
     * @return array An array containing paginated results and status-filtered data.
     */
    public function getDescendantIds(string $modelClass, int $authId) {
        // For other Auth IDs, collect descendant IDs recursively
        $mergedIds = $this->descendantRecursive($modelClass, $authId);

        // Exclude the Auth ID itself
        $mergedIds = $mergedIds->filter(fn($id) => $id !== $authId);

        // Store or update the data in the `user_descendants` table
        DescendantUser::updateOrCreate(
            ['user_id' => $authId],
            ['descendant_ids' => $mergedIds]
        );

        // Return the ids
        return $mergedIds;
    }

    /**
     * Collect descendant IDs recursively.
     *
     * @param string $modelClass The Eloquent model class to query.
     * @param int $authId The ID of the authenticated user.
     * @return \Illuminate\Support\Collection A collection of all descendant IDs.
     */
    private function descendantRecursive($modelClass, $authId)
    {
        $ids = collect([]); // Store all collected descendant IDs
        $queue = collect([$authId]); // Start the queue with the Auth ID
        $processedIds = collect([]); // Track already-processed IDs to avoid duplicates
    
        while ($queue->isNotEmpty()) {
            // Fetch next level descendant IDs, excluding already processed IDs
            $nextIds = $modelClass::whereIn('users.created_by', $queue->toArray())
                ->whereNotIn('users.id', $processedIds->toArray())
                ->pluck('users.id');
    
            // If no new IDs are found, break the loop
            if ($nextIds->isEmpty()) {
                break;
            }
    
            // Add the next IDs to the processed list to prevent re-processing
            $processedIds = $processedIds->merge($queue);
    
            // Merge the next IDs into the collected IDs
            $ids = $ids->merge($nextIds);
    
            // Prepare the next queue
            $queue = $nextIds;
        }

        // Return unique IDs
        return $ids->unique();
    }
}

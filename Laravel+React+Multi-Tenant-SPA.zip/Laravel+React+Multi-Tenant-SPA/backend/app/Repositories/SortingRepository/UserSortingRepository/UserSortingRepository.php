<?php

namespace App\Repositories\SortingRepository\UserSortingRepository;
use Illuminate\Support\Facades\DB;


class UserSortingRepository {

  /**
   * Apply sorting to the data based on the sort model.
   * @param mixed $data
   * @param mixed $sortModel
   * @return <collections>
   */
  public function applyEloqSorting($query, $sortModel)
  {
    if (empty($sortModel)) {
        return $query;
    }

    if (is_string($sortModel)) {
        $sortModel = json_decode($sortModel, true);
    }
    if (empty($sortModel) || !is_array($sortModel)) {
        return $query;
    }

    foreach ($sortModel as $sort) {
        if (
            isset($sort['field'], $sort['sort']) &&
            is_string($sort['field']) &&
            in_array(strtolower($sort['sort']), ['asc', 'desc'])
        ) {
            $field = $sort['field'];
            $order = strtolower($sort['sort']) === 'asc' ? 'asc' : 'desc';

            if (in_array($field, ['id', 'name', 'username', 'email', 
                'created_by', 'updated_by', 'created_at', 
                'updated_at'])) {
                // Apply sorting to simple fields
                $query->orderBy("users.{$field}", $order);

            } elseif ($field === 'status') {
                // Sorting by JSON field status
                $query->orderByRaw("JSON_UNQUOTE(JSON_EXTRACT(users.status, '$[0]')) $order");

            } elseif (in_array($field, ['roles', 'roles.title', 'roles.name'])) {
                // Simplified sorting using whereHas with concatenated roles.title and roles.name
                // $query->whereHas('roles', function ($query) use ($order) {
                //     $query->orderByRaw("CONCAT(roles.title, ' ', roles.name) $order");
                // });

                $query->where(function ($query) use ($order) {
                    $query->whereHas('roles', function ($subQuery) {
                        $subQuery->select(DB::raw("CONCAT(roles.title, ' ', roles.name) as role_full_name"));
                    })
                    ->orDoesntHave('roles');
                })
                ->orderByRaw("
                    CASE 
                        WHEN EXISTS (
                            SELECT 1 FROM roles 
                            INNER JOIN role_user ON roles.id = role_user.role_id 
                            WHERE role_user.user_id = users.id
                        ) 
                        THEN (
                            SELECT CONCAT(roles.title, ' ', roles.name) 
                            FROM roles 
                            INNER JOIN role_user ON roles.id = role_user.role_id 
                            WHERE role_user.user_id = users.id 
                            LIMIT 1
                        ) 
                        ELSE ''
                    END $order
                "); // Sort by roles.title + roles.name
            }
        }
    }

    return $query;
  }
}
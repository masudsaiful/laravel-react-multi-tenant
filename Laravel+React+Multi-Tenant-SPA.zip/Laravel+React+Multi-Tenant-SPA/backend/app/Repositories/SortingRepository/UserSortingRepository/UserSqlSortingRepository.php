<?php

namespace App\Repositories\SortingRepository\UserSortingRepository;

class UserSqlSortingRepository {

  /**
   * Apply sorting to the data based on the sort model.
   * @param mixed $data
   * @param mixed $sortModel
   * @return <collections>
   */
  public function applySorting($data, $sortModel)
  {
    if (empty($sortModel)) {
        return $data;
    }

    if (is_string($sortModel)) {
        $sortModel = json_decode($sortModel, true);
    }
    if (empty($sortModel) || !is_array($sortModel)) {
        return $data;
    }

    foreach ($sortModel as $sort) {
      if (
          isset($sort['field'], $sort['sort']) &&
          is_string($sort['field']) &&
          in_array(strtolower($sort['sort']), ['asc', 'desc'])
      ) {
          $field = $sort['field'];
          $order = strtolower($sort['sort']) === 'asc' ? SORT_ASC : SORT_DESC;

          if (in_array($field, ['id', 'name', 'username', 'email', 
              'created_by', 'updated_by', 'created_at', 
              'updated_at'])) {
              // Case-insensitive sorting for string fields
              $data = $data->sortBy(function ($item) use ($field) {
                  return strtolower($item->$field);
              }, SORT_REGULAR, $order === SORT_DESC);

          } elseif ($field === 'status') {
              // Handle sorting for the status JSON array
              $data = $data->sortBy(function ($item) {
                  // Convert the status array into a sortable string (e.g., joining values)
                  return is_array($item->status) ? implode(',', $item->status) : '';
              }, SORT_REGULAR, $order === SORT_DESC);

          } elseif (in_array($field, ['roles', 'roles.title', 'roles.name'])) {
              $data = $data->sortBy(function ($user) use ($field) {
                  if ($field === 'roles') {
                      return $user->roles->map(function ($role) {
                          return $role->title . ' ' . $role->name;
                      })->join(', ');
                  }
              }, SORT_REGULAR, $order === SORT_DESC);
          }
      }
    }

    return $data;
  }
}
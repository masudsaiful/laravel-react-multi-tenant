<?php

namespace App\Repositories\SortingRepository\RoleSortingRepository;
use Illuminate\Support\Facades\DB;


class RoleSortingRepository {

  /**
   * Apply sorting to the data based on the sort model.
   * @param mixed $data
   * @param mixed $sortModel
   * @return <collections>
   */
  public function applyEloqSorting($query, $sortModel)
  {
    if (empty($sortModel)) {
        return $query;
    }

    if (is_string($sortModel)) {
        $sortModel = json_decode($sortModel, true);
    }
    if (empty($sortModel) || !is_array($sortModel)) {
        return $query;
    }

    foreach ($sortModel as $sort) {
        if (
            isset($sort['field'], $sort['sort']) &&
            is_string($sort['field']) &&
            in_array(strtolower($sort['sort']), ['asc', 'desc'])
        ) {
            $field = $sort['field'];
            $order = strtolower($sort['sort']) === 'asc' ? 'asc' : 'desc';

            if (in_array($field, ['id', 'name', 'title', 'email', 
                'created_by', 'updated_by', 'created_at', 
                'updated_at'])) {
                // Apply sorting to simple fields
                $query->orderBy("roles.{$field}", $order);

            } elseif ($field === 'status') {
                // Sorting by JSON field status
                $query->orderByRaw("JSON_UNQUOTE(JSON_EXTRACT(roles.status, '$[0]')) $order");

            }
        }
    }

    return $query;
  }
}
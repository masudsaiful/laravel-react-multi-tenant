<?php

namespace App\Repositories\QueryRepository\UserQueryRepository;

use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;

use App\Models\User\User;
use App\Repositories\FilteringRepository\UserFilteringRepository\UserFilteringRepository;
use App\Repositories\SortingRepository\UserSortingRepository\UserSortingRepository;
use App\Repositories\MappingRepository\UserMappingRepository\UserMappingRepository;
use App\Repositories\DescendantRepository\DescendantUserRepository\DescendantUserRepository;
use App\Helpers\Utilities;

class UserQueryRepository
{
    protected $userSqlFilteringRepository;
    protected $userSqlSortingRepository;
    protected $userFilteringRepository;
    protected $userSortingRepository;
    protected $userMappingRepository;
    protected $decendantUserRepository;

    public function __construct( 
        UserFilteringRepository $userFilteringRepository,
        UserSortingRepository $userSortingRepository,
        UserMappingRepository $userMappingRepository,
        DescendantUserRepository $decendantUserRepository
    ) {
        $this->userFilteringRepository = $userFilteringRepository;
        $this->userSortingRepository = $userSortingRepository;
        $this->userMappingRepository = $userMappingRepository;
        $this->decendantUserRepository = $decendantUserRepository;
    }

    /**
     * Fetch all descendant records using Eloquent.
     *
     * Retrieves descendant records for a given model class and user ID,
     * including all records created by the user and their entire hierarchy.
     * Applies filters, sorting, and pagination.
     *
     * @param string $modelClass The Eloquent model class to query.
     * @param int $authId The ID of the authenticated user.
     * @param int $page The current page number for pagination.
     * @param int $pageSize The number of records per page.
     * @param array|object $filterModel Filtering criteria as an array or JSON object.
     * @param array|object $sortModel Sorting criteria as an array or JSON object.
     * @return array An array containing paginated results and status-filtered data.
     */
    public function getDescendantByEloq(
        int $page, 
        int $pageSize, 
        $filterModel,
        $sortModel,
    ) {
        $authId = Auth::id();

        if ($authId === 1) {
            // Fetch all records except where id = 1
            $query = User::where('users.id', '!=', $authId);
        } else {
            /** 
             * For other Auth IDs, collect descendant IDs recursively
             * @var \Illuminate\Support\Collection $descendantIds 
             */
            $descendantIds = $this->decendantUserRepository->getDescendantIds(
                User::class, $authId
            );

            // // Exclude the Auth ID itself
            // $descendantIds = $descendantIds->filter(fn($id) => $id !== $authId);
    
            // // Convert collection to array before using in whereIn
            // $query = $modelClass::whereIn('created_by', $descendantIds->toArray());

            // Convert collection to array before using in whereIn
            $query = User::whereIn('users.id', $descendantIds);
        }

        // Clone the original query to avoid modification conflicts
        $queryPaginate = clone $query;
        $queryStatusFiltered = clone $query;

        // Apply filtering, sorting
        $filtered = $this->userFilteringRepository->applyEloqFiltering($queryPaginate, $filterModel);
        $sorted = $this->userSortingRepository->applyEloqSorting($filtered, $sortModel);
        
        // Apply pagination
        $paginated = $sorted->paginate($pageSize, ['*'], 'page', $page);
        $tatalCount = $paginated->total();

        /** 
         * Relation mapped items included descendant relationship expected for view listing
         * status filtered mapped same but filtered by status expected to use in select option
         * @var \Illuminate\Support\Collection $descendantIds 
         */
        $relationMapped = $this->userMappingRepository->applyEloqRelationMapping($sorted);
        $statusRelationMapped = $this->userMappingRepository->applyEloqStatusRelationMapping($queryStatusFiltered);

        // Return the response structure expected by the UserController
        return [
            'paginated' => new LengthAwarePaginator(
                $relationMapped, 
                $tatalCount, 
                $pageSize, 
                $page
            ),
            'statusFiltered' => $statusRelationMapped,
        ];
    }
}

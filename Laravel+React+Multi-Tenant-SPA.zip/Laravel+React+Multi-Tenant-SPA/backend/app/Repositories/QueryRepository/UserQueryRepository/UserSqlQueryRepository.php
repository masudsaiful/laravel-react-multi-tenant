<?php

namespace App\Repositories\QueryRepository\UserQueryRepository;

use App\Models\User\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Pagination\LengthAwarePaginator;
use App\Repositories\SortingRepository\UserSortingRepository\UserSqlSortingRepository;
use App\Repositories\FilteringRepository\UserFilteringRepository\UserSqlFilteringRepository;
use App\Repositories\MappingRepository\UserMappingRepository\UserSqlMappingRepository;

class UserSqlQueryRepository
{
    protected $userSqlFilteringRepository;
    protected $userSqlSortingRepository;
    protected $userSqlMappingRepository;

    public function __construct( 
        UserSqlFilteringRepository $userSqlFilteringRepository,
        UserSqlSortingRepository $userSqlSortingRepository,
        UserSqlMappingRepository $userSqlMappingRepository,
    ) {
        $this->userSqlFilteringRepository = $userSqlFilteringRepository;
        $this->userSqlSortingRepository = $userSqlSortingRepository;
        $this->userSqlMappingRepository = $userSqlMappingRepository;
    }

    /**
     * Fetch all descendant records using raw SQL.
     *
     * This method retrieves descendant records for a given model class and user ID,
     * retrieve all descendant records for super admin (id 1)
     * retrieve all descendant records created by user ID and the chaining under the user ID
     * applying filters and pagination.
     *
     * @param string $modelClass The model class to query.
     * @param int $authId The ID of the authenticated user.
     * @param int $page The current page number for pagination.
     * @param int $pageSize The number of records per page.
     * @param mixed $filterModel The filtering criteria (array or JSON string).
     * @return array An array containing paginated results and status-filtered data.
     */
    public function getDescendantByRawSQL(
        string $modelClass, 
        int $authId, 
        int $page, 
        int $pageSize, 
        $filterModel,
        $sortModel,
    ) {
        $tableName = (new $modelClass)->getTable();
        $offset = ($page - 1) * $pageSize;

        // Define the columns to select, excluding sensitive fields
        $columns = array_merge(['id'], (new $modelClass)->getFillable());
        $columns = array_diff($columns, ['password', 'remember_token']); 

        // Condition to exclude soft-deleted records
        $deletedAtCondition = 'deleted_at IS NULL';

        if ($authId == 1) {
            // Query for super admin, excluding super admin itself
            $query = "
                SELECT " . implode(',', array_map(function($col) { return "users.$col"; }, $columns)) . "
                FROM {$tableName} AS users
                WHERE users.id != 1 AND {$deletedAtCondition}
                ORDER BY users.created_at ASC
            ";

            $countQuery = "
                SELECT COUNT(*) as total
                FROM {$tableName} AS users
                WHERE users.id != 1 AND {$deletedAtCondition};
            ";

            $statusQuery = "
                SELECT " . implode(',', array_map(function($col) { return "users.$col"; }, $columns)) . "
                FROM {$tableName} AS users
                WHERE users.id != 1 AND JSON_CONTAINS(users.status, '1') AND {$deletedAtCondition}
                ORDER BY users.created_at ASC;
            ";
        } else {
            // Query for regular users, including only their descendants
            $query = "
                WITH RECURSIVE descendants AS (
                    SELECT 
                        users.id AS id,
                        users.name AS name,
                        users.email AS email,
                        users.username AS username,
                        users.created_by AS created_by,
                        users.updated_by AS updated_by,
                        users.status AS status,
                        users.deleted_at AS deleted_at,
                        users.created_at AS created_at
                    FROM {$tableName} AS users
                    WHERE users.created_by = :authId AND users.deleted_at IS NULL
                UNION
                    SELECT 
                        t.id AS id,
                        t.name AS name,
                        t.email AS email,
                        t.username AS username,
                        t.created_by AS created_by,
                        t.updated_by AS updated_by,
                        t.status AS status,
                        t.deleted_at AS deleted_at,
                        t.created_at AS created_at
                    FROM {$tableName} AS t
                    INNER JOIN descendants AS d ON d.id = t.created_by
                    WHERE t.deleted_at IS NULL
                )
                SELECT 
                    descendants.id,
                    descendants.name,
                    descendants.email,
                    descendants.username,
                    descendants.created_by,
                    descendants.updated_by,
                    descendants.status,
                    descendants.deleted_at,
                    descendants.created_at
                FROM descendants
                WHERE descendants.id != 1 AND descendants.id != descendants.created_by AND descendants.deleted_at IS NULL
                ORDER BY descendants.created_at ASC
            ";

            $countQuery = "
                WITH RECURSIVE descendants AS (
                    SELECT 
                        users.id AS id,
                        users.name AS name,
                        users.email AS email,
                        users.username AS username,
                        users.created_by AS created_by,
                        users.updated_by AS updated_by,
                        users.status AS status,
                        users.deleted_at AS deleted_at,
                        users.created_at AS created_at
                    FROM {$tableName} AS users
                    WHERE users.created_by = :authId AND users.deleted_at IS NULL
                UNION
                    SELECT 
                        t.id AS id,
                        t.name AS name,
                        t.email AS email,
                        t.username AS username,
                        t.created_by AS created_by,
                        t.updated_by AS updated_by,
                        t.status AS status,
                        t.deleted_at AS deleted_at,
                        t.created_at AS created_at
                    FROM {$tableName} AS t
                    INNER JOIN descendants AS d ON d.id = t.created_by
                    WHERE t.deleted_at IS NULL
                )
                SELECT COUNT(*) as total
                FROM descendants
                WHERE descendants.id != 1 AND descendants.id != descendants.created_by AND descendants.deleted_at IS NULL
            ";

            $statusQuery = "
                WITH RECURSIVE descendants AS (
                    SELECT 
                        users.id AS id,
                        users.name AS name,
                        users.email AS email,
                        users.username AS username,
                        users.created_by AS created_by,
                        users.updated_by AS updated_by,
                        users.status AS status,
                        users.deleted_at AS deleted_at,
                        users.created_at AS created_at
                    FROM {$tableName} AS users
                    WHERE users.created_by = :authId AND users.deleted_at IS NULL
                UNION
                    SELECT 
                        t.id AS id,
                        t.name AS name,
                        t.email AS email,
                        t.username AS username,
                        t.created_by AS created_by,
                        t.updated_by AS updated_by,
                        t.status AS status,
                        t.deleted_at AS deleted_at,
                        t.created_at AS created_at
                    FROM {$tableName} AS t
                    INNER JOIN descendants AS d ON d.id = t.created_by
                    WHERE t.deleted_at IS NULL
                )
                SELECT 
                    descendants.id,
                    descendants.name,
                    descendants.email,
                    descendants.username,
                    descendants.created_by,
                    descendants.updated_by,
                    descendants.status,
                    descendants.deleted_at,
                    descendants.created_at
                FROM descendants
                WHERE descendants.id != 1 AND descendants.id != descendants.created_by AND JSON_CONTAINS(descendants.status, '1') AND descendants.deleted_at IS NULL
                ORDER BY descendants.created_at ASC
            ";
        }

        // Fetch data and apply necessary processing
        $descendants = $authId == 1
            ? DB::select($query)
            : DB::select($query, [$authId]);

        // Get the total count
        $total = $authId == 1
            ? DB::selectOne($countQuery)->total
            : DB::selectOne($countQuery, [$authId])->total;

        // Apply the same filtering logic to the status filtered data
        $statusFiltered = $authId == 1
        ? DB::select($statusQuery)
        : DB::select($statusQuery, ['authId' => $authId]);

        // Convert stdClass objects to models
        $queryCollection = collect($descendants);
        $statusQueryCollection = collect($statusFiltered);

        /**
         * convert stdClass object of array return by DB::select to models 
         * to ensure fetching data compatibility with Eloquent relationships.
         */
        $hydrated = User::hydrate($queryCollection->toArray());
        $statusHydrated = User::hydrate($statusQueryCollection->toArray());

        // Apply relation and status mapping
        $relationMapped = $this->userSqlMappingRepository->applySqlRelationMapping($hydrated);
        $statusRelationMapped = $this->userSqlMappingRepository->applySqlRelationMapping($statusHydrated);

        // Apply filtering, sorting, and mapping
        $filtered = $this->userSqlFilteringRepository->applyFiltering($relationMapped, $filterModel);
        $totalCount = $filtered->count();
        $sorted = $this->userSqlSortingRepository->applySorting($filtered, $sortModel);
        // Apply pagination
        $paginated = $sorted->forPage($page, $pageSize)->values();



        // Return the paginated results along with the filtered status data
        return [
            'paginated' => new LengthAwarePaginator(
                $paginated, 
                $totalCount, 
                $pageSize, 
                $page
            ),
            'statusFiltered' => $statusRelationMapped,
        ];
    }

    // /**
    //  * paginated and status filtered datas lazy loading relationship models
    //  *
    //  * @return <collections>
    //  */
    // private function mapRolesAndPermissions($collection)
    // {
    //     $userIds = $collection->pluck('id');

    //     // Use chunked approach for large datasets and memory efficiency
    //     $processedUsers = collect();
    //     User::with([
    //         'roles' => function ($q) {
    //             $q->whereJsonContains('roles.status', 1); // Filter roles with status = 1
    //         },
    //     ])
    //     ->latest()
    //     ->whereIn('users.id', $userIds)
    //     ->chunk(100, function ($chunk) use ($processedUsers) {
    //         // Process each chunk of users
    //         $chunk->each(function ($user) use ($processedUsers) {
    //             $user->roles->load(['permissions' => function ($q) use ($user) { 
    //                 $roleIds = User::find($user->id)->roles()->pluck('roles.id');
    //                 $q->whereIn('permissions.role_id', $roleIds)
    //                 ->where(function($wn) use ($user) {
    //                     $wn->whereJsonContains('permissions.user_id', $user->id)
    //                     ->orWhere(function($ow) {
    //                         $ow->whereJsonLength('permissions.user_id', 0);
    //                     });
    //                 })
    //                 ->whereNot(function ($query) use ($user) {
    //                     $permissionModels = DB::table('permissions')
    //                     ->whereJsonContains('permissions.user_id', $user->id)
    //                     ->pluck('model');

    //                     if ($permissionModels->isNotEmpty()) { 
    //                         Log::debug('masud' . $user->id);
    //                         $query->when(
    //                             $permissionModels,
    //                             function (Builder $sq, $permissionModels) {
    //                                 $sq->whereJsonLength('permissions.user_id', 0)
    //                                 ->whereIn('permissions.model', $permissionModels);
    //                             },
    //                             function (Builder $sq, $user){
    //                                 $sq->whereJsonContains('permissions.user_id', '!=', $user->id);
    //                             },
    //                         );
    //                     } else {
    //                         $query->whereJsonContains('permissions.user_id', !$user->id)
    //                         ->whereJsonLength('permissions.user_id', '>', 0);

    //                     }
    //                 });
    //             }]);

    //             // Optional: Process and modify $user data here before adding it to the collection
    //             $processedUsers->push($user);
    //         });
    //     });

    //     return $processedUsers;
    // }

    // /**
    //  * Fetch all descendants using Eloquent.
    //  *
    //  * @param string $modelClass
    //  * @param int $authId
    //  * @return \Illuminate\Support\Collection
    //  */
    // public function getDescendantByEloq($modelClass, $authId)
    // {
    //     $descendants = $modelClass::where('created_by', $authId)->get();
    //     $allDescendants = collect();

    //     $fetchDescendants = function ($items) use (&$fetchDescendants, $modelClass, &$allDescendants) {
    //         foreach ($items as $item) {
    //         $allDescendants->push($item);
    //         $children = $modelClass::where('created_by', $item->id)->get();

    //         if ($children->isNotEmpty()) {
    //             $fetchDescendants($children);
    //         }
    //         }
    //     };

    //     $fetchDescendants($descendants);

    //     return $allDescendants;
    // }
}

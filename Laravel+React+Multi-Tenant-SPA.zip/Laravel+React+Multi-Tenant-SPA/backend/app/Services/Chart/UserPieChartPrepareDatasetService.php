<?php

namespace App\Services\Chart;

use Illuminate\Support\Facades\DB;

use App\Exceptions\CustomException;


class UserPieChartPrepareDatasetService
{
    /**
     * Function to update user_pie_charts table.
     * @param mixed $chartModelName
     * @param mixed $modelName
     */
    public function prepareDataset($modelName, $chartModelName)
    {
        $userCount = $this->updateActiveUserCount($modelName);
        $totalUsers = $userCount['total_users'];

        $deletedUsers = $userCount['deleted_users'];
        $deletedUserPercent = $totalUsers > 0 ? number_format((($deletedUsers * 100) / $totalUsers), 2) : 0;
        $deletedEnableUserPercent = $deletedUsers > 0 ? number_format((($userCount['deleted_enable_users'] * 100) / $deletedUsers), 2) : 0;
        $deletedDisableUserPercent = $deletedUsers > 0 ? number_format((($userCount['deleted_disable_users'] * 100) / $deletedUsers), 2) : 0;

        $existingUsers = $userCount['existing_users'];
        $existingUserPercent = $totalUsers > 0 ? number_format((($existingUsers * 100) / $totalUsers), 2) : 0;
        $existingEnableUserPercent = $existingUsers > 0 ? number_format((($userCount['existing_enable_users'] * 100) / $existingUsers), 2) : 0;
        $existingDisableUserPercent = $existingUsers > 0 ? number_format((($userCount['existing_disable_users'] * 100) / $existingUsers), 2) : 0;

        if ($totalUsers > 0) {
            $this->storActiveUserCount(
                $chartModelName,
                $totalUsers, 
                $deletedUsers, 
                $existingUsers,
                $deletedUserPercent,
                $existingUserPercent,
                $deletedEnableUserPercent,
                $existingEnableUserPercent,
                $deletedDisableUserPercent,
                $existingDisableUserPercent,
            );
        }
    }

    /**
     * Get the count of the users as different states
     */
    protected function updateActiveUserCount($modelName)
    {
        $data = [];

        $data['total_users'] = $modelName::withTrashed()->count();

        $data['deleted_users'] = $modelName::withTrashed()
            ->whereNotNull('deleted_at')
            ->count();

        $data['existing_users'] = $modelName::whereNull('deleted_at')
        ->count();

        $data['deleted_enable_users'] = $modelName::withTrashed()
        ->whereNotNull('deleted_at')
        ->whereJsonContains('status', 1)
        ->count();

        $data['deleted_disable_users'] = $modelName::withTrashed()
        ->whereNotNull('deleted_at')
        ->whereJsonContains('status', 2)
        ->count();

        $data['existing_enable_users'] = $modelName::whereJsonContains('status', 1)
        ->whereNull('deleted_at')
        ->count();

        $data['existing_disable_users'] = $modelName::whereJsonContains('status', 2)
        ->whereNull('deleted_at')
        ->count();

        return $data;
    }
    
    /**
     * Store or update the users to the user_pie_charts table.
     */
    protected function storActiveUserCount(
        $chartModelName,
        int $totalUsers, 
        int $deletedUsers, 
        int $existingUsers, 
        string $deletedUserPercent, 
        string $existingUserPercent, 
        string $deletedEnableUserPercent, 
        string $existingEnableUserPercent,
        string $deletedDisableUserPercent, 
        string $existingDisableUserPercent,
     ) {
        DB::beginTransaction();
        try {
            $chartModelName::updateOrCreate([
            'deleted_users' => $deletedUsers, 
            'existing_users' => $existingUsers, 
            'deleted_user_percent' => $deletedUserPercent,
            'existing_user_percent' => $existingUserPercent,
            'deleted_enable_user_percent' => $deletedEnableUserPercent,
            'existing_enable_user_percent' => $existingEnableUserPercent,
            'deleted_disable_user_percent' => $deletedDisableUserPercent,
            'existing_disable_user_percent' => $existingDisableUserPercent,
            ],['total_users' => $totalUsers]);

            DB::commit();

        } catch (\Throwable $e) {

            DB::rollback();

            throw new CustomException([
                'status' => 'failed',
                'message' => "{$chartModelName} dataset can\'t be created successfully, {$e->getMessage()}",
            ], 200); // 422, provided data invalid, 200 for graceful response
        }
    }
}

<?php

namespace App\Services\Chart;

use Illuminate\Support\Str;
use Carbon\Carbon;

class UserBarChartPrepareDatasetService
{
    /**
     * Fetch active user data.
     * The method processes users in chunks and aggregates counts by month and year.
     *
     * @param mixed $modelName
     * @param mixed $chartModelName
     * @return void
     */
    public function prepareDataset($modelName, $chartModelName)
    {
        // Updating user_bar_charts table
        $userCounts = $this->updateActiveUserCount($modelName);

        // Loop through user counts and store the data
        foreach ($userCounts as $key => $value) {
            // Laravel Str helper
            // Replace underscores with spaces
            // Capitalize the first letter of each word
            $userType = Str::of($key)->replace('_', ' ')->title(); 
            
            // Loop through years and months to store data
            foreach ($value as $year => $months) {
                foreach ($months as $month => $count) {
                    $this->storActiveUserCount($chartModelName, $year, $month, $userType, $count);
                }
            }
        }
    }

    /**
     * Get the count of active users for a given user in all months and years.
     * Uses chunking to handle large datasets efficiently.
     */
    protected function updateActiveUserCount($modelName)
    {
        $data = [];

        // Process users in chunks
        $modelName::selectRaw('YEAR(created_at) as year, MONTH(created_at) as month')
            ->whereNull('deleted_at')
            ->groupByRaw('YEAR(created_at), MONTH(created_at)')
            ->orderByRaw('YEAR(created_at), MONTH(created_at)')
            ->chunk(1000, function ($yearMonthPairs) use (&$data, $modelName) {
                foreach ($yearMonthPairs as $pair) {
                    $year = $pair->year;
                    $month = $pair->month;

                    // Active users count
                    $data['active'][$year][$month] = $modelName::whereJsonContains('status', 1)
                        ->whereNull('deleted_at')
                        ->whereYear('users.created_at', $year)
                        ->whereMonth('users.created_at', $month)
                        ->count();

                    // Disabled users count
                    $data['disable'][$year][$month] = $modelName::whereJsonContains('status', 2)
                        ->whereNull('deleted_at')
                        ->whereYear('users.updated_at', $year)
                        ->whereMonth('users.updated_at', $month)
                        ->count();

                    // Deleted users count
                    $data['delete'][$year][$month] = $modelName::withTrashed()
                        ->whereNotNull('deleted_at')
                        ->whereYear('deleted_at', $year)
                        ->whereMonth('deleted_at', $month)
                        ->count();

                    // Users with roles count
                    $data['has_role'][$year][$month] = $modelName::with(['roles' => function ($q) {
                            $q->whereJsonContains('status', 1);
                        }])
                        ->whereNull('deleted_at')
                        ->whereJsonContains('status', 1)
                        ->whereYear('users.created_at', $year)
                        ->whereMonth('users.created_at', $month)
                        ->whereHas('roles', function ($q) {
                            $q->whereJsonContains('status', 1);
                        })
                        ->count();
                }
            });

        return $data;
    }

    /**
     * Store or update the chart data based on the type, year, and month.
     */
    protected function storActiveUserCount($chartModelName, string $year, string $month, string $userType, int $userCount)
    {
        $chartModelName::updateOrCreate(
            ['user_type' => $userType, 'year' => $year, 'month' => $month],
            ['user_count' => $userCount]
        );
    }
}

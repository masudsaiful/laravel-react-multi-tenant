<?php

namespace App\Services\Chart;

use Illuminate\Support\Facades\DB;

use App\Models\Chart\RoleBarChart;
use App\Models\Chart\UserBarChart;
use App\Models\Role\Role;

class UserBarChartDatasetService
{
    /**
     * Fetch dataset based on roles, period, and years.
     */
    public function getDataset(array $requestData)
    {
        // Check request data type
        // Based on req data type related methoeds call
        $type = $requestData['type'][0];
        $methodMonthly = "monthly{$type}Data";
        $methodYearly = "yearly{$type}Data";
        $particulars = $requestData['particulars'] ?? [];


        // return response()->json(['m' => $requestData['particulars']]); debug

        $period = $requestData['period'][0];
        $years = $requestData['years'] ?? [];

        // Default to current year for "Month" period if no year is specified
        if ($period == 1 && empty($years)) {
            $years = [date('Y')];
        }

        if ($period === 1) {
            return $this->$methodMonthly($particulars, $years);
        }

        if ($period === 2) {
            return $this->$methodYearly($particulars, $years);
        }
    }

    /**
     * Fetch role titles in a role-title map for transforming role IDs to names.
     */
    protected function getRoleTitleMap(): array
    {
        return Role::pluck('title', 'id')->toArray();
    }

    /**
     * Fetch monthly data for the given datas and years.
     */
    protected function monthlyUsersData(array $userTypes, array $years)
    {

        // Include all datas if none are specified from arguments
        $userTypes = $userTypes ?: UserBarChart::distinct()->pluck('user_type')->toArray();

        // Fetch data, grouping by month and aggregating user counts across years
        $data = UserBarChart::whereIn('user_type', $userTypes)
            ->whereIn('year', $years) // Use all selected years
            ->select(DB::raw('user_type, month, SUM(user_count) as user_count'))
            ->groupBy('user_type', 'month')
            ->get()
            ->mapToGroups(function ($item) {
                return [$item->month => [$item->user_type => (int)$item->user_count]];
            });
    
        return $this->transformMonthlyUsersData($data);
    }

    /**
     * Transform monthly data to fill missing months.
     */
    protected function transformMonthlyUsersData($data)
    {
        $formattedData = [];
        foreach ($data as $month => $userTypeCounts) {
            $formattedItem = ['month' => date('M', mktime(0, 0, 0, $month, 10))];
    
            foreach ($userTypeCounts as $userTypeCount) {
                foreach ($userTypeCount as $userType => $count) {
                    $title = $userType ?? $userType;
                    $formattedItem[$title] = $count;
                }
            }

            $formattedData[] = $formattedItem;
        }
    
        $allUserTypes = array_unique(array_merge(...array_map('array_keys', $formattedData)));
        $allUserTypes = array_diff($allUserTypes, ['year', 'month']); // Remove 'year' and 'month' from keys

        // Sort data keys alphabetically
        sort($allUserTypes);

        // Define the correct month order for sorting
        $monthOrder = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']; 

        // Add missing keys to each entry and move 'year' or 'month' to the end
        foreach ($formattedData as &$data) {
            // Add missing datas with 0 and order them alphabetically
            $data = array_merge(array_fill_keys($allUserTypes, 0), $data);

            // Sort 'month' to appear in correct order if present, then add 'year' or 'month' at the end
            // Keep original month value for easier sorting later
            if (isset($data['month'])) {
                $data['month'] = $data['month']; 
            }

            // Move 'year' or 'month' to the end if it exists
            foreach (['year', 'month'] as $timeKey) {
                if (isset($data[$timeKey])) {
                    $timeValue = $data[$timeKey];
                    unset($data[$timeKey]); // Remove time key from current position
                    $data[$timeKey] = $timeValue; // Add time key at the end
                }
            }
        }
        unset($data); // Break reference

        // Step 4: Sort the entire dataset by month order if 'month' is present
        usort($formattedData, function ($a, $b) use ($monthOrder) {
            // Only compare 'month' if it exists in both arrays
            if (isset($a['month']) && isset($b['month'])) {
                return array_search($a['month'], $monthOrder) <=> array_search($b['month'], $monthOrder);
            }
            return 0;
        });

        return $formattedData;
    }

    /**
     * Fetch yearly data for the given data and years.
     */
    protected function yearlyUsersData(array $userTypes, array $years)
    {
        // Include all years if none are specified
        if (empty($years)) {
            $years = $this->getAvailableUserYears();
        }

        // Include all datas if none are specified from arguments
        $userTypes = $userTypes ?: UserBarChart::distinct()->pluck('user_type')->toArray();

        $data = UserBarChart::whereIn('user_type', $userTypes)
            ->whereIn('year', $years)
            ->select(DB::raw('user_type, year, SUM(user_count) as user_count'))
            ->groupBy('user_type', 'year')
            ->get()
            ->mapToGroups(function ($item) {
                return [$item->year => [$item->user_type => (int)$item->user_count]];
            });

        return $this->transformYearlyUsersData($data, $years);
    }

    /**
     * Transform yearly data to fill missing years.
     */
    protected function transformYearlyUsersData($data, $years)
    {
        $formattedData = [];
        foreach ($data as $year => $userTypeCounts) {
            $formattedItem = ['year' => $year];

            foreach ($userTypeCounts as $userTypeCount) {
                foreach ($userTypeCount as $userType => $count) {
                    $title = $userType ?? $userType;
                    $formattedItem[$title] = $count;
                }
            }

            $formattedData[] = $formattedItem;
        }

        // Ensure all years are included, even if missing from the dataset
        foreach ($years as $year) {
            if (!collect($formattedData)->pluck('year')->contains($year)) {
                $formattedData[] = ['year' => $year];
            }
        }

        // Dataset arranging for same length of items
        $allUserTypes = array_unique(array_merge(...array_map('array_keys', $formattedData)));
        $allUserTypes = array_diff($allUserTypes, ['year', 'month']); // Remove 'year' and 'month' from keys

        // Sort data keys alphabetically
        sort($allUserTypes);

        // Add missing keys to each entry and ensure chronological order of years
        foreach ($formattedData as &$data) {
            $data = array_merge(array_fill_keys($allUserTypes, 0), $data);
        }
        unset($data); // Break reference

        // Sort the formatted dataset by year in ascending order
        usort($formattedData, function ($a, $b) {
            return $a['year'] <=> $b['year'];
        });

        return $formattedData;
    }

    /**
     * Fetch all available years from the related Chart table.
     */
    public function getAvailableYears(): array
    {
        return RoleBarChart::where('status', 'active')->distinct()->orderBy('year', 'asc')->pluck('year')->toArray();
    }

    /**
     * Fetch all available years from the related Chart table.
     */
    public function getAvailableUserYears(): array
    {
        return UserBarChart::distinct()->orderBy('year', 'asc')->pluck('year')->toArray();
    }
}

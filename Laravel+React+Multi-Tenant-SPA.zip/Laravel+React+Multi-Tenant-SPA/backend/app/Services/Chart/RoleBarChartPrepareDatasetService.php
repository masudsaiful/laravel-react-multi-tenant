<?php

namespace App\Services\Chart;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use App\Exceptions\CustomException;

class RoleBarChartPrepareDatasetService
{
    /**
     * Fetch active user count for each role, grouped by year and month.
     * Processes users in chunks and aggregates data, updating the chart model.
     *
     * @param string $modelName The model class to fetch roles from.
     * @param string $chartModelName The model to store aggregated user counts.
     * @return void
     */
    public function prepareDataset($modelName, $chartModelName)
    {
        // Fetch roles with active status (status = 1) in chunks of 100
        $modelName::whereJsonContains('roles.status', 1)
            ->chunk(100, function ($roles) use ($chartModelName) {
                foreach ($roles as $role) {
                    // Aggregated user counts grouped by year-month
                    $aggregatedUserCounts = [];

                    // Check if role has active users before processing
                    if ($role->users()->whereJsonContains('users.status', 1)->exists()) {
                        // Process users in chunks
                        $role->users()->whereJsonContains('users.status', 1)
                            ->select('users.id', 'users.created_at')
                            ->chunk(100, function ($users) use ($role, &$aggregatedUserCounts) {
                                // Skip empty chunks
                                if ($users->isEmpty()) {
                                    Log::info('Empty chunk for Role ID: ' . $role->id . '. Skipping...');
                                    return;
                                }

                                // Group users by year-month and count
                                $userCounts = $users
                                    ->groupBy(function ($user) {
                                        return $user->created_at->format('Y-m'); // Group by year-month
                                    })
                                    ->map(fn($group) => $group->count()); // Count users in each group

                                // Aggregate counts across chunks
                                foreach ($userCounts as $yearMonth => $count) {
                                    $aggregatedUserCounts[$yearMonth] = ($aggregatedUserCounts[$yearMonth] ?? 0) + $count;
                                }
                            });
                    }

                    // Remove non-matching records from the chart model
                    $this->removeActiveUserCount($chartModelName, $role->id, $aggregatedUserCounts);

                    // Update the chart model with the aggregated counts
                    foreach ($aggregatedUserCounts as $yearMonth => $totalCount) {
                        [$year, $month] = explode('-', $yearMonth);
                        $this->updateActiveUserCount($chartModelName, $role->id, $year, $month, $totalCount, $role->status);
                    }
                }
            });
    }

    /**
     * Remove old records from the chart model that don't match the aggregated year-month.
     *
     * @param string $chartModelName
     * @param int $roleId
     * @param array $aggregatedUserCounts
     * @return void
     */
    protected function removeActiveUserCount($chartModelName, $roleId, $aggregatedUserCounts)
    {
        $validYearMonths = array_keys($aggregatedUserCounts);

        // Delete records from the chart model that don't match the aggregated year-month combinations
        $chartModelName::where('role_id', $roleId)
            ->whereNotIn(DB::raw("CONCAT(year, '-', month)"), $validYearMonths)
            ->delete();

        Log::info('Removed non-matching records for Role ID: ' . $roleId);
    }

    /**
     * Update the role bar chart with the user count for the given year and month.
     *
     * @param string $chartModelName
     * @param int $roleId
     * @param int $year
     * @param int $month
     * @param int $userCount
     * @param mixed $status
     * @return void
     */
    protected function updateActiveUserCount($chartModelName, $roleId, $year, $month, $userCount, $status)
    {
        $roleStatus = $status === [1] || (is_array($status) && in_array(1, $status)) ? 'active' : 'disable';

        try {
            // Update chart model within a transaction for consistency
            DB::transaction(function () use ($chartModelName, $roleId, $year, $month, $userCount, $roleStatus) {
                // Update or create the record for the role, year, and month
                $chartModelName::updateOrCreate(
                    [
                        'role_id' => $roleId,
                        'year' => $year,
                        'month' => $month,
                    ],
                    [
                        'user_count' => $userCount, 
                        'status' => $roleStatus,
                    ]
                );

                Log::info('Role bar chart updated for Role ID: ' . $roleId . ', Year: ' . $year . ', Month: ' . $month);
            });
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Role bar chart update failed: ' . $e->getMessage(),
            ], 200); // 422, unprocessable entity. 200 for graceful response

            Log::error('Failed to update role bar chart: ' . $e->getMessage());
        }
    }
}


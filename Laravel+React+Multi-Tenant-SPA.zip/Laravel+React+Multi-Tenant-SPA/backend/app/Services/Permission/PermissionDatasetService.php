<?php

namespace App\Services\Permission;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Auth;
use Illuminate\Database\Eloquent\Builder;
use App\Models\User\User;
use App\Models\Permission\Permission;


/**
 * Class PermissionDatasetService
 *
 * This class provides functionality to format models 
 * Formatted permission dataset to add with user response
 */
class PermissionDatasetService
{
    /**
     * Retrieve all model names and their fully qualified names 
     * from the `app/Models` directory.
     *
     * @return array
     */
    public function getDataset()
    {
        // Fetch the user explicitly
        $user = User::find(Auth::id());
        if (!$user) {
            return []; // Return empty dataset if user is not authenticated
        }

        $userId = $user->id;
        $roleIds = $user->roles()->roleStatusScope(1)->pluck('roles.id');

        // // Fetch permissions directly assigned to the user
        // $userPermissions = Permission::whereJsonContains('user_id', $user->id)
        // ->whereIn('role_id', $roleIds)
        // ->get();

        // // If user-specific permissions found, return them
        // if (!$userPermissions->isEmpty()) {
        //     return $this->formatPermissions($userPermissions);
        // }

        // // Get permissions based on role_ids, ignore the user_id field
        // $rolePermissions = Permission::whereIn('role_id', $roleIds) // Match permissions where role_id matches
        // ->where(function ($query) {
        //     $query->whereNull('user_id') // Match where user_id is NULL
        //             ->orWhereJsonLength('user_id', 0); // Or match where user_id is an empty array
        // })->get();


        // // If user-specific permissions found, return them
        // if (!$rolePermissions->isEmpty()) {
        //     return $this->formatPermissions($rolePermissions);
        // }


        $permissions1 = Permission::whereJsonContains('permissions.user_id', $userId)
            ->whereIn('permissions.role_id', $roleIds);
            
        $permissions2 = Permission::whereJsonLength('permissions.user_id', '==', 0)
            ->whereIn('permissions.role_id', $roleIds)
            ->whereNotIn('permissions.model', $permissions1->pluck('model'));

        $permissions = $permissions1->union($permissions2)->get();

        if (!$permissions->isEmpty()) {
            return $this->formatPermissions($permissions);
        }

        // Return an empty dataset if no permissions are found
        return [];
    }

    // Group by model and aggregate permissions
    private function formatPermissions($permissions)
    {
        $result = $permissions
            ->groupBy('model')
            ->map(function ($permissions, $model) {
                return [
                    'model' => $model,
                    'create' => $permissions->max('create') ? 1 : 0,
                    'update' => $permissions->max('update') ? 1 : 0,
                    'delete' => $permissions->max('delete') ? 1 : 0,
                ];
            })
            ->values()
            ->toArray();

        return $result;
    }
}

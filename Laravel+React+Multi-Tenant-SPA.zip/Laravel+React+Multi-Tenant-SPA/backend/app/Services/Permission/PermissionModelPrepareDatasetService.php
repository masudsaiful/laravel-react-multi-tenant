<?php

namespace App\Services\Permission;

use Illuminate\Support\Facades\File;

/**
 * Class PermissionModelPrepareDatasetService
 *
 * This class provides functionality to list all models 
 * from the `app/Models` directory, including those in subdirectories.
 */
class PermissionModelPrepareDatasetService
{
    /**
     * Retrieve all model names and their fully qualified names 
     * from the `app/Models` directory.
     *
     * @return array
     */
    public function prepareModelDataset()
    {
        // Define the path to the `Models` directory
        $modelsPath = app_path('Models');

        // Recursively retrieve all files from the directory and its subdirectories
        $modelFiles = File::allFiles($modelsPath);

        // Initialize arrays to hold model names and fully qualified names
        // $modelNames = [];
        // $modelNamesWithNamespaces = [];

        // Initialize the array to hold formatted model data 
        $formattedModels = [];
        $modelNamesWithNamespaces = [];

        // Iterate through each file found in the directory
        foreach ($modelFiles as $file) {
            // Check if the file has a `.php` extension
            if ($file->getExtension() === 'php') {
                // Extract the file name without the extension
                $fileName = $file->getFilenameWithoutExtension();

                // // Add the file name to the $modelNames array
                // $modelNames[] = $fileName;

                // Generate the fully qualified model name (including namespace)
                $relativePath = str_replace(
                    [base_path() . DIRECTORY_SEPARATOR, '.php'],
                    '',
                    $file->getPathname()
                );

                $namespace = str_replace(
                    [DIRECTORY_SEPARATOR, 'app'],
                    ['\\', 'App'],
                    $relativePath
                );

                // Format the model name into the required structure
                $formattedModel = [
                    'id' => strtolower($fileName), // Fully Qualified Model Name
                    'label' => $fileName, // All lowercase, no gaps
                    'value' => $this->formatModelName($fileName), // PascalCase with spaces
                ];

                // Add the model to the list
                $formattedModels[] = $formattedModel;

                // Add any related custom entries
                $formattedModels = $this->addCustomEntriesAfter($formattedModels, $formattedModel);

                // Add the fully qualified name to the $modelNamesWithNamespaces array
                $modelNamesWithNamespaces[] = $namespace;
            }
        }

        // // Return both arrays
        // return [
        //     'modelNames' => $modelNames,
        //     'modelNamesWithNamespaces' => $modelNamesWithNamespaces,
        // ];

        // // Add custom entries to the models list
        // $formattedModels = $this->addCustomEntries($formattedModels);

        // Return both arrays
        return [
            'modelNames' => $formattedModels,
            'modelNamesWithNamespaces' => $modelNamesWithNamespaces,
        ];
    }

    /**
     * Format a model name by adding spaces to PascalCase or CamelCase names.
     *
     * @param string $name
     * @return string
     */
    protected function formatModelName(string $name): string
    {
        return preg_replace('/(?<!^)([A-Z])/', ' $1', $name);
    }

    /**
     * Add custom entries immediately after the given model entry.
     *
     * @param array $models
     * @param array $currentModel
     * @return array
     */
    protected function addCustomEntriesAfter(array $models, array $currentModel): array
    {
        // Define custom entries based on the current model's ID
        $customEntries = [
            'userpiechart' => [
                [
                    'id' => 'dashboard',
                    'label' => 'Dashboard',
                    'value' => 'Dashboard',
                ],
            ],
            'user' => [
                [
                    'id' => 'profile',
                    'label' => 'Profile',
                    'value' => 'Profile',
                ],
            ],
            // Add more custom entries as needed
        ];

        // Check if the current model ID has associated custom entries
        if (array_key_exists($currentModel['id'], $customEntries)) {
            // Find the index of the current model in the array
            $currentIndex = array_search($currentModel, $models);

            // Insert custom entries immediately after the current model
            array_splice($models, $currentIndex + 1, 0, $customEntries[$currentModel['id']]);
        }

        return $models;
    }
}

<?php

namespace App\Services\Permission;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Auth;

use App\Models\User\User;
use App\Models\Permission\Permission;


/**
 * Class PermissionDatasetService
 *
 * This class provides functionality to format models 
 * Formatted permission dataset to add with user response
 */
class PermissionDatasetService
{
    /**
     * Retrieve all model names and their fully qualified names 
     * from the `app/Models` directory.
     *
     * @return array
     */
    public function getDataset()
    {
        // Fetch the user explicitly
        $user = User::find(Auth::id());
        $roleIds = $user->roles->pluck('id');

        // Fetch permissions through roles
        $rolePermissions = $user->roles()
            ->whereHas('permissions') // Ensure roles have permissions
            ->with('permissions') // Load only related permissions
            ->get()
            ->pluck('permissions')
            ->flatten();

        // Fetch permissions directly assigned to the user
        $userPermissions = Permission::whereJsonContains('user_id', $user->id)
        ->whereIn('role_id', $roleIds)
        ->get();

        // Combine role-based and user-specific permissions
        $allPermissions = $rolePermissions->merge($userPermissions);

        // Group by model and aggregate permissions
        $result = $allPermissions
            ->groupBy('model')
            ->map(function ($permissions, $model) {
                return [
                    'model' => $model,
                    'create' => $permissions->max('create') ? 1 : 0,
                    'update' => $permissions->max('update') ? 1 : 0,
                    'delete' => $permissions->max('delete') ? 1 : 0,
                ];
            })
            ->values()
            ->toArray();

        return $result;
    }
}

<?php

namespace App\Exceptions;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Exception;

class CustomException extends Exception
{
    /**
     * Detailed information about the exception, including status and message.
     *
     * @var array
     */
    protected $details;
    protected $code;

    /**
     * Create a new CustomException instance.
     *
     * @param array|string $details Detailed exception information or message.
     * @param int $code HTTP status code for the exception response.
     */
    public function __construct($details = [
        "status" => "unathenticated or failed",
        "message" => "custom exception default unathenticated or failed message",
        "errors" => null,
    ], $code = 401)
    {

        // Ensure $details is an array and merge with defaults.
        $this->details = array_merge([
            "status" => "unauthenticated or failed",
            "message" => "custom exception default unauthenticated or failed message",
            "errors" => null,
        ], is_array($details) ? $details : ["message" => $details]);

        $this->code = $code;

        // parent::__construct(json_encode($details), $code);
        // parent::__construct(json_encode($this->details), $code);
        parent::__construct($this->details['errors'], $code);
    }

    /**
     * Render the exception as an HTTP response.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function render(Request $request)
    {
        // Response to profile fetching first time SPA mount or page reload.
        if ($request->is('*profile*') || 
            $request->is('*roles*') || 
            $request->is('*roles*')) {

            // Check if user is authenticated
            if(!Auth::check()) {
                return response()->json([
                    'status' => $this->details['status'] ?? 'unauthenticated',
                    'message' => $this->details['message'] ?? 'custom exception unathenticated message',
                    'errors' => $this->details['errors'] ?? 'custom exception unathenticated errors',
                ], $this->code);

            } else {
                return response()->json([
                    'status' => $this->details['status'] ?? 'failed',
                    'message' => $this->details['message'] ?? 'custom exception failed message',
                    'errors' => $this->details['errors'] ?? 'custom exception failed errors',
                ], $this->code);
            }

        } else {
            // Check if user is authenticated
            if(!Auth::check()) {
                return response()->json([
                    'status' => $this->details['status'] ?? 'unauthenticated',
                    'message' => $this->details['message'] ?? 'custom exception unathenticated message',
                    'errors' => $this->details['errors'] ?? 'custom exception unathenticated errors',
                ], $this->code);

            } else {
                return response()->json([
                    'status' => $this->details['status'] ?? 'failed',
                    'message' => $this->details['message'] ?? 'custom exception failed message',
                    'errors' => $this->details['errors'] ?? 'custom exception failed errors',
                ], $this->code);
            }
        }
    }
}


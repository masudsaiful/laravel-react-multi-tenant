<?php

namespace App\Http\Controllers\BulkAction;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

use App\Helpers\Utilities;
use App\Exceptions\CustomException;


class BulkManyToManyActionController extends Controller
{
    /**
     * Store a newly created resource in storage.
     * Param ($resource) value from Route::prefix('{resource}').
     * app() to dynamically resolve the model.
     * app($modelName) resolves the model instance dynamically.
     * Str::studly() capitalizes the first letter.
     * Str::singular($resource) converts "users" to "user".
     * 'App\\Models\\' . $modelName . '\\'. $modelName creates the full model class path
     * 
     */
    public function manyToManyDelete($request, $model, $relation)
    {
        $ids = $request->ids;

        DB::beginTransaction();
        try {
            if (!Utilities::isEmptyUniversalCheck($ids) && 
                is_array($ids) &&
                !Utilities::isEmptyUniversalCheck($relation)) {
                // Initiate class
                $modelInstance = app($model);
                $records = $modelInstance::whereIn('id', $ids);

                // $users = User::whereIn('id', $ids);
                // foreach ($users->get() as $user) {
                //     $user->roles()->detach();
                // }
                // $users->delete();

                // Example: Detach the specified relationship before deletion (if it exists)
                foreach ($records->get() as $record) {
                    // Check if the relationship method name exists defining by the $record e.g, User model has 'roles' method
                    if ($relation && method_exists($record, $relation)) { 

                        // Detach the relationship by using relation method name before deleting the record
                        $record->{$relation}()->detach(); 
                    }
                }

                // Delete the records
                $records->delete();
            }

            DB::commit();
    
            return response()->json([
                'status' => 'success',
                'message' => "Successfully deleted the selected records with relationship records",
            ], 200); // successfully deleted, returned contents (status, message etc.)
    
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => "Can't be deleted the selected records and thus relationship. {$e->getMessage()}",
            ], 422); // 422, provided data invalid
        }
    }

    public function manyToManyAssign($request, $model, $relation)
    {
        $ids = $request->ids;
        $relationIds = $request->relationIds;

        DB::beginTransaction();
        try {
            if (!Utilities::isEmptyUniversalCheck($ids) && 
                is_array($ids) &&
                !Utilities::isEmptyUniversalCheck($relationIds) && 
                is_array($relationIds) &&
                !Utilities::isEmptyUniversalCheck($relation)) {
                // Initiate class
                $modelInstance = app($model);
                $records = $modelInstance::whereIn('id', $ids);

                // Example: Attach the specified relationship
                foreach ($records->get() as $record) {
                    // Check if the relationship method name exists defining by the $record e.g, User model has 'roles' method
                    if ($relation && method_exists($record, $relation)) { 

                        // Attach the relationship by using relation method name.
                        $record->{$relation}()->syncWithPivotValues(
                            $relationIds, [
                                'created_by' => Auth::id(), 
                                'updated_by' => Auth::id(),
                            ]
                        ); 
                    }
                }
            }

            DB::commit();
    
            return response()->json([
                'status' => 'success',
                'message' => "Successfully assigned to the selected records."
            ], 200); // successfully deleted, returned contents (status, message etc.)
    
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => "Can\'t be assigned to the selected records. {$e->getMessage()}"
            ], 422); // 422, provided data invalid
        }
    }

    public function manyToManyUnassign($request, $model, $relation)
    {
        $ids = $request->ids;
        $relationIds = $request->relationIds;

        DB::beginTransaction();
        try {
            if (!Utilities::isEmptyUniversalCheck($ids) && 
                is_array($ids) &&
                !Utilities::isEmptyUniversalCheck($relationIds) && 
                is_array($relationIds) &&
                !Utilities::isEmptyUniversalCheck($relation)) {
                    
                // initiate class
                $modelInstance = app($model);
                $records = $modelInstance::whereIn('id', $ids);

                // Example: Attach the specified relationship
                foreach ($records->get() as $record) {
                    // Check if the relationship method name exists defining by the $record e.g, User model has 'roles' method
                    if ($relation && method_exists($record, $relation)) { 
                        
                        // Attach the relationship by using relation method name.
                        $record->{$relation}()->detach(); 
                    }
                }
            }

            DB::commit();
    
            return response()->json([
                'status' => 'success',
                'message' => "Successfully unasigned to the selected records."
            ], 200); // successfully deleted, returned contents (status, message etc.)
    
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => "Can\'t be unassigned to the selected records. {$e->getMessage()}"
            ], 422); // 422, provided data invalid
        }
    }
}

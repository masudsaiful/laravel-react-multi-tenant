<?php

namespace App\Http\Controllers\BulkAction;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

use App\Helpers\Utilities;
use App\Exceptions\CustomException;


class BulkDeleteActionController extends Controller
{
    /**
     * Store a newly created resource in storage.
     * Param ($resource) value from Route::prefix('{resource}').
     * app() to dynamically resolve the model.
     * app($modelName) resolves the model instance dynamically.
     * Str::studly() capitalizes the first letter.
     * Str::singular($resource) converts "users" to "user".
     * 'App\\Models\\' . $modelName . '\\'. $modelName creates the full model class path
     * @param mixed $request
     * @param mixed $model
     * @param mixed $action
     */
    public function delete($request, $model, $action)
    {
        $ids = $request->ids;

        DB::beginTransaction();
        try {
            if (!Utilities::isEmptyUniversalCheck($ids) && is_array($ids)) {
                // Use the dynamically resolved model to perform the delete operation
                $modelInstance = app($model);
                $records = $modelInstance::whereIn('id', $ids);
                // Delete the records
                $records->{$action}();
            }

            DB::commit();
    
            return response()->json([
                'status' => 'success',
                'message' => "Selected records has been deleted without deleting relation models of {$model}",
            ], 200); // successfully deleted, returned contents (status, message etc.)
    
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => "Can\'t be deleted records of {$model}. {$e->getMessage()}",
            ], 422); // 422, provided data invalid
        }
    }
}

<?php

namespace App\Http\Controllers\BulkAction;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
//Laravel's Str helper to format the string and app() to dynamically resolve the model.
use Illuminate\Support\Str;

use App\Exceptions\CustomException;
use App\Helpers\Utilities;
use App\Http\Controllers\BulkAction\BulkFetchController;

class BulkActionController extends Controller
{
    /**
     * Store a newly created resource in storage.
     * Param ($resource) value from Route::prefix('{resource}').
     * app() to dynamically resolve the model.
     * app($modelName) resolves the model instance dynamically.
     * Str::studly() capitalizes the first letter.
     * Str::singular($resource) converts "users" to "user".
     * 'App\\Models\\' . $modelName . '\\'. $modelName creates the full model class path
     * @param \Illuminate\Http\Request $request
     * @param mixed $resourceName
     * @param mixed $actionName
     */
    public function bulkAction(Request $request, $resourceName, $actionName)
    {
        // resource name
        // $resourceName can get as a method parameter
        // Or using $request method, $request->route('resourceName');
        // Convert to singular upper and lower case, e.g., 'users' to 'User' and 'user.
        if(!Utilities::isEmptyUniversalCheck($resourceName)) {
            $resourceUpper = Str::studly(Str::singular($resourceName));
            $resourceLower = Str::lcfirst(Str::singular($resourceName));
        }

        // action name, delete or assign or unassign
        if(!Utilities::isEmptyUniversalCheck($actionName)) {
            $actionUpper = Str::studly(Str::singular($actionName));
            $actionLower = Str::lcfirst(Str::singular($actionName));
        }  

        // relation ids
        if(!Utilities::isEmptyUniversalCheck($request->relationIds)) {
            $relationIds = $request->relationIds;
        }

        // relation method, e.g., User relation to Role using 'roles' method
        if(!Utilities::isEmptyUniversalCheck($request->relationMethod)) {
            $relationMethodUpper = Str::studly(Str::singular($request->relationMethod));
            $relationMethodLower = Str::lcfirst(Str::singular($request->relationMethod));
        }

        // relation type 1:1, e.g., ManyToMany, OneToMany, OneToOne
        if(!Utilities::isEmptyUniversalCheck($request->relationType)) {
            $relationTypeUpper = Str::studly(Str::singular($request->relationType));
            $relationTypeLower = Str::lcfirst(Str::singular($request->relationType));
        }

        // Fully qualify main model class name
        $modelName = 'App\\Models\\' . $resourceUpper . '\\'. $resourceUpper;

        // Check if the model class exists, e.g., 'User'.
        if (!class_exists($modelName)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Model not found, model: '. $resourceUpper,
            ], 404); // 404, Not found
        }

        if ($request->isMethod('post')) {
            // Only bulk delete without relation resource if not supplied
            if ((Utilities::isEmptyUniversalCheck($request->relationMethod) ||
                Utilities::isEmptyUniversalCheck($request->relationType)) &&
                !Utilities::isEmptyUniversalCheck($request->ids) && 
                is_array($request->ids) &&
                $actionLower === 'delete') {

                // Fully qualify controller class name
                $controllerName = "App\\Http\\Controllers\\BulkAction\\Bulk{$actionUpper}ActionController";

                // Check if class exists
                if (!class_exists($controllerName)) {
                    throw new CustomException([
                        'status' => 'failed',
                        'message' => "Controller not found, controller: {Bulk{$actionUpper}ActionController}",
                    ], 404); // 404, Not found
                }

                // Instantiate the class
                $controllerInstance = app($controllerName);
                return $controllerInstance->{$actionLower}($request, $modelName, $actionLower);

            } else {
                // Fully qualify controller class name
                $controllerName = "App\\Http\\Controllers\\BulkAction\\Bulk{$relationTypeUpper}ActionController";
                // Fully qualify relation model class name
                $relationModelName = 'App\\Models\\' . $relationMethodUpper . '\\'. $relationMethodUpper;

                // Check if the controller class exists, e.g., 'BulkManyToManyActionController'.
                if (!class_exists($controllerName)) {
                    throw new CustomException([
                        'status' => 'failed',
                        'message' => "Controller not found, controller: Bulk{$relationTypeUpper}ActionController",
                    ], 404); // 404, Not found
                }

                // Check if the relation model class exists, e.g., 'User' relation with Role.
                if (!class_exists($relationModelName)) {
                    throw new CustomException([
                        'status' => 'failed',
                        'message' => 'Model not found, model: '. $relationMethodUpper,
                    ], 404); // 404, Not found
                }

                // Instantiate the class and call method
                $controllerInstance = app($controllerName);
                $actionMethod = $relationTypeLower.$actionUpper;

                return $controllerInstance->{$actionMethod}(
                    $request, 
                    $modelName, 
                    $request->relationMethod,
                );
            }
        }

        // DB::beginTransaction();
        // try {
        //     if (is_array($ids)) {
        //         // Use the dynamically resolved model to perform the delete operation
        //         $modelInstance = app($modelName);
        //         $records = $modelInstance::whereIn('id', $ids);

        //         // $users = User::whereIn('id', $ids);
        //         // foreach ($users->get() as $user) {
        //         //     $user->roles()->detach();
        //         // }
        //         // $users->delete();

        //         // Example: Detach the specified relationship before deletion (if it exists)
        //         foreach ($records->get() as $record) {
        //             // Check if the relationship method name exists defining by the $record e.g, User model
        //             if ($relationMethodName && method_exists($record, $relationMethodName)) { 
        //                 // Detach the relationship by using relation method name before deleting the record
        //                 $record->{$relationMethodName}()->detach(); 
        //             }
        //         }

        //         // Delete the records
        //         $records->delete();
        //     }

        //     DB::commit();
    
        //     return response()->json([
        //         'status' => 'success',
        //         'message' => $model . '(s) has been deleted',
        //     ], 200); // successfully deleted, returned contents (status, message etc.)
    
        // } catch (\Throwable $e) {
        //     DB::rollback();
        //     throw new CustomException([
        //         'status' => 'failed',
        //         'message' => $model . '(s) can\'t be deleted, '. $e->getMessage(),
        //     ], 422); // 422, provided data invalid
        // }
    }

    public function bulkFetch(Request $request, $resourceName, $actionName)
    {
        // resource name
        // $resourceName can get as a method parameter
        // Or using $request method, $request->route('resourceName');
        // Convert to singular upper and lower case, e.g., 'users' to 'User' and 'user.
        if(!Utilities::isEmptyUniversalCheck($resourceName)) {
            $resourceUpper = Str::studly(Str::singular($resourceName));
            $resourceLower = Str::lcfirst(Str::singular($resourceName));
        }

        // action name, delete or assign or unassign
        if(!Utilities::isEmptyUniversalCheck($actionName)) {
            $actionUpper = Str::studly(Str::singular($actionName));
            $actionLower = Str::lcfirst(Str::singular($actionName));
        }  

        // relation ids
        if(!Utilities::isEmptyUniversalCheck($request->relationIds)) {
            $relationIds = $request->relationIds;
        }

        // relation method, e.g., User relation to Role using 'roles' method
        if(!Utilities::isEmptyUniversalCheck($request->relationMethod)) {
            $relationMethodUpper = Str::studly(Str::singular($request->relationMethod));
            $relationMethodLower = Str::lcfirst(Str::singular($request->relationMethod));
        }

        // relation type 1:1, e.g., ManyToMany, OneToMany, OneToOne
        if(!Utilities::isEmptyUniversalCheck($request->relationType)) {
            $relationTypeUpper = Str::studly(Str::singular($request->relationType));
            $relationTypeLower = Str::lcfirst(Str::singular($request->relationType));
        }

        // This should be e.g, 'users' or other plural resource name
        // $resourceName = $resource;
        // or
        // $resourceName = $request->route('resource');

        // Fully qualify class name
        $modelName = 'App\\Models\\' . $resourceUpper . '\\'. $resourceUpper;

        // Check if the model class exists, e.g., 'User'.
        if (!class_exists($modelName)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Model not found, model: '. $resourceUpper,
            ], 404); // 404, Not found
        }

        // if ($request->isMethod('post')) {
        //     // Bulk relation type first letter Upper case
        //     $relationTypeUpper = Str::studly(Str::singular($request->relationType));

        //     // Bulk relation type first letter lower case
        //     $relationTypeLower = Str::lcfirst(Str::singular($request->relationType));

        //     if ((Utilities::isEmptyUniversalCheck($request->relationMethod) ||
        //         Utilities::isEmptyUniversalCheck($request->relationType) ||
        //         Utilities::isEmptyUniversalCheck($request->relationIds)) &&
        //         $actionLower === 'delete') {

        //         // Fully qualified class name
        //         $controllerName = "App\\Http\\Controllers\\BulkAction\\BulkFetchActionController";

        //         // Check if the class exists, e.g., 'BulkManyToManyActionController'.
        //         if (!class_exists($controllerName)) {
        //             throw new CustomException([
        //                 'status' => 'failed',
        //                 'message' => 'Controller not found, controller: ' . $controllerName,
        //             ], 404); // 404, Not found
        //         }

        //         // Instantiate the class
        //         $controllerInstance = app($controllerName);

        //         return $controllerInstance->{$actionLower}($request, $modelName, $actionLower);

        //     } else {
        //         // Fully qualified class name
        //         $controllerName = "App\\Http\\Controllers\\BulkAction\\Bulk{$relationTypeUpper}ActionController";

        //         // Check if the class exists, e.g., 'BulkManyToManyActionController'.
        //         if (!class_exists($controllerName)) {
        //             throw new CustomException([
        //                 'status' => 'failed',
        //                 'message' => 'Controller not found, controller: ' . $controllerName,
        //             ], 404); // 404, Not found
        //         }

        //         // Instantiate the controller class
        //         $controllerInstance = app($controllerName);
        //         $actionMethod = $relationTypeLower.$actionUpper;

        //         return $controllerInstance->{$actionMethod}($request, $modelName, $actionMethod);
        //     }
        // }

        if ($request->isMethod('get')) {
            if(!Utilities::isEmptyUniversalCheck($actionLower)) {
                // Instantiate the class
                $controllerInstance = app(BulkFetchController::class);
                $actionMethod = $actionLower;

                return $controllerInstance->{$actionMethod}($request, $modelName, $actionMethod, $resourceLower);
            }
        }
    }
}

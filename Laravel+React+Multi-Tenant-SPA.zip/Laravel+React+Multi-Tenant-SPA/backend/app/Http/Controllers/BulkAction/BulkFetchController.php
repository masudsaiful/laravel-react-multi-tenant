<?php

namespace App\Http\Controllers\BulkAction;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
//Laravel's Str helper to format the string and app() to dynamically resolve the model.
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;

use App\Exceptions\CustomException;


class BulkFetchController extends Controller
{
    /**
     * Store a newly created resource in storage.
     * Param ($resource) value from Route::prefix('{resource}').
     * app() to dynamically resolve the model.
     * app($modelName) resolves the model instance dynamically.
     * Str::studly() capitalizes the first letter.
     * Str::singular($resource) converts "users" to "user".
     * 'App\\Models\\' . $modelName . '\\'. $modelName creates the full model class path
     * 
     */
    public function assign($request, $model, $action, $resourceLower)
    {
        try {

            $resourceStatusScope = "{$resourceLower}StatusScope";
            // initiate class
            $modelInstance = app($model);
            $allQuery = $modelInstance->$resourceStatusScope(1);

            // db:seed artisan at the beginning will create superadmin user/role 1
            // Exclude SuperAdmin for non-superadmin users
            if (Auth::id() != 1) {
                $allQuery->where('id', '!=', 1);
            }

            $allRoles = $allQuery->get();
    
            return response()->json([
                'status' => 'success',
                'message' => "{$model} records loaded successfully",
                'allRoles' => $allRoles,
            ], 200); // successfully deleted, returned contents (status, message etc.)
    
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => "{$model} records couldn\'t be loaded, {$e->getMessage()}",
            ], 422); // 422, provided data invalid
        }
    }

    public function unassign($request, $model, $action, $resourceLower)
    {
        try {
            // Convert to upper case
            $relationMethodUpper = Str::studly(Str::singular($request->query('relationMethod')));

            // Fully qualified class name
            $relationModelName = 'App\\Models\\' . $relationMethodUpper . '\\'. $relationMethodUpper;

            // Check if the model class exists, e.g., 'User'.
            if (!class_exists($relationModelName)) {
                throw new CustomException([
                    'status' => 'failed',
                    'message' => 'Relation model not found, model: '. $relationMethodUpper,
                ], 404); // 404, Not found
            }

            $resourceStatusScope = "{$resourceLower}StatusScope";
            // Instantiate the class
            $modelInstance = app($model);
            $allQuery = $modelInstance->$resourceStatusScope(1);

            // db:seed artisan at the beginning will create superadmin user/role 1
            // Exclude SuperAdmin for non-superadmin users
            if (Auth::id() != 1) {
                $allQuery->where('id', '!=', 1);
            }

            // Fetched that have at least relationship model exists.
            $allRoles = $allQuery->has($request->query('relationMethod'))->get();
    
            return response()->json([
                'status' => 'success',
                'message' => "{$model} records loaded successfully",
                'allRoles' => $allRoles,
            ], 200); // successfully deleted, returned contents (status, message etc.)
    
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => "{$model} records couldn\'t be loaded, {$e->getMessage()}",
            ], 404); // 404, cannot find the requested resource.
        }
    }
}

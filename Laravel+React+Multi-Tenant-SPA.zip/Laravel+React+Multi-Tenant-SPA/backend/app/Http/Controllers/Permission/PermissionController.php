<?php

namespace App\Http\Controllers\Permission;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;

use App\Models\Role\Role;
use App\Models\User\User;
use App\Exceptions\CustomException;
use App\Models\Permission\Permission;
use App\http\Requests\Permission\PermissionRequest;
use App\Services\Permission\PermissionModelPrepareDatasetService;

class PermissionController extends Controller
{
    protected $service;

    /**
     * Constructor to initialize PermissionModelPrepareDatasetService.
     *
     * @param \App\Services\Permission\PermissionModelPrepareDatasetService $service
     */
    public function __construct(PermissionModelPrepareDatasetService $service)
    {
        $this->service = $service;
    }
    
    /**
     * Fetch a list of permissions for the authenticated user.
     *
     * Filters permissions based on user ID and role conditions and includes additional 
     * permission dataset models. Returns the data as a JSON response.
     *
     * @param \Illuminate\Http\Request $request The HTTP request instance.
     * @return \Illuminate\Http\JsonResponse JSON response with permissions and models.
     * @throws \App\Exceptions\CustomException If an error occurs during execution.
     */
    public function index(Request $request)
    {
        $response = Gate::inspect('viewAny', Permission::class);
        if ($response->allowed()) {

            // Get the authenticated user's ID
            $userId = Auth::id();

            /*
            * Construct a query to retrieve permissions:
            * - Include records where the 'user_id' JSON array does not have exactly one value.
            * - If 'user_id' has exactly one value:
            *   - Exclude records where the value matches the current user ID (unless the user is an admin, userId === 1).
            * - For non-admin users (userId !== 1):
            *   - Exclude records with 'role_id' equal to 1.
            * - Select specific fields from the permissions table.
            */
            $query = Permission::with([
                'createdByUser:id,name,username,created_by,updated_by', 
                'updatedByUser:id,name,username,created_by,updated_by',
            ])
            ->select(
                'id','user_id','role_id','uuid','model',
                'create','update','delete','title','note',
                'created_by','updated_by',
            )
            ->where(function ($query) use ($userId) {
                $query->whereJsonLength('permissions.user_id', '!=', 1) 
                ->orWhere(function ($subQuery) use ($userId) {
                    $subQuery->whereJsonLength('permissions.user_id', 1) 
                    ->whereNot(function ($innerQuery) use ($userId) {
                        $innerQuery->when($userId !== 1, function ($query) use ($userId) {
                            $query->whereJsonContains('permissions.user_id', $userId);
                        });
                    });
                });
            })
            ->when($userId != 1, function ($query) use ($userId) {
                $query->where('permissions.role_id', '!=', 1)
                    ->where('permissions.created_by', $userId);
            });

            // Prepare additional dataset models related to permissions
            $modelQuery = $this->service->prepareModelDataset();

            // if (Auth::id() != 1) {
            //     $query->whereNot('role_id', 1);
            // }

            // Fetch the permissions based on the constructed query
            $permissions = $query->latest()->get();

            // Fetch the additional permission models.
            $permissionModels = $modelQuery;
            
            // Return the permissions and models as a JSON response
            return response()->json([
                'status' => 'success',
                'message' => 'Permissions loaded successfully',
                'permissions' => $permissions,
                'permissionModels' => $permissionModels,
            ], 200); // 200, successfully retrieved
        } else {
            // Policy denied
            return response()->json([
                'status' => 'failed',
                'message' => 'Permissions couldn\'t be loaded.',
                'errors' => $response->message(),
            ], 200); //403, no permission, 200 for graceful response
        }

        // try{
        //     // Get the authenticated user's ID
        //     $userId = Auth::id();

        //     /*
        //     * Construct a query to retrieve permissions:
        //     * - Include records where the 'user_id' JSON array does not have exactly one value.
        //     * - If 'user_id' has exactly one value:
        //     *   - Exclude records where the value matches the current user ID (unless the user is an admin, userId === 1).
        //     * - For non-admin users (userId !== 1):
        //     *   - Exclude records with 'role_id' equal to 1.
        //     * - Select specific fields from the permissions table.
        //     */
        //     $query = Permission::where(function ($query) use ($userId) {
        //         $query->whereJsonLength('user_id', '!=', 1) 
        //         ->orWhere(function ($subQuery) use ($userId) {
        //             $subQuery->whereJsonLength('user_id', 1) 
        //             ->whereNot(function ($innerQuery) use ($userId) {
        //                 $innerQuery->when($userId !== 1, function ($query) use ($userId) {
        //                     $query->whereJsonContains('user_id', $userId);
        //                 });
        //             });
        //         });
        //     })->when($userId != 1, function ($query) {
        //         $query->where('role_id', '!=', 1);
        //     })->select('id','uuid','title','note','create','update','delete','role_id','model','user_id');

        //     // Prepare additional dataset models related to permissions
        //     $modelQuery = $this->service->prepareModelDataset();

        //     // if (Auth::id() != 1) {
        //     //     $query->whereNot('role_id', 1);
        //     // }

        //     // Fetch the permissions based on the constructed query
        //     $permissions = $query->get();

        //     // Fetch the additional permission models.
        //     $permissionModels = $modelQuery;
            
        //     // Return the permissions and models as a JSON response
        //     return response()->json([
        //         'status' => 'success',
        //         'message' => 'Permissions loaded successfully',
        //         'permissions' => $permissions,
        //         'permissionModels' => $permissionModels,
        //     ], 200); // 200, successfully retrieved

        // }  catch (\Throwable $e) {
        //     // Handle any exceptions that occur during execution and throw a CustomException
        //     throw new CustomException([
        //         'status' => 'failed',
        //         'message' => 'Permissions couldn\'t be loaded.',
        //         'errors' => $e->getMessage(),
        //     ], 200); // 404, resource couldn't be found, 200 for graceful response
        // }
    }

    /**
     * Store a newly created permission resource in storage.
     *
     * @param \App\Http\Requests\Permission\PermissionRequest $request The request instance with permission data.
     * @return \Illuminate\Http\JsonResponse JSON response with the created permission.
     * @throws \App\Exceptions\CustomException If permission creation fails.
     */
    public function store(PermissionRequest $request)
    {
        try {
            $response = Gate::inspect('create', Permission::class);
            if ($response->allowed()) {

                DB::beginTransaction();

                $permission = new Permission();
                // Collect and merge resource fillable data with creator information.
                $permissionFillableData = collect($request->only($permission->getFillable()));
                $createdByFillableData = collect(['created_by' => Auth::id(), 'updated_by' => Auth::id()])->only($permission->getFillable());
                $permissionData = $createdByFillableData->merge($permissionFillableData)->all();
                $permission->fill($permissionData)->save();

                // Attach role to the permission
                $permission->role()->associate($request->role_id);
                // Attach created by to the permission
                $permission->createdByUser()->associate(Auth::id());

                // Handle the `role` field from the payload
                // If role not array from payload (like used in user/role controller) then need to validate
                // $roles = is_array($request->role) ? $request->role : [$request->role];
                // $validRoles = Role::whereIn('id', $roles)->pluck('id')->toArray();

                // if (empty($validRoles)) {
                //     throw new CustomException([
                //         'status' => 'failed',
                //         'message' => 'Invalid or non-existent roles provided.',
                //     ], 422);
                // }

                // Attaching with additional 'created_by' column in the role_permission table
                // $permission->roles()->detach();
                // $permission->roles()->attach($request->roles, ['created_by' => Auth::id()]);
                // $permission->roles()->syncWithPivotValues([$request->role], ['created_by' => Auth::id()]);

                // Role assigned to permission record track for role chart table
                // event(new UserEvent($permission)); or
                // UserEvent::dispatch($permission);

                $permission->save();

                // Commit the transaction after saving
                DB::commit();

                return response()->json([
                    'status' => 'success',
                    'message' => 'Permission has been created',
                    'permission' => $permission,
                ], 201); // 201, successfully created
            } else {
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Permission can\'t be created',
                    'errors' => $response->message(),
                ], 403); //403, no permission, 200 for graceful response
            }

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Permission can\'t be created, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Display the specified permission resource.
     *
     * @param \App\Http\Requests\Permission\PermissionRequest $permission The requested permission instance.
     * @return \Illuminate\Http\JsonResponse JSON response with the permission details.
     * @throws \App\Exceptions\CustomException If the permission resource can't be loaded.
     */
    public function show(Permission $permission)
    {
        try {
            $response = Gate::inspect('view', $permission);
            if ($response->allowed()) {

                // Prepare additional dataset models related to the permission.
                $permissionModels = $this->service->prepareModelDataset();

                // Find the specific permission by ID and return it with related models.
                $permission = Permission::whereId($permission->id)->first();

                return response()->json([
                    'status' => 'success',
                    'message' => 'Permissions or Permission models loaded',
                    'permissionModels' => $permissionModels,
                    'permissions' => $permission,
                ], 200); // 200, successfully retrieved

            } else {
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Permissions or Permission models couldn\'t be loaded',
                    'errors' => $response->message(),
                ], 200); //403, no permission, 200 for graceful response
            }

        } catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Permissions or Permission models couldn\'t be loaded',
                'errors' => $e->getMessage(),
            ], 200); // 404, resource couldn't be found, 200 for graceful response
        }
    }

    /**
     * Update the specified permission resource in storage.
     *
     * @param \App\Http\Requests\Permission\PermissionRequest $request The request with updated data.
     * @param \App\Models\Permission\Permission $permission The permission instance to update.
     * @return \Illuminate\Http\JsonResponse JSON response with updated permission.
     * @throws \App\Exceptions\CustomException If permission update fails.
     */
    public function update(PermissionRequest $request, Permission $permission)
    {
        try {
            $response = Gate::inspect('update', $permission);
            if ($response->allowed()) {

                DB::beginTransaction();
                // Find the permission instance by ID and update it
                $permission = $permission::whereId($permission->id)->first();

                // Handle array status field
                // $status = $request->input('status');
                // if (is_array($status)) {
                //     $status = $status[0]; // or any appropriate serialization method
                // }

                // Merge user fillable data with updater information.
                $fillableData = collect($request->only($permission->getFillable()));
                $createdByFillableData = collect(['updated_by' => Auth::id()])->only($permission->getFillable());
                $datas = $createdByFillableData->merge($fillableData)->all();
                $permission->fill($datas);

                // Attach role to the permission
                $permission->role()->associate($request->role_id);
                // Attach updated by user to the permission
                $permission->updatedByUser()->associate(Auth::id());

                // Role assigned to user record track for role chart table
                // event(new UserEvent($user)); or
                // UserEvent::dispatch($user);

                $permission->save();
                // $userFillableData = $request->only($user->getFillable());
                // $user->fill($userFillableData);
                // $user->save();

                // Commit the transaction after saving
                DB::commit();

                return response()->json([
                    'status' => 'success',
                    'message' => 'Permission has been updated',
                    'permission' => $permission,
                ], 200); // 200, successfully retrieved and updated
            } else {
                return response()->json([
                    'status' => 'failed',
                    'message' => 'Permission can\'t be updated',
                    'errors' => $response->message(),
                ], 403); //403, no permission, 200 for graceful response
            }

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Permission can\'t be updated, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Remove the specified permission resource from storage.
     *
     * @param \App\Models\Permission\Permission $permission The permission instance to delete.
     * @return \Illuminate\Http\JsonResponse JSON response indicating the deletion result.
     */
    public function destroy(Permission $permission)
    {
        //
    }
}

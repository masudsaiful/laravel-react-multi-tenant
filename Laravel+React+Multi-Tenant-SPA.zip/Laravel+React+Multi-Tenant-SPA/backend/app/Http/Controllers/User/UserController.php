<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Gate;

use App\Exceptions\CustomException;
use App\Models\User\User;
use App\Http\Requests\User\UserRequest;
use App\Helpers\Utilities;
use App\Services\Permission\PermissionDatasetService;
use App\Repositories\QueryRepository\UserQueryRepository\UserSqlQueryRepository;
use App\Repositories\QueryRepository\UserQueryRepository\UserQueryRepository;

class UserController extends Controller
{
    protected $service;
    protected $userSqlQueryRepository;
    protected $userQueryRepository;

    public function __construct(
        PermissionDatasetService $service,
        UserSqlQueryRepository $userSqlQueryRepository,
        UserQueryRepository $userQueryRepository,
    ) {
        $this->service = $service;
        $this->userSqlQueryRepository = $userSqlQueryRepository;
        $this->userQueryRepository = $userQueryRepository;
    }

    /**
     * Display a paginated listing of resource with optional filtering and sorting.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(Request $request)
    {
        $response = Gate::inspect('viewAny', User::class);
        if ($response->allowed()) {

            $page = $request->input('page', 1);
            $pageSize = $request->input('pageSize', 20);
            if ($request->has('filterModel')) {
                $filterModel = $request->input('filterModel');
            }
            if ($request->has('sortModel')) {
                $sortModel = $request->input('sortModel', []);
            }

            // // Call the repository with pagination and filtering for datas, descentant datas
            // $descendantData = $this->userSqlQueryRepository->getDescendantByRawSQL(
            //     User::class, Auth::id(), $page, $pageSize, $filterModel, $sortModel,
            // );

            // // LengthAwarePaginator object. Using ->items()
            // $paginatedData = collect($descendantData['paginated']->items());

            // return response()->json([
            //     'status' => 'success',
            //     'message' => 'User(s) has been loaded',
            //     'user' => $paginatedData->values(),
            //     'allUsers' => $descendantData['statusFiltered'],
            //     'total' => $descendantData['paginated']->total(),
            //     'current_page' => $descendantData['paginated']->currentPage(),
            //     'last_page' => $descendantData['paginated']->lastPage(),
            //     'permissionDataset' =>  $this->service->getDataset(),
            // ], 200); // 200, successfully retrieved

            // Call the repository with pagination and filtering for datas, descentant datas
            $descendantData = $this->userQueryRepository->getDescendantByEloq(
                $page, $pageSize, $filterModel, $sortModel,
            );
            
            $paginatedData = collect($descendantData['paginated']->items());
            
            return response()->json([
                'status' => 'success',
                'message' => 'User(s) has been loaded',
                'user' => $paginatedData->values(),
                'allUsers' => $descendantData['statusFiltered'],
                'total' => $descendantData['paginated']->total(),
                'current_page' => $descendantData['paginated']->currentPage(),
                'last_page' => $descendantData['paginated']->lastPage(),
                'permissionDataset' => $this->service->getDataset(),
            ], 200);
            
        } else {
            // Policy denied
            return response()->json([
                'status' => 'failed',
                'message' => 'User couldn\'t be loaded.',
                'errors' => $response->message(),
            ], 200); //403, no permission, 200 for graceful response
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param UserRequest $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function store(UserRequest $request)
    {
        DB::beginTransaction();
        try {
            $user = new User();

            // Collect and merge resource fillable data with creator information.
            $userFillableData = collect($request->only($user->getFillable()));
            $createdByFillableData = collect(['created_by' => Auth::id(), 'updated_by' => Auth::id()])->only($user->getFillable());
            $userData = $createdByFillableData->merge($userFillableData)->all();
            $user->fill($userData)->save();

            // Attaching with additional 'created_by' column in the role_user table
            // $user->roles()->detach();
            // $user->roles()->attach($request->roles, ['created_by' => Auth::id()]);
            $user->roles()->syncWithPivotValues($request->roles, ['created_by' => Auth::id(), 'updated_by' => Auth::id()]);

            // Role assigned to user record track for role chart table
            // event(new UserEvent($user)); or
            // UserEvent::dispatch($user);

            $user->save();

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'User has been created',
                'user' => $user,
            ], 201); // 201, successfully created

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'User can\'t be created, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Display the specified resource by id.
     *
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function show(string $id)
    {
        try {
            // Lazy eager loading not working with common pattern query
            // Lazy loading work with common pattern query (roleRelScope)
            if (Auth::id() != 1) {
                $user = User::roleRelNonSuperAdminScope('with', 'roles', 1)
                ->whereId($id)
                ->first();
            } else {
                $user = User::roleRelSuperAdminScope('with', 'roles', 1)
                ->whereId($id)
                ->first();
            }


            // lazy eager loading of selected fields of roles table 
            // $user->load('roles:id,name,title,created_by');

            // $user = User::whereId($id)->firstOrFail();
            // $user->load(['roles' => function ($query) {
            //     $query->roleStatusScope(1)
            //     ->select('roles.id', 'roles.name', 'roles.title', 'roles.created_by');
            // }]);

            return response()->json([
                'status' => 'success',
                'message' => 'User has been loaded',
                'user' => $user,
            ], 200); // 200, successfully retrieved

        } catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'User can\'t be loaded.',
                'errors' => $e->getMessage(),
            ], 200); // 404, resource couldn't be found, 200 for graceful response
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param UserRequest $request
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function update(UserRequest $request, string $id)
    {
        DB::beginTransaction();
        try {
            $user = User::whereId($id)->first();
            // $existingCreatedBy = $user->roles()->first()->pivot->created_by;

            // Handle array status field
            // $status = $request->input('status');
            // if (is_array($status)) {
            //     $status = $status[0]; // or any appropriate serialization method
            // }

            // Merge user fillable data with updater information.
            $userFillableData = collect($request->only($user->getFillable()));
            $createdByFillableData = collect(['updated_by' => Auth::id()])->only($user->getFillable());
            $userData = $userFillableData->merge($createdByFillableData)->all();
            $user->fill($userData);

            // Data count tracking before new attaching
            // event(new RoleBarChartDetachEvent($user)); or
            // RoleBarChartDetachEvent::dispatch($user);

            // Sync with additional 'created_by' column in role_user table
            // $user->roles()->syncWithPivotValues($request->roles, ['updated_by' => Auth::id(), 'created_by' => $existingCreatedBy]);
            $user->roles()->syncWithPivotValues($request->roles, ['updated_by' => Auth::id(), 'created_by' => $request->created_by]);
            
            // Role assigned to user record track for role chart table
            // event(new UserEvent($user)); or
            // UserEvent::dispatch($user);

            $user->save();
            // $userFillableData = $request->only($user->getFillable());
            // $user->fill($userFillableData);
            // $user->save();

            // Disabled users token deleted not to login when status disable
            if ($request->status === [2]) {
                $user->sanctumPersonalAccessTokens()->delete();
            }

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'User has been updated',
                'user' => $user,
            ], 200); // 200, successfully retrieved and updated

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'User can\'t be updated, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Remove the specified resource from storage.
     * Simple and non nested relationships deleting in here.
     * Complex or nested relationships deleting in model's boot method.
     *
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function destroy(string $id)
    {
        DB::beginTransaction();
        try {
            $user = User::find($id);
            $roleIds = $user->roles->pluck('id');

            $user->roles()->detach($roleIds->toArray()); 
            // // or
            // $user->roles()->detach($roleIds->all());
            // // or
            // $user->roles()->detach();
            $user->delete();

            DB::commit();
    
            return response()->json([
                'status' => 'success',
                'message' => 'User has been deleted',
            ], 200); // successfully deleted, returned contents (status, message etc.)
    
        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => 'User can\'t be deleted, '. $e->getMessage(),
            ], 422); // 422, provided data invalid
        }
    }
}


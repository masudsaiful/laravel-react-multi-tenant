<?php

namespace App\Http\Controllers\Setting;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

use App\Models\Setting\Setting;
use App\Exceptions\CustomException;
use App\Helpers\Utilities;


class SettingController extends Controller
{
    public function prepareThemeMode(Request $request) {
        DB::beginTransaction();
        try {
            $setting = new Setting();
            $themeModeFillableData = collect($request->only($setting->getFillable()));
            $createdByFillableData = collect(['created_by' => Auth::id(), 'updated_by' => Auth::id()])->only($setting->getFillable());
            $fillableData = $createdByFillableData->merge($themeModeFillableData)->all();
            $setting = Setting::updateOrcreate(
                ['user_id' => Auth::id()],
                $fillableData
            );

            DB::commit();

            return response()->json([
                'status' => 'success',
                'message' => 'Theme mode updated successfully',
                'themeMode' => $setting->theme_mode,
            ], 201); // 201, successfully created

        } catch (\Throwable $e) {
            DB::rollback();
            throw new CustomException([
                'status' => 'failed',
                'message' => "Theme mode can\'t be created. {$e->getMessage()}",
            ], 422); // 422, provided data invalid
        }
    }

    /**
     * Display the specified resource by id.
     *
     * @param string $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function getThemeMode(string $id) {
        try {
            $setting = Setting::where('user_id', $id)->first();

            if (Utilities::isEmptyUniversalCheck($setting)) {
                return response()->json([
                    'status' => 'failed',
                    'message' => 'No theme mode found, returning default value.',
                    'themeMode' => true, // Or the default theme mode you want to provide
                ], 200); // 200, successfully handled with default value
            }

            return response()->json([
                'status' => 'success',
                'message' => 'Theme mode has been loaded',
                'themeMode' => $setting->theme_mode,
            ], 200); // 200, successfully retrieved

        } catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Theme mode can\'t be loaded.',
                'errors' => $e->getMessage(),
            ], 200); // 404, cannot find the requested resource. 200 for graceful response.
        }
    }
}


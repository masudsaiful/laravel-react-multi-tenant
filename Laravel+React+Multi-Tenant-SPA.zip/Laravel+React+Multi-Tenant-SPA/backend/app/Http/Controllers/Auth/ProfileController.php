<?php

namespace App\Http\Controllers\Auth;

use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Gate;

use App\Exceptions\CustomException;
use App\Models\User\User;
use App\Services\Permission\PermissionDatasetService;

class ProfileController extends Controller
{
    protected $service;

    public function __construct(PermissionDatasetService $service)
    {
        $this->service = $service;
    }

    /**
     * Retrieve the authenticated user's profile.
     *
     * @return \Illuminate\Http\JsonResponse
     * @throws CustomException
     */
    public function profile()
    {
        $response = Gate::inspect('view-profile');
        if ($response->allowed()) {

            $user = Auth::user();
                
            // Validate the user instance
            if (!$user instanceof User) {
                throw new CustomException([
                    'status' => 'failed',
                    'message' => 'Profile not found.',
                    'errors' => 'Invalid User instance.',
                ], 200); // 500, instance not exists in internal server, 200, for graceful response 
            }
            
            // Active user profile always status === [1] 
            // Excluding inactive roles from active user profile
            // Excluding super admin role from none super admin profile
            if (Auth::id() != 1) {
                $user->load(['roles' => function($query) {
                    $query->where('roles.id', '!=', 1)
                    ->whereJsonContains('roles.status', 1);
                },'roles.permissions']);
                
            } else {
                $user->load(['roles' => function($query) {
                    $query->whereJsonContains('roles.status', 1);
                }, 'roles.permissions']);
            }

            // Hide sensitive fields like password and remember_token
            $user->makeHidden([
                'password', 
                'remember_token', 
                'deleted_at',
                'created_at',
                'updated_at',
            ]);
            
            // Hide fields for roles and permissions
            $user->roles->each(function($role) {
                $role->makeHidden(['created_at', 'updated_at', 'deleted_at']);
                $role->permissions->each(function($permission) {
                    $permission->makeHidden(['created_at', 'updated_at', 'deleted_at']);
                });
            });

            return response()->json([
                'status' => 'success',
                'message' => 'Profile found',
                'profile' => $user,
                'permissionDataset' =>  $this->service->getDataset(),
            ], 200);
        } else {
            // Policy denied
            return response()->json([
                'status' => 'failed',
                'message' => 'Profile not found',
                'errors' => $response->message(),
            ], 200); //403, no permission, 200 for graceful response
        }
    }
}

// OLD
// namespace App\Http\Controllers\Auth;

// use Illuminate\Http\Request;
// use App\Models\User\User;
// use Illuminate\Support\Facades\Auth;
// use App\Http\Controllers\Controller;
// use App\Exceptions\CustomException;

// class ProfileController extends Controller
// {
//     /**
//      * Handle unauthenticated user.
//      * Dependencies to Authenticate Middleware
//      * Dependencies to CustomUnauthenticateException
//      * Dpendencies to Exceptions Handler
//      */

//     public function profile()
//     {
//         // if(Auth::user()) {
//         //     return response()->json(Auth::user());
//         // } else {
//         //     return null;
//         // }

//         if (!Auth::check()) {
//             throw new CustomException([
//                 'status' => 'profile controller failed', 
//                 'message' => 'Profile controller exception occured, auth check failed'
//             ], 401);
//         }

//         $user = Auth::user();

//         // Lazy eager loading after retrieved User
//         // $user->load('roles'); 

//         // Ensure $user is an instance of the User model
//         if (!$user instanceof User) {
//             throw new CustomException([
//                 'status' => 'profile controller failed', 
//                 'message' => 'Profile controller exception occured, auth user instance of user model check failed'
//             ], 500);
//         }

//         // Decode status field from dB json format to PHP assoc array
//         if (is_string($user->status)) {
//             $user->status = json_decode($user->status, true);
//         }

//         // Exclude password and other sensitive fields
//         $user->makeHidden(['password', 'remember_token']);

//         // lazy eager loading of selected fields of roles table 
//         $user->load('roles:id,name,title,created_by');

//         return response()->json([
//             'status' => 'success',
//             'message' => 'Found profile',
//             'profile' => $user, 
//         ], 200);
//     }
// }
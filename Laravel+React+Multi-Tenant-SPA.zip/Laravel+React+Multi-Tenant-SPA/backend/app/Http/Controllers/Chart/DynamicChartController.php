<?php

namespace App\Http\Controllers\Chart;

use App\Http\Controllers\Controller;
//Laravel's Str helper to format the string and app() to dynamically resolve the model.
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Auth;

use App\Exceptions\CustomException;
use App\Http\Requests\Chart\ChartRequest;


class DynamicChartController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:sanctum');
    }
    
    /**
     * Store a newly created resource in storage.
     * Param ($resource) value from Route::prefix('{resource}').
     * app() to dynamically resolve the model.
     * app($modelName) resolves the model instance dynamically.
     * Str::studly() capitalizes the first letter.
     * Str::singular($resource) converts "users" to "user".
     * 'App\\Models\\' . $modelName . '\\'. $modelName creates the full model class path
     * @param \App\Http\Requests\Chart\ChartRequest $request
     * @param mixed $resourceName
     * @param mixed $chartName
     */
    public function handle(ChartRequest $request, $resourceName, $chartName)
    {
        if (!Auth::check()) {
            throw new CustomException([
                'status' => 'failed',
                'message' => 'Profile not found.',
                'errors' => 'Unauthenticated user'
            ], 200); // 401, unauthenticated, 200, for graceful response
        }

        // These should be use to format class.
        $resource = $resourceName;
        $chart = $chartName;
        // or
        // $resourceName = $request->route('resourceName');

        // Convert to singular upper case, e.g., 'users' to 'User'.
        $resourceUpper = Str::studly(Str::singular($resource));
        $chartUpper = Str::studly(Str::singular($chart));

        // Fully qualify model and service class name.
        $prepareDatasetServiceName = "App\\Services\\Chart\\{$resourceUpper}{$chartUpper}ChartPrepareDatasetService";
        $datasetServiceName = "App\\Services\\Chart\\{$resourceUpper}{$chartUpper}ChartDatasetService";
        $modelName = 'App\\Models\\' . $resourceUpper . '\\'. $resourceUpper;
        $chartModelName = "App\\Models\\Chart\\{$resourceUpper}{$chartUpper}Chart";

        // Check if the service class exists, e.g., 'ServiceClassName'.
        // if (!class_exists($prepareDatasetServiceName)) {
        //     throw new CustomException([
        //         'status' => 'failed',
        //         'message' => "Service not found, {$resourceUpper}{$chartUpper}ChartPrepareDatasetService",
        //     ], 404); // 404, Not found
        // }

        // Check if the model class exists, e.g., 'User'.
        // if (!class_exists($modelName)) {
        //     throw new CustomException([
        //         'status' => 'failed',
        //         'message' => "Model not found, {$modelName}",
        //     ], 404); // 404, Not found
        // }

        // Check if chart model class exists, e.g., 'UserBarChart'.
        // if (!class_exists($chartModelName)) {
        //     throw new CustomException([
        //         'status' => 'failed',
        //         'message' => "Char model not found, {$resourceUpper}{$chartUpper}Chart",
        //     ], 404); // 404, Not found
        // }

        // Fully qualify controller class name, e.g, 'ControllerClassNameController'.
        $controllerName = "App\\Http\\Controllers\\Chart\\{$resourceUpper}{$chartUpper}ChartController";

        // Check if the class exists, e.g., 'UserBarChartController'.
        // if (!class_exists($controllerName)) {
        //     throw new CustomException([
        //         'status' => 'failed',
        //         'message' => "Controller not found, {$resourceUpper}{$chartUpper}ChartController",
        //     ], 404); // 404, Not found
        // }

        $this->ensureClassesExist([$prepareDatasetServiceName, $modelName, $chartModelName, $controllerName]);

        // Instantiate the controller class
        $controllerInstance = app($controllerName);
        // Call to class method on the instance
        $controllerInstance->prepareDataset(
            $request, 
            $modelName, 
            $chartModelName, 
            $prepareDatasetServiceName
        );

        if ($request->isMethod('post')) {
            // Call the 'getDataset' method on the instance
            return $controllerInstance->getDataset(
                $request, 
                $chartModelName, 
                $datasetServiceName
            );

        } elseif ($request->isMethod('get')) {
            // Call the 'getDatacolumn' method on the instance
            return $controllerInstance->getDatacolumn($request, $modelName, $chartModelName);
        }
    }

    protected function ensureClassesExist(array $classes)
    {
        foreach ($classes as $class) {
            if (!class_exists($class)) {
                throw new CustomException([
                    'status' => 'failed',
                    'message' => "Problems occured in DynamicChartController",
                    'errors' => "Class not found: {$class}",
                ], 404); // 404, Not found
            }
        }
    }    
}

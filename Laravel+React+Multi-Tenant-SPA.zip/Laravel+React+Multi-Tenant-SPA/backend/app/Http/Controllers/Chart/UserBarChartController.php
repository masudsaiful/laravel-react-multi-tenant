<?php

namespace App\Http\Controllers\Chart;

use App\Http\Controllers\Controller;
use App\Exceptions\CustomException;


class UserBarChartController extends Controller
{
    /**
     * @param mixed $chartUpper
     * @param mixed $resourceUpper
     * 
     */
    public function prepareDataset(
        $request, 
        $modelName, 
        $chartModelName, 
        $prepareDatasetServiceName)
    {
        // Instantiate the class
        $serviceInstance = app($prepareDatasetServiceName);
        // Call to class method on the instance
        $serviceInstance->prepareDataset($modelName, $chartModelName);
    }
    
    public function getDataset(
        $request, 
        $chartModelName, 
        $datasetServiceName)
    {
        // Assumes 'type' || 'period' is an array
        $type = $request->type;
        $period = $request->period;

        // Check if the class exists.
        if (!class_exists($datasetServiceName)) {
            throw new CustomException([
                'status' => 'failed',
                'message' => "Service not found, {$datasetServiceName}",
            ], 404); // 404, Not found
        }

        try {
            if (is_array($type) && is_array($period)) {
                // Instantiate the class
                $serviceInstance = app($datasetServiceName);
                // Call to class method on the instance
                $records = $serviceInstance->getDataset($request->all());
    
                return response()->json([
                    'status' => 'success',
                    'message' => "Dataset found of {$chartModelName}",
                    'dataset' => $records,
                ], 200); 
            }
        } catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => "Dataset didn't found of {$chartModelName}.",
                'errors' => $e->getMessage(),
            ], 200); // 404, cannot find the requested resource. 200 for graceful response.
        }
    }

    public function getDatacolumn($request, $modelName, $chartModelName)
    {
        // Instantiate the controller class
        $modelInstance = app($modelName);
        $chartModelInstance = app($chartModelName);

        try{
            $allChartUserTypes = $chartModelInstance->distinct()->pluck('user_type');
            $allChartUserTypeYears = $chartModelInstance->distinct()->pluck('year');

            return response()->json([
                'status' => 'success',
                'message' => "Column datas loaded successfully of {$chartModelName}",
                'allChartRecords' => $allChartUserTypes,
                'allChartYearRecords' => $allChartUserTypeYears,
            ], 200); // 200, successfully retrieved

        }  catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => "Column datas not found of {$chartModelName}.",
                'errors' => $e->getMessage(),
            ], 200); // 404, cannot find the requested resource. 200 for graceful response.
        }
    }
}

<?php

namespace App\Http\Controllers\Chart;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
//Laravel's Str helper to format the string and app() to dynamically resolve the model.
use Illuminate\Support\Str;
use App\Exceptions\CustomException;
use Illuminate\Support\Facades\DB;

use App\Http\Requests\Chart\ChartRequest;


class UserPieChartController extends Controller
{
    /**
     * @param mixed $chartUpper
     * @param mixed $resourceUpper
     * 
     */
    public function prepareDataset(
        $request, 
        $modelName, 
        $chartModelName, 
        $prepareDatasetServiceName)
    {
        // Instantiate the class
        $serviceInstance = app($prepareDatasetServiceName);
        // Call to class method on the instance
        $serviceInstance->prepareDataset($modelName, $chartModelName);
    }

    public function getDatacolumn($request, $modelName, $chartModelName)
    {
        // Instantiate the controller class
        $modelInstance = app($modelName);
        $chartModelInstance = app($chartModelName);

        try{
            // Define default dataset
            $userDefaultPieChartDatas = [
                'total_users' => 0,
                'deleted_users' => 0,
                'existing_users' => 0,
                'deleted_user_percent' => 0,
                'existing_user_percent' => 0,
                'deleted_enable_user_percent' => 0,
                'existing_enable_user_percent' => 0,
                'deleted_disable_user_percent' => 0,
                'existing_disable_user_percent' => 0,
            ];

            $userPieChartDatas = $chartModelInstance->latest()->first();
            $pieChartDatas = collect($userDefaultPieChartDatas)->merge($userPieChartDatas ? $userPieChartDatas : [])->all();

            $data = [
                ['label' => 'Users', 'value' => $pieChartDatas['total_users']],
                ['label' => 'Deleted', 'value' => $pieChartDatas['deleted_users']],
                ['label' => 'Existing', 'value' => $pieChartDatas['existing_users']],
                ['label' => 'Deleted %', 'value' => $pieChartDatas['deleted_user_percent']],
                ['label' => 'Existing %', 'value' => $pieChartDatas['existing_user_percent']],
                ['label' => 'Deleted Enbl %', 'value' => $pieChartDatas['deleted_enable_user_percent']],
                ['label' => 'Exsting Enbl %', 'value' => $pieChartDatas['existing_enable_user_percent']],
                ['label' => 'Deleted Disbl %', 'value' => $pieChartDatas['deleted_disable_user_percent']],
                ['label' => 'Existing Disbl %', 'value' => $pieChartDatas['existing_disable_user_percent']],
            ];

            return response()->json([
                'status' => 'success',
                'message' => "Chart datas loaded successfully of {$chartModelName}",
                'dataset' => $data,
            ], 200); // 200, successfully retrieved

        }  catch (\Throwable $e) {
            throw new CustomException([
                'status' => 'failed',
                'message' => "Chart datas couldn\'t be loaded of {$chartModelName}.",
                'errors' => $e->getMessage(),
            ], 200); // 404, cannot find the requested resource. 200 for graceful response.
        }
    }
}

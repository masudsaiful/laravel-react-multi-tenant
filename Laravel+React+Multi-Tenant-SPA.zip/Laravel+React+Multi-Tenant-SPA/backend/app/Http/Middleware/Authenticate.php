<?php

namespace App\Http\Middleware;

use Illuminate\Auth\Middleware\Authenticate as Middleware;
use Illuminate\Http\Request;
use App\Exceptions\CustomException;

class Authenticate extends Middleware
{
    /**
     * Get the path the user should be redirected to when they are not authenticated.
     */
    protected function redirectTo(Request $request): ?string
    {
        // if (!$request->expectsJson()) {
        //     return route('login');
        // }
        
        return $request->expectsJson() ? null : route('/');

        // Ensure all requests are treated as API requests
        // if ($this->isApiRequest($request)) {
        //     return null; // Do nothing for API requests
        // }

        // Optionally handle non-API requests (strict API apps may not need this)
        // return null; // Prevent any redirection
    }

    /**
     * Handle unauthenticated user.
     */
    protected function unauthenticated($request, array $guards)
    {
        if ($request->expectsJson()) {
            throw new CustomException([
                'status' => 'unauthenticated',
                'message' => 'middleware unauthenticated message',
                'errors' => 'User is not authenticated, Please check your authentication token.'
            ], 200); // 401 provided unauthenticated, 200 for graceful response
        }
    }

    /**
     * Check if the request is API-based.
     */
    private function isApiRequest(Request $request): bool
    {
        return $request->expectsJson();
    }
}

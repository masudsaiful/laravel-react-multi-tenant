<?php

namespace App\Http\Requests\Chart;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class ChartRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        // Authorize all requests for this form request.
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return $this->chartRules();
    }

    /**
     * Define rules for POST requests.
     *
     * @return array
     */
    private function postRules() {
        $rules = [
            'type' => ['required', 'array', 'min:1'], // Type must be an array with at least one item.
            'type.*' => ['string', 'min:1'],  // Type must be an array with at least one item.
            'period' => ['required', 'array'],
            'period.*' => ['integer', 'numeric'],
        ];
        return $rules;
    }

    /**
     * Choose rules based on request method.
     *
     * @return array
     */
    private function combinationRules() {
        $rules = [];
        if (Request::isMethod('post')) {
            $rules = $this->postRules();
            return $rules;
        } else {
            return $rules;
        }
    }

    /**
     * Define the combination rules
     *
     * @return array
     */
    private function chartRules()
    {
        $rules = $this->combinationRules();
        return $rules;
    }

    /**
     * Customize the validation messages for this request.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'type.required' => 'Required type.',
            'type.array' => 'Type must be array.',
            'period.required' => 'Required period.',
            'period.array' => 'Period must be array.',
            // Additional custom messages as needed.
        ];
    }

    /**
     * Filters to be applied to the input before validation.
     *
     * @return array
     */
    public function filters(): array
    {
        return [
            'type.*' => 'trim', // Filter to trim.
        ];
    }
}

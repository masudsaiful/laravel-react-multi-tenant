<?php

namespace App\Http\Requests\User;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class UserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize(): bool
    {
        // Authorize all requests for this form request.
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return $this->userRules();
    }

    /**
     * Define rules for POST requests (creating a new role).
     *
     * @return array
     */
    private function postRules() {
        $rules = [
            'name' => 'required|string|max:255',
            'username' => 'required|string|max:255|unique:users,username',
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
            'status' => ['required', 'array', 'min:1'], // Status must be an array with at least one item.
            'status.*' => ['integer', 'numeric', 'min:1'],  // Status must be an array with at least one item.
            'roles' => ['required', 'array'],
            'roles.*' => ['integer', 'numeric', 'exists:roles,id'], // Roles must be valid role IDs.
            'password' => 'required|string|min:8|confirmed',
        ];
        return $rules;
    }

    /**
     * Define rules for PUT requests (updating an existing role).
     *
     * @return array
     */
    private function putRules() {
        $rules = [
            'name' => 'required|string|max:255',
        ];
        $rules['username'] = ['required', 'string', 'max:255', Rule::unique('users','username')->ignore(Request::input('id'),'id')];
        $rules['email'] = ['required', 'string', 'email', 'max:255', Rule::unique('users','email')->ignore(Request::input('id'),'id')];
        $rules['status'] = ['required', 'array', 'min:1']; // Status must be an array with at least one item.
        $rules['status.*'] = ['integer', 'numeric'];
        $rules['roles'] = ['required', 'array', 'exists:roles,id']; // Roles must be valid role IDs.
        $rules['roles.*'] = ['integer', 'numeric'];
        $rules['password'] = 'nullable|sometimes|string|min:8|confirmed';
        return $rules;
    }

    /**
     * Choose rules based on request method.
     *
     * @return array
     */
    private function combinationRules() {
        if (Request::isMethod('post')) {
            $rules = $this->postRules();
            return $rules;
        }

        if (Request::isMethod('put')) {
            $rules = $this->putRules();
            return $rules;
        }
    }

    /**
     * Define the combination rules
     *
     * @return array
     */
    private function userRules()
    {
        $rules = $this->combinationRules();
        return $rules;
    }

    /**
     * Customize the validation messages for this request.
     *
     * @return array
     */
    public function messages(): array
    {
        return [
            'email.unique' => 'The email has already been taken.',
            'password.confirmed' => 'The password confirmation does not match.',
            // Additional custom messages as needed.
        ];
    }

    /**
     * Filters to be applied to the input before validation.
     *
     * @return array
     */
    public function filters(): array
    {
        return [
            'email' => 'trim|lower', // Filter to trim and convert email to lowercase.
            'name' => 'trim|capitalize', // Filter to trim and capitalize name.
        ];
    }
}

// OLD
// namespace App\Http\Requests\User;

// use Illuminate\Http\Request;
// use Illuminate\Validation\Rule;
// use Illuminate\Foundation\Http\FormRequest;

// class UserRequest extends FormRequest
// {
//     /**
//      * Determine if the user is authorized to make this request.
//      */
//     public function authorize(): bool
//     {
//         return true;
//     }

//     /**
//      * Get the validation rules that apply to the request.
//      *
//      * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
//      */
//     public function rules(): array
//     {
//         return $this->userRules();
//     }

//     private function postRules() {
//         $rules = [
//             'name' => 'required|string|max:255',
//             'username' => 'required|string|max:255|unique:users,username',
//             'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email'],
//             'status' => ['required', 'array'],
//             'status.*' => ['integer', 'numeric'],
//             'roles' => ['required', 'array'],
//             'roles.*' => ['integer', 'numeric'],
//             'password' => 'required|string|min:8|confirmed',
//         ];
//         return $rules;
//     }

//     private function putRules() {
//         $rules = [
//             'name' => 'required|string|max:255',
//         ];
//         $rules['username'] = ['required', 'string', 'max:255', Rule::unique('users','username')->ignore(Request::input('id'),'id')];
//         $rules['email'] = ['required', 'string', 'email', 'max:255', Rule::unique('users','email')->ignore(Request::input('id'),'id')];
//         $rules['status'] = ['required', 'array'];
//         $rules['status.*'] = ['integer', 'numeric'];
//         $rules['roles'] = ['required', 'array'];
//         $rules['roles.*'] = ['integer', 'numeric'];
//         $rules['password'] = 'nullable|sometimes|string|min:8|confirmed';
//         return $rules;
//     }

//     private function combinationRules() {
//         if (Request::isMethod('post')) {
//             $rules = $this->postRules();
//             return $rules;
//         }

//         if (Request::isMethod('put')) {
//             $rules = $this->putRules();
//             return $rules;
//         }
//     }

//     private function userRules()
//     {
//         $rules = $this->combinationRules();
//         return $rules;
//     }
// }

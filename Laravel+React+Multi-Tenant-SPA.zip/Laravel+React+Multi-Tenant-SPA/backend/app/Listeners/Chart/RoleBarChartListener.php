<?php

namespace App\Listeners\Chart;

use Illuminate\Contracts\Queue\ShouldQueue;


class RoleBarChartListener implements ShouldQueue
{
    /**
     * Handle the event.
     */
    public function handle($event): void
    {

    }
}

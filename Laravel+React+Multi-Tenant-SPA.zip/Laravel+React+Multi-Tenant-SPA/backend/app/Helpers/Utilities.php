<?php

namespace App\Helpers;

use Illuminate\Support\Collection;

class Utilities
{
    /**
     * Check if the first three characters of one string match another string.
     *
     * @param string $matchingWhat The string to match from.
     * @param string $matchingWith The string to match against.
     * @return bool True if the first three characters match, case-insensitively.
     */
    public static function matchString($matchingWhat, $matchingWith)
    {
        // Case-insensitive check if $matchingWith starts with the first
        // three characters of $matchingWhat.
        return stripos($matchingWith, substr($matchingWhat, 0, 3)) === 0;
    }

    /**
     * Check if a variable is empty, undefined, null, blank, or invalid.
     *
     * @param mixed $value
     * @return bool
     */
    public static function isEmptyUniversalCheck($value): bool
    {
        // Quick checks for the most common cases
        if (is_null($value) || $value === '' || $value === false || $value === 0 || $value === 0.0) {
            return true;
        }
    
        // Check for undefined or uninitialized variables
        if (!isset($value)) {
            return true;
        }
    
        // Handle strings (trim only if it's a string to avoid overhead)
        if (is_string($value) && trim($value) === '') {
            return true;
        }
    
        // Handle arrays
        if (is_array($value) && count($value) === 0) {
            return true;
        }
    
        // Handle Laravel query builders
        if ($value instanceof \Illuminate\Database\Eloquent\Builder) {
            return $value->count() === 0; // Executes the query to check if results exist
        }
    
        // Handle Laravel collections
        if ($value instanceof \Illuminate\Support\Collection) {
            return $value->isEmpty();
        }
    
        // Handle countable objects
        if ($value instanceof \Countable) {
            return count($value) === 0;
        }
    
        // Handle generic objects
        if (is_object($value)) {
            return empty(get_object_vars($value));
        }
    
        // Otherwise, it's not empty
        return false;
    }
    
    // public static function isEmptyUniversalCheck($value): bool
    // {
    //     // Check for undefined or uninitialized variables
    //     if (!isset($value)) {
    //         return true;
    //     }

    //     // Check for null
    //     if (is_null($value)) {
    //         return true;
    //     }

    //     // Check for empty string or string containing only whitespace
    //     if (is_string($value) && trim($value) === '') {
    //         return true;
    //     }

    //     // Check for empty array
    //     if (is_array($value) && empty($value)) {
    //         return true;
    //     }

    //     // Check for empty object or object with no properties
    //     if (is_object($value)) {
    //         if ($value instanceof Collection) {
    //             // Check for Laravel collections
    //             return $value->isEmpty();
    //         } elseif ($value instanceof \Countable) {
    //             // Check for countable objects
    //             return count($value) === 0;
    //         } else {
    //             // General object check
    //             return empty(get_object_vars($value));
    //         }
    //     }

    //     // Check for false or zero (optional, if these should be considered "empty")
    //     if ($value === false || $value === 0 || $value === 0.0) {
    //         return true;
    //     }

    //     // Otherwise, it's not empty
    //     return false;
    // }
}

// OLD
// namespace App\Helpers;

// class Utilities
// {
//     public static function matchString($matchingWhat, $matchingWith)
//     {
//         // If first three characters of $matchingWhat match $matchingWith
//         // (case-insensitive)
//         return stripos($matchingWith, substr($matchingWhat, 0, 3)) === 0;
//     }
// }

<?php

namespace App\Observers\User;

use App\Models\User\User;
use App\Events\User\UserEvent;

class UserObserver
{
    /**
     * Handle the User "created" event.
     */
    public function created(User $user): void
    {
        // if ($user->status === [1] && $user->roles()->exists()) {
        //     UserEvent::dispatch($user);
        //     // event(new UserEvent($user));
        // }

        // Check if roles have been attached to the user
        // if ($user->wasRecentlyCreated && $user->roles()->exists()) {
        //     event(new UserEvent($user)); // Dispatch UserEvent after roles are confirmed
        // }

        // UserEvent::dispatch($user);
    }

        /**
     * Handle the User "creating" event.
     */
    public function creating(User $user): void
    {
        // if ($user->status === [1] && $user->roles()->exists()) {
        //     UserEvent::dispatch($user);
        //     // event(new UserEvent($user));
        // }

        // Check if roles have been attached to the user
        // if ($user->wasRecentlyCreated && $user->roles()->exists()) {
        //     event(new UserEvent($user)); // Dispatch UserEvent after roles are confirmed
        // }

        // UserEvent::dispatch($user);
    }

    /**
     * Handle the User "updating" event.
     */
    public function updating(User $user): void
    {
        // if ($user->isDirty() || $user->roles()->exists()) {
        //     UserEvent::dispatch($user);
        // }

        // UserEvent::dispatch($user);
    }

    /**
     * Handle the User "updated" event.
     */
    public function updated(User $user): void
    {
        // if ($user->isDirty('status') || $user->roles()->exists()) {
        //     UserEvent::dispatch($user);
        // }

        // UserEvent::dispatch($user);
    }

    /**
     * Handle the User "saving" event.
     */
    public function saving(User $user): void
    {
        // if ($user->isDirty('status') || $user->roles()->exists()) {
        //     UserEvent::dispatch($user);
        // }

        // if ($user->status === [1] && $user->roles()->exists()) {
        //     UserEvent::dispatch($user);
        //     // event(new UserEvent($user));
        // }

        // UserEvent::dispatch($user);
    }

    /**
     * Handle the User "saved" event.
     */
    public function saved(User $user): void
    {
        // if ($user->isDirty('status') || $user->roles()->exists()) {
        //     UserEvent::dispatch($user);
        // }

        // if ($user->status === [1] && $user->roles()->exists()) {
        //     UserEvent::dispatch($user);
        //     // event(new UserEvent($user));
        // }

        UserEvent::dispatch($user, 'saved');
    }

    /**
     * Handle the User "deleted" event.
     */
    public function deleted(User $user): void
    {
        UserEvent::dispatch($user, 'deleted');
    }

    /**
     * Handle the User "restored" event.
     */
    public function restored(User $user): void
    {
        //
    }

    /**
     * Handle the User "force deleted" event.
     */
    public function forceDeleted(User $user): void
    {
        //
    }
}

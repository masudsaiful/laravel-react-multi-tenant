<?php

namespace App\Policies\Role;

use Illuminate\Auth\Access\Response;

use App\Models\User\User;
use App\Models\Role\Role;
use App\Services\Permission\PermissionDatasetService;

class RolePolicy
{
    protected $service;
    protected $permission = 'role';

    public function __construct(PermissionDatasetService $service)
    {
        $this->service = $service;
    }

    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): Response
    {
        $userStatus = $user->status === [1];
        $permissionDataset =  $this->service->getDataset();

        $rules = $userStatus && 
        $this->checkKeyExists(
            $permissionDataset, 
            $this->permission,
            'viewAny',  
        );

        return $rules
        ? Response::allow()
        : Response::deny('Permission restricted to view list'); 
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, Role $role)
    {
        $userStatus = $user->status === [1];
        $createdBy = $user->id === $role->created_by;
        $permissionDataset =  $this->service->getDataset();

        $rules = $userStatus && 
        $this->checkKeyExists(
            $permissionDataset, 
            $this->permission,
            'view',  
        ) && 
        $createdBy;

        return $rules
        ? Response::allow()
        : Response::deny('Permission restricted to view'); 
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user)
    {
        //
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, Role $role)
    {
        //
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, Role $role)
    {
        //
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(User $user, Role $role)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(User $user, Role $role)
    {
        //
    }

    /**
     * Perform pre-authorization checks.
     */
    public function before(User $user, string $ability): bool|null
    {
        $userId = $user->id;
        $roleId = $user->roles()->where('roles.id',1)->first()?->id;

        if ($userId === 1 && $roleId === 1) {
            return true;
        }
     
        return null;
    }

    // checking 'role' keyword in the permission dataset
    protected function checkKeyExists(array $datas, string $key, string $field): bool
    {
        // Validate the input $datas
        if (empty($datas) || !is_array($datas)) {
            return false; // Invalid dataset
        }
    
        // Validate the $key
        if (empty($key) || !is_string($key)) {
            return false; // Invalid key
        }
    
        // Validate the $field
        if (!in_array($field, ['create', 'update', 'delete', 'viewAny', 'view'])) {
            return false; // Invalid field
        }
    
        // Iterate through the dataset
        foreach ($datas as $item) {
            // Ensure each item is valid and has the necessary keys
            if (!is_array($item) || !isset($item['model'], $item['create'], $item['update'], $item['delete'])) {
                continue; // Skip malformed data
            }
    
            // Check if the 'model' matches the $key
            if ($item['model'] === $key) {
                // For "viewAny", return true regardless of the values of create, update, and delete
                if ($field === 'viewAny') {
                    return true; // View is always true if the model matches
                }
    
                // For "view", return true regardless of the values of update
                elseif ($field === 'view' && $item['update'] == 1) {
                    return true; // If update is 1, return true
                }

                // For other fields (create, update, delete), check if the specific field is 1
                elseif (isset($item[$field]) && $item[$field] == 1) {
                    return true; // If create, update, or delete is 1, return true
                }
            }
        }
    
        return false; // No match found
    }  
}

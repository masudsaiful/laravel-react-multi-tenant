<?php

namespace App\Models\Permission;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

use App\Models\Role\Role;
use App\Models\User\User;

class Permission extends Model
{
    use HasFactory, SoftDeletes;

    /**
     * Fillable attributes for mass assignment.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'role_id',
        'uuid',
        'model',
        'create',
        'update',
        'delete',
        'title',
        'note',
        'created_by',
        'updated_by',
    ];

    /**
     * The attributes that should be cast.
     * user_id field as json field type in dB
     * 
     * @var array<string, string>
     */
    protected $casts = [
        'user_id' => 'array',
    ];

    /**
     * Define the relationship between Permission and Role models.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class, 'role_id', 'id');
    }

    /**
     * Define the relationship between Permission created by and user models.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function createdByUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by', 'id')->withDefault();
    }

    /**
     * Define the relationship between Permission updated by and user models.
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function updatedByUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by', 'id')->withDefault();
    }
}

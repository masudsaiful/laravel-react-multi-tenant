<?php

namespace App\Models\Setting;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

use App\Models\User\User;


class Setting extends Model
{
    use HasFactory;

    /**
     * Fillable attributes for mass assignment.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'theme_mode',
        'created_by',
        'updated_by',
    ];

    // Theme mode field ensurely convert to boolean (true/false)
    protected $casts = [
        'theme_mode' => 'boolean',
    ];

    
    /**
     * Define a one-to-one relationship with the associated model.
     *
     * @return \Illuminate\Database\Eloquent\Relations\HasOne
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}

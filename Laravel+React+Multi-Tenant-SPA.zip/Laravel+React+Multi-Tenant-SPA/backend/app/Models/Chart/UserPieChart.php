<?php

namespace App\Models\Chart;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserPieChart extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'total_users',
        'deleted_users',
        'existing_users',
        'deleted_user_percent',
        'existing_user_percent',
        'deleted_enable_user_percent',
        'existing_enable_user_percent',
        'deleted_disable_user_percent',
        'existing_disable_user_percent',
    ];

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'user_pie_charts';
}

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_pie_charts', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('total_users')->index();
            $table->unsignedInteger('deleted_users')->index();
            $table->unsignedInteger('existing_users')->index();
            $table->string('deleted_user_percent')->index();
            $table->string('existing_user_percent')->index();
            $table->string('deleted_enable_user_percent');
            $table->string('existing_enable_user_percent');
            $table->string('deleted_disable_user_percent');
            $table->string('existing_disable_user_percent');
            $table->unsignedTinyInteger('status')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_pie_charts');
    }
};

<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->id();
            $table->json('user_id')->nullable()->comment('Optional user associated with the permission');
            $table->unsignedBigInteger('role_id')->comment('Role associated with the permission one to many relation');
            $table->string('uuid')->unique()->comment('Unique ID of this repeatable form');
            $table->string('model')->comment('The name of the model this permission applies to');
            $table->boolean('create')->default(false)->comment('Indicates if create action is allowed');
            $table->boolean('update')->default(false)->comment('Indicates if edit action is allowed');
            $table->boolean('delete')->default(false)->comment('Indicates if delete action is allowed');
            $table->string('title')->nullable()->comment('Optional title for the permission');
            $table->text('note')->nullable()->comment('Additional notes for the permission');
            $table->unsignedBigInteger('created_by')->nullable()->index();
            $table->unsignedBigInteger('updated_by')->nullable()->index();
            $table->softDeletes('deleted_at')->index();
            $table->timestamps();
            $table->index('created_at');
            $table->index('updated_at');
            $table->foreign('role_id')->references('id')->on('roles')->onDelete('cascade');
            $table->foreign('created_by')->references('id')->on('users')->onDelete('set null');
            $table->foreign('updated_by')->references('id')->on('users')->onDelete('set null');

            $table->index(['create', 'update', 'delete']);
            $table->index(['role_id', 'model']);
            // $table->unique(['role_id', 'model'], 'unique_role_model'); // Base unique constraint
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('permissions');
    }
};
